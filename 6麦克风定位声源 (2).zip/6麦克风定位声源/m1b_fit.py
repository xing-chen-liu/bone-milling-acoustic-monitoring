# -*- coding: utf-8 -*-
"""M1b2: 从 m1b_results.csv 读中位时延, 单位已修正, Huber 鲁棒排列拟合"""
import numpy as np
import csv, itertools, os

C = 343.0
PAIRS = [(i, j) for i in range(6) for j in range(i + 1, 6)]
TRIPLES = [(i, j, k) for i in range(6) for j in range(i + 1, 6) for k in range(j + 1, 6)]

med = {}
with open(os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results"), "m1b_results.csv"),
          encoding="utf-8-sig") as f:
    for row in csv.DictReader(f):
        if row["pair"] == "CLOSURE" or row["band"] != "1-10kHz":
            continue
        med.setdefault(row["session"], {})[row["pair"]] = float(row["tau_med_us"])

xs = np.arange(-100, 201, 5.0)
ys = np.arange(15, 501, 5.0)
GX, GY = np.meshgrid(xs, ys, indexing="ij")
G = np.stack([GX.ravel(), GY.ravel()], axis=1)
HUBER = 30.0   # us, 残差超过此值线性惩罚(压制峰跳跃野值)


def huber_rmse(resid):
    a = np.abs(resid)
    w = np.where(a <= HUBER, a ** 2, 2 * HUBER * a - HUBER ** 2)
    return np.sqrt(np.mean(w, axis=1))


def fit(med_us, tag):
    v = np.array([med_us[f"{i+1}-{j+1}"] for (i, j) in PAIRS])
    results = []
    for perm in itertools.permutations(range(6)):
        p = np.array(perm, float) * 8.0
        r = np.sqrt((p[None, :] - G[:, 0:1]) ** 2 + G[:, 1:2] ** 2)
        resid = np.empty((len(G), 15))
        for pi, (i, j) in enumerate(PAIRS):
            pred = (r[:, i] - r[:, j]) * 1e-3 / C * 1e6
            resid[:, pi] = v[pi] - pred
        rmse = huber_rmse(resid)
        b = int(np.argmin(rmse))
        results.append((float(rmse[b]), perm, float(G[b, 0]), float(G[b, 1])))
    results.sort()
    print(f"\n{tag}  Top-5 排列:")
    for rmse, perm, x, y in results[:5]:
        print(f"  HuberRMSE={rmse:6.2f} us  perm(ch1..6->槽位)={perm}  源 x={x:.0f} y={y:.0f} mm")
    ident = [t for t in results if t[1] == (0, 1, 2, 3, 4, 5)][0]
    print(f"  [对照]顺序排列: HuberRMSE={ident[0]:.2f} us  源 x={ident[2]:.0f} y={ident[3]:.0f} mm")
    # 闭合误差
    cl = []
    for (i, j, k) in TRIPLES:
        e = (med_us[f"{i+1}-{j+1}"] + med_us[f"{j+1}-{k+1}"] - med_us[f"{i+1}-{k+1}"])
        cl.append(e)
    print(f"  闭合误差: std={np.std(cl):.1f} us |max|={np.max(np.abs(cl)):.1f} us")
    return results[0]


for s in ("session01", "session02"):
    fit(med[s], s)

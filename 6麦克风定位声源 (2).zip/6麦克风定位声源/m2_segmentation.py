# -*- coding: utf-8 -*-
"""
M2 v2: 旧数据事件分段（几何无关）
时间线揭示三档能量平台: 背景(低) / 空转(中) / 切削(高)。
方法: log-RMS 上确定性 3-means(三分位初始化) -> 三态按能量排序
      -> 中值平滑 + 最短段约束 -> 事件(状态迁移)。
特征(谱质心/低频比)仅作段级报告与人工校验, 不参与分段方向决策。
输出: m2_segments.csv, m2_timeline_*.png, 切削段清单
"""
import numpy as np
from scipy.io import wavfile
import csv, os

FS_EXPECT = 352800
FRAME = int(0.010 * FS_EXPECT)
HOP = int(0.005 * FS_EXPECT)
BASE = r"D:\bone\data\raw"
SESSIONS = ["session01", "session02"]
MIN_SEG = 0.30
MERGE = 0.15
STATE = {0: "背景", 1: "空转", 2: "切削"}


def load_mono(name):
    xs = []
    for c in range(1, 7):
        fs, x = wavfile.read(os.path.join(BASE, name, f"ch{c}.wav"))
        assert fs == FS_EXPECT
        xs.append(x.astype(np.float32) / 32768.0)
    N = min(len(x) for x in xs)
    return np.mean(np.stack([x[:N] for x in xs]), axis=0)


def features(mono):
    n = (len(mono) - FRAME) // HOP
    rms = np.empty(n); cen = np.empty(n); low = np.empty(n)
    freqs = np.fft.rfftfreq(FRAME, 1 / FS_EXPECT)
    band_low = (freqs >= 300) & (freqs < 1000)
    for i in range(n):
        seg = mono[i * HOP:i * HOP + FRAME]
        spec = np.abs(np.fft.rfft(seg)) ** 2
        tot = spec.sum() + 1e-20
        rms[i] = np.sqrt(np.mean(seg ** 2))
        cen[i] = float(freqs @ spec / tot)
        low[i] = float(spec[band_low].sum() / tot)
    return rms, cen, low


def kmeans1d(v, k=3, iters=50):
    q = np.quantile(v, np.linspace(0, 1, k + 2)[1:-1])
    c = q.copy()
    for _ in range(iters):
        d = np.abs(v[:, None] - c[None, :])
        lab = np.argmin(d, axis=1)
        new = np.array([v[lab == j].mean() if (lab == j).any() else c[j] for j in range(k)])
        if np.allclose(new, c):
            break
        c = new
    return lab, c


def smooth(lab, k=11):
    out = lab.copy()
    for i in range(len(lab)):
        lo, hi_ = max(0, i - k // 2), min(len(lab), i + k // 2 + 1)
        seg = lab[lo:hi_]
        out[i] = int(np.bincount(seg).argmax())
    return out


def segments(t, lab):
    segs = []
    s = 0
    for i in range(1, len(lab)):
        if lab[i] != lab[i - 1]:
            segs.append([t[s], t[i - 1], int(lab[s])])
            s = i
    segs.append([t[s], t[-1], int(lab[s])])
    return segs


def enforce_min(segs):
    out = []
    for seg in segs:
        if out and (seg[1] - seg[0]) < MERGE:
            out[-1][1] = seg[1]
        else:
            out.append(seg)
    for _ in range(3):
        merged = []
        for seg in out:
            if merged and (seg[1] - seg[0]) < MIN_SEG:
                merged[-1][1] = seg[1]
            elif merged and merged[-1][2] == seg[2]:
                merged[-1][1] = seg[1]
            else:
                merged.append(seg)
        out = merged
    return out


def main():
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        have_mpl = True
    except Exception:
        have_mpl = False
    rows = []
    cutting_all = {}
    for name in SESSIONS:
        mono = load_mono(name)
        rms, cen, low = features(mono)
        t = (np.arange(len(rms)) * HOP + FRAME // 2) / FS_EXPECT
        logr = np.log10(rms + 1e-12)
        lab_raw, centers = kmeans1d(logr, k=3)
        order = np.argsort(centers)               # 低->高能量
        remap = {int(order[0]): 0, int(order[1]): 1, int(order[2]): 2}
        lab = np.array([remap[int(v)] for v in lab_raw])
        lab = smooth(lab, 11)
        segs = enforce_min(segments(t, lab))
        print(f"\n=== {name} ===")
        print("t0      t1      状态     时长     RMS(dB)  谱质心(Hz)  低频比%")
        cuts = []
        for (t0, t1, st) in segs:
            m = (t >= t0) & (t <= t1)
            print(f"{t0:7.2f} {t1:7.2f}  {STATE[st]:4s}  {t1-t0:6.2f}s  "
                  f"{20*np.log10(rms[m].mean()+1e-12):7.1f}  {cen[m].mean():8.0f}  "
                  f"{low[m].mean()*100:6.1f}")
            rows.append(dict(session=name, t0=round(t0, 3), t1=round(t1, 3),
                             state=STATE[st], dur_s=round(t1 - t0, 2),
                             rms_db=round(float(20 * np.log10(rms[m].mean() + 1e-12)), 1),
                             centroid_hz=round(float(cen[m].mean()), 0),
                             lowband_pct=round(float(low[m].mean() * 100), 1)))
            if st == 2:
                cuts.append((t0, t1))
        cutting_all[name] = cuts
        ev = []
        for k in range(1, len(segs)):
            if segs[k][2] != segs[k - 1][2]:
                ev.append((segs[k][0], f"{STATE[segs[k-1][2]]}→{STATE[segs[k][2]]}"))
        print("事件: " + ("; ".join(f"{e[0]:.2f}s {e[1]}" for e in ev) or "无"))
        if have_mpl:
            fig, ax = plt.subplots(figsize=(11, 3))
            ax.plot(t, 20 * np.log10(rms + 1e-12), lw=0.6, color="#52525B")
            colors = {0: "#D3D4DA", 1: "#80C1FF", 2: "#0FDC78"}
            for (t0, t1, st) in segs:
                ax.axvspan(t0, t1, color=colors[st], alpha=0.3)
            for (e0, _) in ev:
                ax.axvline(e0, color="#b3261e", lw=0.8, ls="--")
            ax.set_xlabel("time (s)"); ax.set_ylabel("RMS (dB)")
            ax.set_title(f"{name}: gray=background  blue=idle-spindle  green=cutting")
            fig.tight_layout()
            fig.savefig(os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results"),
                                     f"m2_timeline_{name}.png"), dpi=130)
            plt.close(fig)
    out = os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results"), "m2_segments.csv")
    with open(out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["session", "t0", "t1", "state", "dur_s",
                                          "rms_db", "centroid_hz", "lowband_pct"])
        w.writeheader(); w.writerows(rows)
    print(f"\n结果 -> {out}")
    print("\n=== M3 可用的干净切削段清单 ===")
    for name, cuts in cutting_all.items():
        for (t0, t1) in cuts:
            print(f"{name}: {t0:.2f} - {t1:.2f} s  ({t1-t0:.2f}s)")


if __name__ == "__main__":
    main()

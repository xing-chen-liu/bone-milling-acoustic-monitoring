# -*- coding: utf-8 -*-
"""
M3: 路B特征预研（旧数据切削段, 几何无关）
输入: M2 切削段 (session01: 9.44-15.70; session02: 14.06-15.19, 24.62-30.14)
每 20ms 帧/10ms 移提取:
  log-RMS, 包络斜率, 谱质心, 频带比(300-1k/1-5k/5-9k/9k+), 谱平坦度, 滚降85, 峰值因数,
  齿频(包络自相关峰)
评估: 段内 CV(稳定性) + Spearman(特征~时间, 单调漂移指示) + 跨段一致性
边界: 无深度真值, 只做特征筛选与管线验证, 深度映射由台架阶段确认。
输出: m3_features.csv + m3_traj_session01.png + 控制台报告
"""
import numpy as np
from scipy.io import wavfile
from scipy.stats import spearmanr
import csv, os

FS_EXPECT = 352800
FRAME = int(0.020 * FS_EXPECT)     # 20 ms
HOP = int(0.010 * FS_EXPECT)       # 10 ms
BASE = r"D:\bone\data\raw"
SEGMENTS = [("session01", 9.44, 15.70), ("session02", 14.06, 15.19), ("session02", 24.62, 30.14)]
FEATURES = ["log_rms", "env_slope", "centroid", "low_300_1k", "mid_1_5k",
            "high_5_9k", "vhigh_9k_up", "flatness", "rolloff85", "crest", "tooth_hz"]


def load_mono(name):
    xs = []
    for c in range(1, 7):
        fs, x = wavfile.read(os.path.join(BASE, name, f"ch{c}.wav"))
        assert fs == FS_EXPECT
        xs.append(x.astype(np.float32) / 32768.0)
    N = min(len(x) for x in xs)
    return np.mean(np.stack([x[:N] for x in xs]), axis=0)


_cache = {}
def get_mono(name):
    if name not in _cache:
        _cache[name] = load_mono(name)
    return _cache[name]


def frame_features(seg):
    n = (len(seg) - FRAME) // HOP
    freqs = np.fft.rfftfreq(FRAME, 1 / FS_EXPECT)
    bands = {"low_300_1k": (300, 1000), "mid_1_5k": (1000, 5000),
             "high_5_9k": (5000, 9000), "vhigh_9k_up": (9000, 20000)}
    masks = {k: (freqs >= lo) & (freqs < hi) for k, (lo, hi) in bands.items()}
    out = {k: np.empty(n) for k in FEATURES}
    for i in range(n):
        fr = seg[i * HOP:i * HOP + FRAME]
        spec = np.abs(np.fft.rfft(fr)) ** 2
        tot = spec.sum() + 1e-20
        rms = np.sqrt(np.mean(fr ** 2))
        out["log_rms"][i] = 20 * np.log10(rms + 1e-12)
        out["centroid"][i] = float(freqs @ spec / tot)
        for k, m in masks.items():
            out[k][i] = float(spec[m].sum() / tot)
        logspec = np.log(spec + 1e-20)
        out["flatness"][i] = float(np.exp(logspec.mean()) / (spec.mean() + 1e-20))
        cum = np.cumsum(spec) / tot
        out["rolloff85"][i] = float(freqs[np.searchsorted(cum, 0.85)])
        out["crest"][i] = float(np.max(np.abs(fr)) / (rms + 1e-12))
    # 包络斜率与齿频(基于 RMS 包络)
    env = 10 ** (out["log_rms"] / 20)
    out["env_slope"] = np.gradient(env, HOP / FS_EXPECT) / (env + 1e-12)   # 相对斜率 1/s
    # 齿频: 包络去均值自相关, 搜 10-500 Hz 对应滞后
    e = env - env.mean()
    ac = np.correlate(e, e, mode="full")[len(e) - 1:]
    ac /= (ac[0] + 1e-20)
    lo_lag = max(1, int(FS_EXPECT / HOP / 500))   # 500 Hz
    hi_lag = min(len(ac) - 1, int(FS_EXPECT / HOP / 10))  # 10 Hz
    if hi_lag > lo_lag + 2:
        k = lo_lag + int(np.argmax(ac[lo_lag:hi_lag]))
        out["tooth_hz"][:] = FS_EXPECT / HOP / k
    else:
        out["tooth_hz"][:] = np.nan
    return out


def main():
    rows = []
    report = {}
    for (name, t0, t1) in SEGMENTS:
        mono = get_mono(name)
        seg = mono[int(t0 * FS_EXPECT):int(t1 * FS_EXPECT)]
        F = frame_features(seg)
        n = len(F["log_rms"])
        tt = np.arange(n) * HOP / FS_EXPECT
        tag = f"{name}_{t0:.2f}-{t1:.2f}"
        report[tag] = {}
        for k in FEATURES:
            v = F[k]
            ok = ~np.isnan(v)
            vv = v[ok]; ttt = tt[ok]
            cv = float(np.std(vv) / (abs(np.mean(vv)) + 1e-12) * 100)
            rho, _ = spearmanr(ttt, vv) if len(vv) > 4 else (np.nan, 1.0)
            report[tag][k] = (float(np.mean(vv)), cv, float(rho))
            for i in range(n):
                rows.append(dict(seg=tag, t=round(float(tt[i]), 3), feature=k,
                                 value=round(float(v[i]), 5)))
        # 控制台段报告
        print(f"\n=== {tag}  ({n} 帧) ===")
        print(f"{'特征':<12}{'均值':>12}{'CV%':>8}{'Spearman ρ':>12}")
        for k in FEATURES:
            m, cv, rho = report[tag][k]
            print(f"{k:<12}{m:>12.3f}{cv:>8.1f}{rho:>12.2f}")

    # 跨段一致性: 均值的跨段 CV
    print("\n=== 跨段一致性（3 段均值的 CV）===")
    for k in FEATURES:
        ms = [report[t][k][0] for t in report]
        cv = float(np.std(ms) / (abs(np.mean(ms)) + 1e-12) * 100)
        print(f"{k:<12} 段均值 CV = {cv:5.1f}%   ({', '.join(f'{m:.2f}' for m in ms)})")

    # 候选筛选: 稳定(段内CV<30) + 有动态(|ρ|>0.5)
    print("\n=== 候选特征筛选 (段内CV<30% 且 |ρ|>0.5) ===")
    for k in FEATURES:
        cvs = [report[t][k][1] for t in report]
        rhos = [abs(report[t][k][2]) for t in report]
        if np.mean(cvs) < 30 and np.mean(rhos) > 0.5:
            print(f"  ✓ {k}   (mean CV={np.mean(cvs):.0f}%, mean |ρ|={np.mean(rhos):.2f})")

    out = os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results"), "m3_features.csv")
    with open(out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["seg", "t", "feature", "value"])
        w.writeheader(); w.writerows(rows)

    # 轨迹图: session01 主段
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        tag = "session01_9.44-15.70"
        mono = get_mono("session01")
        seg = mono[int(9.44 * FS_EXPECT):int(15.70 * FS_EXPECT)]
        F = frame_features(seg)
        tt = np.arange(len(F["log_rms"])) * HOP / FS_EXPECT
        keys = ["log_rms", "centroid", "low_300_1k", "high_5_9k", "flatness", "rolloff85"]
        fig, axes = plt.subplots(len(keys), 1, figsize=(10, 9), sharex=True)
        for ax, k in zip(axes, keys):
            ax.plot(tt, F[k], lw=0.9, color="#02743B")
            ax.set_ylabel(k, fontsize=8)
        axes[-1].set_xlabel("time (s)")
        fig.suptitle("session01 cutting 9.44-15.70s: feature trajectories")
        fig.tight_layout()
        fig.savefig(os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results"),
                                 "m3_traj_session01.png"), dpi=130)
        plt.close(fig)
    except Exception as e:
        print(f"(绘图跳过: {e})")
    print(f"\n结果 -> {out}")


if __name__ == "__main__":
    main()

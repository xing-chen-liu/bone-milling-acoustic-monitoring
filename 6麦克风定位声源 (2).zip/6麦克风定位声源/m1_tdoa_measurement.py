# -*- coding: utf-8 -*-
"""
M1: 旧线阵 6 通道真实数据 TDOA 实测（几何无关量）
数据: D:\\bone\\data\\raw\\session01, session02 (线阵相邻 8mm, fs=352800)
防护规范:
  1) sigma_tau 用稳态段内滑窗估计的重复性(std)——不依赖几何真值;
  2) 物理上限判据 |tau_ij| <= |i-j|*8mm/c（超限=多径/粗差, 也是README遗留问题的检查）;
  3) 闭合误差 tau_ij+tau_jk-tau_ik（对任意声源位置严格为零）= 纯估计质量指标。
输出: 控制台报告 + m1_results.csv
"""
import numpy as np
from scipy.io import wavfile
import csv, os, sys

C = 343.0
D_ADJ = 0.008            # 相邻麦克风间距 8 mm（README）
FS_EXPECT = 352800
FRAME = 8192             # 23.2 ms
HOP = 4096               # 11.6 ms
BANDS = {"1-10kHz": (1000.0, 10000.0),
         "5-9kHz": (5000.0, 9000.0),
         "0.3-20kHz": (300.0, 20000.0)}
BASE = r"D:\bone\data\raw"
SESSIONS = ["session01", "session02"]

PAIRS = [(i, j) for i in range(6) for j in range(i + 1, 6)]
TRIPLES = [(i, j, k) for i in range(6) for j in range(i + 1, 6) for k in range(j + 1, 6)]


def load_session(name):
    chans = []
    for c in range(1, 7):
        fs, x = wavfile.read(os.path.join(BASE, name, f"ch{c}.wav"))
        if fs != FS_EXPECT:
            raise RuntimeError(f"{name} ch{c}: fs={fs} != {FS_EXPECT}")
        chans.append(x.astype(np.float32) / 32768.0)
    N = min(len(x) for x in chans)
    return np.stack([x[:N] for x in chans]), FS_EXPECT


def detect_active(x, fs):
    """多通道 RMS 能量检测活跃段（10ms 窗）"""
    win = int(0.010 * fs)
    mono = np.mean(x, axis=0)
    n = len(mono) // win
    rms = np.sqrt(np.mean(mono[:n*win].reshape(n, win) ** 2, axis=1))
    floor = np.percentile(rms, 10)
    act = rms > max(4 * floor, 1e-4)
    idx = np.where(act)[0]
    if not len(idx):
        return 0.0, len(mono) / fs
    return idx[0] * win / fs, (idx[-1] + 1) * win / fs


def gcc_phat_tau(Fi, Fj, mask, max_lag, nfft):
    """单帧 GCC-PHAT + 抛物线插值; Fi/Fj 为帧 FFT"""
    G = Fi * np.conj(Fj) * mask
    G /= (np.abs(G) + 1e-12)
    cc = np.fft.ifft(G).real
    seg = np.concatenate((cc[-max_lag:], cc[:max_lag + 1]))   # lags -max_lag..max_lag
    k = int(np.argmax(seg))
    tau = k - max_lag
    if 0 < k < len(seg) - 1:
        y0, ym, yp = seg[k], seg[k - 1], seg[k + 1]
        den = ym - 2 * y0 + yp
        if abs(den) > 1e-18:
            tau = tau + 0.5 * (ym - yp) / den
    return tau / FS_EXPECT     # seconds


def session_analysis(x, fs, name, out_rows):
    t0, t1 = detect_active(x, fs)
    print(f"\n=== {name}: 活跃段 {t0:.2f}-{t1:.2f} s ===")
    # 帧列表(活跃段内)
    starts = np.arange(int(t0 * fs), int(t1 * fs) - FRAME, HOP)
    nfft = FRAME
    freqs = np.fft.rfftfreq(nfft, 1 / fs) if False else np.fft.fftfreq(nfft, 1 / fs)
    results = {}
    for bname, (lo, hi) in BANDS.items():
        mask = ((np.abs(freqs) >= lo) & (np.abs(freqs) <= hi)).astype(np.float64)
        taus = np.zeros((len(starts), len(PAIRS)))
        # 逐帧 FFT 6 通道
        F = np.zeros((len(starts), 6, nfft), dtype=np.complex64)
        for fi, s in enumerate(starts):
            for ch in range(6):
                F[fi, ch] = np.fft.fft(x[ch, s:s + nfft])
        for pi, (i, j) in enumerate(PAIRS):
            max_lag = int(np.ceil(abs(i - j) * D_ADJ / C * fs)) + 3
            for fi in range(len(starts)):
                taus[fi, pi] = gcc_phat_tau(F[fi, i], F[fi, j], mask, max_lag, nfft)
        results[bname] = taus
        # 逐对统计
        print(f"\n-- 频段 {bname} --")
        print("pair  d_mm  tau_med(us)  sigma_tau(us)  超限率")
        sig_all = []
        for pi, (i, j) in enumerate(PAIRS):
            d_mm = abs(i - j) * D_ADJ * 1000
            lim = abs(i - j) * D_ADJ / C
            t = taus[:, pi]
            med = np.median(t)
            sig = np.std(t - np.median(t))   # 重复性(去除慢漂移中位)
            viol = np.mean(np.abs(t) > lim * 1.2)   # 20% 容差
            sig_all.append(sig * 1e6)
            print(f"({i+1},{j+1})  {d_mm:4.0f}   {med*1e6:+8.2f}   {sig*1e6:8.2f}   {viol*100:5.1f}%")
            out_rows.append(dict(session=name, band=bname, pair=f"{i+1}-{j+1}",
                                 d_mm=round(d_mm, 1), tau_med_us=round(med * 1e6, 3),
                                 sigma_tau_us=round(sig * 1e6, 3),
                                 viol_pct=round(viol * 100, 1)))
        print(f"sigma_tau 汇总: 中位 {np.median(sig_all):.2f} us  范围 [{min(sig_all):.2f}, {max(sig_all):.2f}]")
        # 闭合误差（几何无关）
        closures = []
        for (i, j, k) in TRIPLES:
            p_ij = PAIRS.index((i, j)); p_jk = PAIRS.index((j, k)); p_ik = PAIRS.index((i, k))
            e = taus[:, p_ij] + taus[:, p_jk] - taus[:, p_ik]
            closures.append(e * 1e6)
        cl = np.concatenate(closures)
        print(f"闭合误差 tau_ij+tau_jk-tau_ik: std={np.std(cl):.2f} us  |max|={np.max(np.abs(cl)):.1f} us")
        out_rows.append(dict(session=name, band=bname, pair="CLOSURE",
                             d_mm="", tau_med_us="", sigma_tau_us=round(float(np.std(cl)), 3),
                             viol_pct=""))
        # 前后半段漂移
        half = len(taus) // 2
        s1 = np.median([np.std(taus[:half, pi] - np.median(taus[:half, pi])) for pi in range(15)]) * 1e6
        s2 = np.median([np.std(taus[half:, pi] - np.median(taus[half:, pi])) for pi in range(15)]) * 1e6
        print(f"漂移检查: 前半段 sigma 中位 {s1:.2f} us / 后半段 {s2:.2f} us")
        # 线阵线性度（仅作方向 sanity, 不进结论）
        med_pairs = [np.median(taus[:, pi]) * 1e6 for pi in range(15)]
        print(f"邻对时延中位(us): " + "  ".join(
            f"({PAIRS[p][0]+1},{PAIRS[p][1]+1})={med_pairs[p]:+.1f}" for p in range(5)))
    return results


def main():
    out_rows = []
    for name in SESSIONS:
        x, fs = load_session(name)
        session_analysis(x, fs, name, out_rows)
        del x
    out = os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results"), "m1_results.csv")
    with open(out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["session", "band", "pair", "d_mm",
                                          "tau_med_us", "sigma_tau_us", "viol_pct"])
        w.writeheader(); w.writerows(out_rows)
    print(f"\n结果 -> {out}")


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""
S4: 事件检测 ROC 仿真 (穿透事件)  [v2: 频域网格按信号长度即时生成]
合成: ch2 谱模板切削声; 注入穿透事件(能量陡降+高频突发+质心跳变, 文献机理);
      混淆事件(崩屑突发: 仅能量升, 无穿透特征)考验误报。
检测器: 能量陡降 E / 高频突发 H / 质心跳变 C / 融合 F
指标: 段级 AUC, 特异度95%下检出率与检测延迟; 验收 AUC>=0.95, 延迟<=50ms
输出: s4_results.csv + s4_roc.png + 控制台
"""
import numpy as np
from scipy.io import wavfile
from scipy.signal import welch
from scipy.ndimage import median_filter
import csv, os

FS = 48000
SEG = 2.5
HOP = int(0.005 * FS)
FRAME = int(0.010 * FS)
N_SEG = 120            # 40 纯切削 / 40 穿透 / 40 混淆
SEED = 44
rng = np.random.default_rng(SEED)

fs0, x0 = wavfile.read(r"D:\bone\data\raw\session01\ch2.wav")
seg0 = x0[int(9.44 * fs0):int(15.70 * fs0)].astype(np.float64) / 32768.0
F_T, P_T = welch(seg0, fs=fs0, nperseg=8192)


def colored(n):
    g = np.fft.rfftfreq(n, 1 / FS)
    P = np.interp(g, F_T, P_T, left=P_T[0], right=P_T[-1] * 1e-4)
    S = (rng.standard_normal(len(g)) + 1j * rng.standard_normal(len(g))) * np.sqrt(P)
    S[(g < 300) | (g > 22000)] = 0
    return np.fft.irfft(S, n)


def band_noise(n, lo, hi, amp):
    g = np.fft.rfftfreq(n, 1 / FS)
    nb = rng.standard_normal(n)
    S = np.fft.rfft(nb)
    S[(g < lo) | (g > hi)] = 0
    y = np.fft.irfft(S, n)
    return amp * y / (np.std(y) + 1e-12)


def synth(kind):
    n = int(SEG * FS)
    x = colored(n)
    x /= np.std(x)
    t0 = None
    if kind == "break":
        t0 = 0.9 + rng.uniform(0, 0.5)
        i0 = int(t0 * FS)
        m = np.ones(n)                                  # 能量陡降 -7dB / 40ms
        k = int(0.040 * FS)
        m[i0:] = 0.45
        m[i0:i0 + k] = np.linspace(1.0, 0.45, k)
        x *= m
        burst = band_noise(int(0.020 * FS), 5000, 15000, 0.5)   # 高频突发 20ms
        x[i0:i0 + len(burst)] += burst
        # 质心跳变: 穿透后谱形高频抬升(乘性, 不加能量, 保持 -7dB 陡降)
        post = x[i0:].copy()
        Sp = np.fft.rfft(post)
        gp = np.fft.rfftfreq(len(post), 1 / FS)
        Sp[gp > 4000] *= 2.5
        x[i0:] = np.fft.irfft(Sp, len(post))
    elif kind == "confuse":
        t0 = 0.9 + rng.uniform(0, 0.5)
        i0 = int(t0 * FS)
        burst = band_noise(int(0.030 * FS), 100, 3000, 1.0)     # 低频突发, 无陡降无高频
        x[i0:i0 + len(burst)] += burst
    return x, t0


GF = np.fft.rfftfreq(FRAME, 1 / FS)
HI_M = (GF >= 5000) & (GF < 15000)


def features(x):
    n = (len(x) - FRAME) // HOP
    rms = np.empty(n); hf = np.empty(n); cen = np.empty(n)
    for i in range(n):
        fr = x[i * HOP:i * HOP + FRAME]
        S = np.abs(np.fft.rfft(fr)) ** 2
        tot = S.sum() + 1e-20
        rms[i] = 20 * np.log10(np.sqrt(np.mean(fr ** 2)) + 1e-12)
        hf[i] = S[HI_M].sum() / tot
        cen[i] = float(GF @ S / tot)
    return rms, hf, cen


def _ma(v, k):
    return np.convolve(v, np.ones(k) / k, mode="same")


def _causal_med(v, w=41):
    """因果中位基线(只用过去 w 帧)"""
    m = median_filter(v, size=w, mode="nearest")
    h = w // 2
    return np.concatenate([np.full(h, m[0]), m[:-h]])


def scores(rms, hf, cen):
    """v4: 包络平滑 + 因果基线 + 比值化(无 MAD, 免爆炸)
       E: 相对过去200ms基线的 dB 陡降; H: hf/因果基线hf; C: cen/因果基线cen"""
    rms_s = _ma(rms, 5)            # 25ms 平滑, 压制帧级±3dB波动
    hf_s = _ma(hf, 3)
    cen_s = _ma(cen, 3)
    drop = _causal_med(rms_s, 41) - rms_s
    h = hf_s / (_causal_med(hf_s, 41) + 1e-9)
    c = cen_s / (_causal_med(cen_s, 41) + 1e-9)
    return {"E": drop, "H": h, "C": c, "F": drop + 2.0 * (h - 1) + 2.0 * (c - 1)}


def auc(labels, vals):
    order = np.argsort(vals)
    r = np.empty(len(vals)); r[order] = np.arange(1, len(vals) + 1)
    n1 = int(labels.sum()); n0 = len(labels) - n1
    return float((r[labels == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0 + 1e-12))


def main():
    data = []
    for i in range(N_SEG):
        kind = "clean" if i < 40 else ("break" if i < 80 else "confuse")
        x, t0 = synth(kind)
        rms, hf, cen = features(x)
        data.append((kind, t0, scores(rms, hf, cen)))
    labels = np.array([d[0] == "break" for d in data])
    stats = {}
    rows = []
    print("检测器  AUC(穿透vs其余)  AUC(穿透vs纯切削)")
    raw = {}
    for det in ("E", "H", "C", "F"):
        vals = np.array([d[2][det].max() for d in data])
        raw[det] = vals
    # 融合: 三检测器段级分数总体标准化后求和(避免量纲混合)
    z = {}
    for det in ("E", "H", "C"):
        v = raw[det]
        z[det] = (v - v.mean()) / (v.std() + 1e-9)
    raw["F"] = z["E"] + z["H"] + z["C"]
    for det in ("E", "H", "C", "F"):
        vals = raw[det]
        a1 = auc(labels, vals)
        a2 = auc(np.array([d[0] == "break" for d in data[:80]]), vals[:80])
        stats[det] = vals
        print(f"  {det}      {a1:.3f}            {a2:.3f}")
        rows.append(dict(det=det, auc_all=round(a1, 4), auc_vs_clean=round(a2, 4)))
    print("\n检测器  阈值(95%特异)  检出率  检测延迟中位(ms)")
    for det in ("E", "H", "C", "F"):
        neg = stats[det][~labels]
        thr = np.percentile(neg, 95)
        pos = stats[det][labels]
        det_rate = float(np.mean(pos > thr))
        delays = []
        for (kind, t0, sc) in data:
            if kind != "break":
                continue
            s = sc[det]
            idx = np.where(s > thr)[0]
            idx = idx[idx * HOP / FS > t0]
            if len(idx):
                delays.append((idx[0] * HOP / FS - t0) * 1000)
        med = float(np.median(delays)) if delays else float("nan")
        print(f"  {det}      {thr:8.2f}     {det_rate:.2f}     {med:8.0f}")
        rows.append(dict(det=det + "@95spec", thr=round(float(thr), 2),
                         det_rate=round(det_rate, 3), delay_ms=round(med, 1)))
    out = os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results"), "s4_results.csv")
    with open(out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["det", "auc_all", "auc_vs_clean",
                                          "thr", "det_rate", "delay_ms"], restval="")
        w.writeheader(); w.writerows(rows)
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(6, 5))
        for det, mk in (("E", "o"), ("H", "s"), ("C", "^"), ("F", "D")):
            vals = stats[det]
            ths = np.linspace(vals.min() - 1, vals.max() + 1, 400)
            tpr = [np.mean(vals[labels] > t) for t in ths]
            fpr = [np.mean(vals[~labels] > t) for t in ths]
            ax.plot(fpr, tpr, mk, ms=3, label=f"{det} (AUC={auc(labels, vals):.3f})")
        ax.plot([0, 1], [0, 1], "k--", lw=0.8)
        ax.set_xlabel("false positive rate"); ax.set_ylabel("true positive rate")
        ax.set_title("S4: breakthrough detection ROC")
        ax.legend(fontsize=9); ax.grid(alpha=0.3)
        fig.tight_layout()
        fig.savefig(os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results"),
                                 "s4_roc.png"), dpi=130)
        plt.close(fig)
    except Exception as e:
        print(f"(绘图跳过: {e})")
    print(f"\n结果 -> {out}")


if __name__ == "__main__":
    main()

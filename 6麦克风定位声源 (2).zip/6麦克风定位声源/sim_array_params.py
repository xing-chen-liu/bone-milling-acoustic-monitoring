# -*- coding: utf-8 -*-
"""
阵列参数批量仿真 v2（刀把安装 · 6 麦环）
发现并修复: 共面正六边形 + 轴上声源 => 时差恒零, z 不可观测(几何退化)。
本版对比 3 类几何:
  G0 共面六边形(现行, 对照)
  G1 交错六边形: 麦高 z = +dz / -dz 交替(推荐候选)
  G2 五圆周 + 1 中心(径向多样性)
然后用最优几何扫 d(R) x H x alpha, 以 B 系深度轴误差 rmse_zB 为主指标。
A 系: 环心原点, xy=环平面, z 沿刀轴; 声源名义 (0,0,-H)。
噪声: 每通道时延误差 e_i ~ N(0, sigma_tau); 时差观测误差 = e_i - e_j。
"""
import numpy as np
import csv
import os

C = 343.0
SIG_TAU = 5e-6
N_TRIAL = 300
SEED = 42
rng = np.random.default_rng(SEED)
PAIRS = [(i, j) for i in range(6) for j in range(i + 1, 6)]


def mic_array(R, geom="hex", dz=0.0):
    if geom == "hex":
        ang = np.arange(6) * (2 * np.pi / 6.0)
        z = np.array([dz if k % 2 == 0 else -dz for k in range(6)])
        return np.stack([R * np.cos(ang), R * np.sin(ang), z], axis=1)
    if geom == "pent_center":
        ang = np.arange(5) * (2 * np.pi / 5.0)
        ring = np.stack([R * np.cos(ang), R * np.sin(ang), np.zeros(5)], axis=1)
        return np.vstack([ring, np.zeros((1, 3))])
    raise ValueError(geom)


def pair_matrix():
    G = np.zeros((len(PAIRS), 6))
    for k, (i, j) in enumerate(PAIRS):
        G[k, i] = 1.0
        G[k, j] = -1.0
    return G


PM = pair_matrix()


def ranges(mics, s):
    return np.linalg.norm(mics - s, axis=1)


def jacobi_u(mics, s):
    diff = s - mics
    r = np.linalg.norm(diff, axis=1)
    return diff / r[:, None], r


def solve_lm(mics, dm, s0, iters=60, ball_center=None, ball_r=20e-3):
    """Levenberg-Marquardt(阻尼 GN), 含 10mm 步长信任域;
    ball_center 给出时, 估计约束在以名义声源为中心的球内(真实系统的先验工作域)"""
    s = s0.copy()
    u, r = jacobi_u(mics, s)
    G = np.array([u[i] - u[j] for (i, j) in PAIRS])
    res = (PM @ r) - dm
    cost = float(res @ res)
    lam = 1e-3
    for _ in range(iters):
        A = G.T @ G
        scale = np.trace(A) / 3.0 + 1e-18
        g = G.T @ res
        try:
            step = np.linalg.solve(A + lam * scale * np.eye(3), -g)
        except np.linalg.LinAlgError:
            lam *= 10.0
            continue
        n = np.linalg.norm(step)
        if n > 10e-3:
            step = step * (10e-3 / n)
        s_new = s + step
        u2, r2 = jacobi_u(mics, s_new)
        G2 = np.array([u2[i] - u2[j] for (i, j) in PAIRS])
        res2 = (PM @ r2) - dm
        cost2 = float(res2 @ res2)
        if cost2 < cost:
            s = s_new
            lam = max(lam / 3.0, 1e-9)
            if ball_center is not None:
                d = s - ball_center
                nd = np.linalg.norm(d)
                if nd > ball_r:
                    s = ball_center + d * (ball_r / nd)
            u, r = jacobi_u(mics, s)
            G = np.array([u[i] - u[j] for (i, j) in PAIRS])
            res = (PM @ r) - dm
            cost = float(res @ res)
            if np.linalg.norm(step) < 1e-10:
                break
        else:
            lam *= 5.0
    return s


def fim_cov(mics, s_true, sigma_tau=SIG_TAU):
    """FIM(15 对基线, 独立近似) 及可观测性秩; 退化方向特征值 -> z 误差下限"""
    u, r = jacobi_u(mics, s_true)
    G = np.array([u[i] - u[j] for (i, j) in PAIRS])
    var = 2.0 * (C * sigma_tau) ** 2
    FIM = G.T @ G / var
    w = np.linalg.eigvalsh(FIM)
    rank = int(np.sum(w > w.max() * 1e-9))
    return FIM, rank, w


def crlb_zb(mics, s_true, alpha_deg, n_gamma=24):
    """深度轴 z_B 误差 CRLB(对 gamma 平均); 退化返回 inf"""
    FIM, rank, _ = fim_cov(mics, s_true)
    if rank < 3:
        return float("inf")
    cov = np.linalg.inv(FIM)
    a = np.deg2rad(alpha_deg)
    vals = []
    for k in range(n_gamma):
        g = 2 * np.pi * k / n_gamma
        n = np.array([np.sin(a) * np.cos(g), np.sin(a) * np.sin(g), np.cos(a)])
        vals.append(n @ cov @ n)
    return float(np.sqrt(np.mean(vals)))


def mc_localize(mics, s_true, alpha_deg, sigma_tau=SIG_TAU, n_trial=N_TRIAL):
    """蒙特卡洛: 返回 rmse3d, rmse_xy, rmse_zA, rmse_zB, bias_zA"""
    H = -s_true[2]
    s0 = np.array([0.0, 0.0, -H * 0.8])
    a = np.deg2rad(alpha_deg)
    s3 = sxy = szA = szB = 0.0
    bzA = 0.0
    for _ in range(n_trial):
        e = rng.normal(0.0, sigma_tau, 6)
        r = ranges(mics, s_true)
        dm = PM @ r + C * (PM @ e)
        err = solve_lm(mics, dm, s0, ball_center=s_true) - s_true
        gd = rng.uniform(0.0, 2 * np.pi)
        n = np.array([np.sin(a) * np.cos(gd), np.sin(a) * np.sin(gd), np.cos(a)])
        s3 += float(err @ err)
        sxy += err[0] ** 2 + err[1] ** 2
        szA += err[2] ** 2
        szB += float(n @ err) ** 2
        bzA += err[2]
    f = lambda x: round(float(np.sqrt(x / n_trial)) * 1e3, 2)
    return f(s3), f(sxy), f(szA), f(szB), round(bzA / n_trial * 1e3, 2)


def kabsch(PA, PB):
    cA, cB = PA.mean(0), PB.mean(0)
    Hm = (PA - cA).T @ (PB - cB)
    U, _, Vt = np.linalg.svd(Hm)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    R = Vt.T @ np.diag([1.0, 1.0, d]) @ U.T
    return R, cB - R @ cA


def alpha_recovery(spread_mm, sigma_p_mm, n_trial=300):
    """已知位置外部参考声源(扬声器)反推 alpha; 声源跨度 = spread_mm"""
    alpha_deg, gamma_deg = 45.0, 30.0
    a, g = np.deg2rad(alpha_deg), np.deg2rad(gamma_deg)
    Ry = np.array([[np.cos(a), 0, np.sin(a)], [0, 1, 0], [-np.sin(a), 0, np.cos(a)]])
    Rz = np.array([[np.cos(g), -np.sin(g), 0], [np.sin(g), np.cos(g), 0], [0, 0, 1]])
    R_AB = Ry @ Rz
    t_B = np.array([5e-3, -3e-3, -18e-3])
    h = spread_mm / 2e3
    PB = np.array([[-h, -h, 0], [h, -h, 0], [h, h, 0], [-h, h, 0]], float)
    PA_true = (R_AB.T @ (PB - t_B).T).T
    sp = sigma_p_mm * 1e-3
    errs = []
    for _ in range(n_trial):
        PA = PA_true + rng.normal(0, sp, PA_true.shape)
        R_est, _ = kabsch(PA, PB)
        a_est = np.degrees(np.arccos(np.clip(R_est[2, 2], -1.0, 1.0)))
        errs.append(a_est - alpha_deg)
    errs = np.array(errs)
    return float(np.sqrt(np.mean(errs ** 2))), float(np.mean(errs))


def main():
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")

    # ---------- sanity: 交错几何零噪声收敛 ----------
    mics = mic_array(16e-3, "hex", 4e-3)
    s_true = np.array([0.0, 0.0, -25e-3])
    r = ranges(mics, s_true)
    dm = PM @ r
    bias = solve_lm(mics, dm, np.array([0.0, 0.0, -20e-3])) - s_true
    print(f"[sanity] staggered geom, zero-noise bias = {np.linalg.norm(bias)*1e3:.4f} mm")

    # ---------- Part 1: alpha 反推 ----------
    print("\n=== Part 1: alpha recovery via external reference sources (true=45 deg) ===")
    print("spread(mm) sigma_p(mm) rmse_alpha(deg) bias(deg)")
    for spread in (30.0, 80.0, 120.0):
        for sp in (1.0, 2.0, 3.0):
            rmse, bias = alpha_recovery(spread, sp)
            print(f"  {spread:6.0f}     {sp:4.1f}        {rmse:6.3f}       {bias:+.3f}")
    print("NOTE: tool-tip itself as reference carries ZERO info (co-moving source).")

    # ---------- Part 2: 几何方案对比 (R=16mm, alpha=45) ----------
    print("\n=== Part 2: geometry comparison (R=16mm, alpha=45deg) ===")
    print("geom            H  off-axis  rank  rmse3d  rmse_xy  rmse_zA  rmse_zB  crlb_zB")
    geo_rows = []
    cases = []
    cases.append(("G0 planar hex", "hex", 0.0, 25.0, 0.0))
    cases.append(("G0 planar hex", "hex", 0.0, 25.0, 1.0))
    cases.append(("G0 planar hex", "hex", 0.0, 25.0, 3.0))
    for dz in (2.0, 3.0, 4.0, 6.0, 8.0):
        cases.append((f"G1 stagger dz={dz:.0f}", "hex", dz, 25.0, 0.0))
        cases.append((f"G1 stagger dz={dz:.0f}", "hex", dz, 30.0, 0.0))
    cases.append(("G2 pent+center", "pent_center", 0.0, 25.0, 0.0))
    cases.append(("G2 pent+center", "pent_center", 0.0, 30.0, 0.0))
    for name, geom, dz, H, off in cases:
        mics = mic_array(16e-3, geom, dz * 1e-3)
        s_true = np.array([off * 1e-3, 0.0, -H * 1e-3])
        _, rank, _ = fim_cov(mics, s_true)
        r3, rxy, rzA, rzB, bzA = mc_localize(mics, s_true, 45.0)
        czb = crlb_zb(mics, s_true, 45.0)
        czb = round(czb * 1e3, 2) if np.isfinite(czb) else float("inf")
        print(f"{name:15s} {H:4.0f} {off:7.1f}  {rank:4d}  {r3:6.2f}  {rxy:7.2f}  "
              f"{rzA:7.2f}  {rzB:7.2f}  {czb:7.2f}")
        geo_rows.append(dict(geom=name, H_mm=H, dz_mm=dz, off_axis_mm=off, rank=rank,
                             rmse3d_mm=r3, rmse_xy_mm=rxy, rmse_zA_mm=rzA,
                             rmse_zB_mm=rzB, crlb_zB_mm=czb))

    print("\n-- dz trade-off at R=16mm, alpha=45deg: crlb_zB(mm) vs clearance(mm) --")
    print("dz_mm  H=25: crlb/clear    H=30: crlb/clear")
    for dz in (0, 2, 4, 6, 8, 10, 12):
        line = f"  {dz:2d}   "
        for H in (25.0, 30.0):
            mics = mic_array(16e-3, "hex", dz * 1e-3)
            st = np.array([0.0, 0.0, -H * 1e-3])
            c = crlb_zb(mics, st, 45.0)
            c = c * 1e3 if np.isfinite(c) else float("inf")
            clear = H * 1e-3 * np.cos(np.deg2rad(45)) - 16e-3 * np.sin(np.deg2rad(45)) \
                - dz * 1e-3
            line += f"  {c:8.2f} / {clear*1e3:5.1f}   "
        print(line)

    with open(os.path.join(base, "sim_geom_compare.csv"), "w", newline="",
              encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(geo_rows[0].keys()))
        w.writeheader()
        w.writerows(geo_rows)

    # ---------- Part 3: d x H x alpha 扫描(交错几何) ----------
    print("\n=== Part 3: sweep R x H x alpha (staggered hex, sigma_tau=5us) ===")
    rows = []
    for R in (12e-3, 14e-3, 16e-3, 18e-3, 20e-3):
        for dz_mm in (4.0,):
            mics = mic_array(R, "hex", dz_mm * 1e-3)
            for H in (15e-3, 20e-3, 25e-3, 30e-3, 35e-3):
                s_true = np.array([0.0, 0.0, -H])
                for ad in (40.0, 45.0, 47.0, 50.0, 55.0):
                    a = np.deg2rad(ad)
                    clear = H * np.cos(a) - R * np.sin(a) - dz_mm * 1e-3
                    f_alias = C / (2 * R)
                    feasible = (clear >= 5e-3) and (f_alias >= 10e3)
                    r3, rxy, rzA, rzB, bzA = mc_localize(mics, s_true, ad)
                    rows.append(dict(
                        R_mm=round(R * 1e3, 1), dz_mm=dz_mm, H_mm=round(H * 1e3, 1),
                        alpha_deg=ad, clear_mm=round(clear * 1e3, 1),
                        f_alias_kHz=round(f_alias / 1e3, 2), feasible=int(feasible),
                        rmse3d_mm=r3, rmse_xy_mm=rxy, rmse_zA_mm=rzA, rmse_zB_mm=rzB,
                        bias_zA_mm=bzA,
                        crlb_zB_mm=(lambda v: round(v * 1e3, 2) if np.isfinite(v)
                                    else float("inf"))(crlb_zb(mics, s_true, ad))))

    with open(os.path.join(base, "sim_array_results.csv"), "w", newline="",
              encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    feas = [r for r in rows if r["feasible"]]
    print(f"total {len(rows)} configs, feasible {len(feas)}, "
          f"infeasible(clearance/aliasing) {len(rows)-len(feas)}")
    print("\n-- Top 12 feasible by rmse_zB --")
    print(" R   H  alpha clear f_alias rmse3d rmse_xy rmse_zA rmse_zB crlb_zB")
    for r in sorted(feas, key=lambda x: x["rmse_zB_mm"])[:12]:
        print(f"{r['R_mm']:4.0f} {r['H_mm']:3.0f} {r['alpha_deg']:5.0f} "
              f"{r['clear_mm']:6.1f} {r['f_alias_kHz']:6.2f} "
              f"{r['rmse3d_mm']:7.2f} {r['rmse_xy_mm']:7.2f} {r['rmse_zA_mm']:7.2f} "
              f"{r['rmse_zB_mm']:7.2f} {r['crlb_zB_mm']:7.2f}")

    for metric in ("rmse_zB_mm", "rmse3d_mm", "crlb_zB_mm"):
        print(f"\n-- mean {metric} (feasible) by factor --")
        for key, vals in (("R_mm", [12, 14, 16, 18, 20]),
                          ("H_mm", [15, 20, 25, 30, 35]),
                          ("alpha_deg", [40, 45, 47, 50, 55])):
            line = f"  {key:9s}: "
            for v in vals:
                sel = [r[metric] for r in feas if r[key] == v]
                line += f"{v}->{(np.mean(sel) if sel else float('nan')):.2f}  "
            print(line)

    # 约束内最优(按 rmse_zB) 与 综合推荐
    best = min(feas, key=lambda x: x["rmse_zB_mm"])
    print(f"\nbest feasible: R={best['R_mm']:.0f} H={best['H_mm']:.0f} "
          f"alpha={best['alpha_deg']:.0f} rmse_zB={best['rmse_zB_mm']:.2f}mm")

    # ---------- Part 4: sigma_tau 敏感性(最优配置) ----------
    print(f"\n=== Part 4: sigma_tau sensitivity at best config ===")
    mics = mic_array(best["R_mm"] * 1e-3, "hex", best["dz_mm"] * 1e-3)
    s_true = np.array([0.0, 0.0, -best["H_mm"] * 1e-3])
    print("sigma_tau(us) rmse3d(mm) rmse_zB(mm)")
    for sig in (3e-6, 5e-6, 8e-6, 10e-6):
        r3, _, _, rzB, _ = mc_localize(mics, s_true, best["alpha_deg"], sigma_tau=sig)
        print(f"   {sig*1e6:5.1f}      {r3:6.2f}    {rzB:6.2f}")


if __name__ == "__main__":
    main()

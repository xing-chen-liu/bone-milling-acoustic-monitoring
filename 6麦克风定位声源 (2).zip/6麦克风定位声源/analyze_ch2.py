# -*- coding: utf-8 -*-
"""真实骨切削音频 ch2.wav 分析：频段能量分布 -> 定稿环半径 d"""
import numpy as np
from scipy.io import wavfile
from scipy import signal as sig

wav_path = r"c:\Users\刘星辰\.trae-cn\attachments\86f42a67-2bde-40d6-b1f0-addfac37d6fa_7da1ccd8-e886-4a9a-89c9-9dfd3f36d6f8_ch2.wav"
fs, x = wavfile.read(wav_path)
if x.ndim > 1:
    x = x[:, 0]
if np.issubdtype(x.dtype, np.integer):
    x = x.astype(np.float64) / np.iinfo(x.dtype).max
x = x - np.mean(x)
dur = len(x) / fs
print(f"[基本信息] 采样率 {fs} Hz | 时长 {dur:.2f} s | 点数 {len(x)} | 峰值 {np.max(np.abs(x)):.4f} (归一化)")

# ---- 时域: RMS 包络与事件分段 ----
win = int(0.010 * fs)
hop = int(0.005 * fs)
frames = [x[i:i+win] for i in range(0, len(x)-win, hop)]
rms = np.array([np.sqrt(np.mean(f**2)) for f in frames])
t_rms = np.arange(len(rms)) * hop / fs
noise_floor = np.percentile(rms, 10)
active = rms > max(4*noise_floor, 0.005)
idx = np.where(active)[0]
if len(idx):
    t_on, t_off = t_rms[idx[0]], t_rms[idx[-1]]
    print(f"[时域] 噪声底 RMS={noise_floor:.5f} | 切削段 {t_on:.2f}s -> {t_off:.2f}s "
          f"(持续 {t_off-t_on:.2f}s) | 最大 RMS={np.max(rms):.4f} @ {t_rms[np.argmax(rms)]:.2f}s")
    seg = slice(idx[0]*hop, min((idx[-1]+2)*hop, len(x)))
else:
    seg = slice(0, len(x))
    print("[时域] 未检出明显切削段, 用全段分析")

xs = x[seg]

# ---- 频域: PSD 与频段能量占比 ----
nper = 4096
f, P = sig.welch(xs, fs=fs, nperseg=nper, noverlap=nper//2)
P_tot = np.trapezoid(P, f) if hasattr(np, "trapezoid") else np.trapz(P, f)
bands = [(0,500),(500,1000),(1000,2000),(2000,4000),(4000,6000),(6000,8000),
         (8000,10000),(10000,12000),(12000,15000),(15000,20000),(20000, fs/2)]
print(f"[频段能量占比 | 分析段 {seg.start/fs:.2f}-{seg.stop/fs:.2f}s]")
for lo, hi in bands:
    if hi > fs/2:
        hi = fs/2
    m = (f >= lo) & (f < hi)
    e = np.trapezoid(P[m], f[m]) if hasattr(np, "trapezoid") else np.trapz(P[m], f[m])
    print(f"  {lo:6.0f}-{hi:6.0f} Hz : {100*e/P_tot:6.2f} %")

# 累积能量 90% / 95% / 99% 对应频率
cum = np.cumsum(np.concatenate([[0], np.diff(f) * (P[1:]+P[:-1])/2])) if True else None
cum = cum / cum[-1]
for q in (0.90, 0.95, 0.99):
    fq = f[np.searchsorted(cum, q)]
    print(f"  累积 {int(q*100)}% 能量频率 : {fq:.0f} Hz")

f_peak = f[np.argmax(P)]
sc = np.trapezoid(f*P, f) / P_tot if hasattr(np, "trapezoid") else np.trapz(f*P, f)/P_tot
print(f"[谱] 峰值频率 {f_peak:.0f} Hz | 谱质心 {sc:.0f} Hz")

# 5-9 kHz 状态区分频段占比(文献)
m59 = (f>=5000)&(f<9000)
e59 = np.trapezoid(P[m59], f[m59]) if hasattr(np, "trapezoid") else np.trapz(P[m59], f[m59])
print(f"[参考] 5-9 kHz(文献状态区分频段)能量占比: {100*e59/P_tot:.2f} %")

# ---- d 定稿判定 ----
print("\n[环半径 d 定稿判定 | 无混叠上限 f<=c/(2d), c=343 m/s]")
for d_mm in (12, 14, 16, 18, 20):
    fmax = 343.0 / (2*d_mm*1e-3) / 1e3
    m = f <= fmax*1e3
    e = np.trapezoid(P[m], f[m]) if hasattr(np, "trapezoid") else np.trapz(P[m], f[m])
    print(f"  d={d_mm:2d} mm -> f_max={fmax:5.2f} kHz, 覆盖能量 {100*e/P_tot:6.2f} %")

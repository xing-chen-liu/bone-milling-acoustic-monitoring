# -*- coding: utf-8 -*-
"""
S3: 波束定向提取仿真 (DAS vs MVDR, 定位误差容忍度)
合成: ch2 谱模板目标声 + 竞争声源 + 白噪, 新交错环(R=16, dz=±4, H=30)
频域窄带波束 1-10 kHz, 协方差由 30 帧估计, MVDR 对角加载 1e-2
扫描: 对准误差 delta = 0/2/5/10/20 mm (随机方向), 干扰 无/-6dB/0dB
指标: 输出信噪比增益(dB, 对单麦), 目标透射(理想 0 dB)
输出: s3_results.csv + s3_gain_curve.png + 控制台
"""
import numpy as np
from scipy.io import wavfile
from scipy.signal import welch
import csv, os

C = 343.0
FS = 96000
N = 2400
NFFT = 4096
K_FRAMES = 30
N_TRIAL = 8
SEED = 43
rng = np.random.default_rng(SEED)

MICS = np.array([[16, 0, 4], [8, 13.9, -4], [-8, 13.9, 4],
                 [-16, 0, -4], [-8, -13.9, 4], [8, -13.9, -4]], float)
SRC = np.array([0.0, 0.0, -30.0])
INTERF = np.array([40.0, 30.0, -20.0])

freqs = np.fft.fftfreq(NFFT, 1 / FS)
BAND = (np.abs(freqs) >= 1000) & (np.abs(freqs) <= 10000)


def load_psd_template():
    fs, x = wavfile.read(r"D:\bone\data\raw\session01\ch2.wav")
    seg = x[int(9.44 * fs):int(15.70 * fs)].astype(np.float64) / 32768.0
    f, P = welch(seg, fs=fs, nperseg=8192)
    Pint = np.interp(np.abs(freqs), f, P, left=P[0], right=P[-1] * 1e-4)
    return Pint


PSD = load_psd_template()


def colored_source():
    band = (np.abs(freqs) >= 300) & (np.abs(freqs) <= 22000)
    S = (rng.standard_normal(NFFT) + 1j * rng.standard_normal(NFFT)) * np.sqrt(PSD)
    S[~band] = 0
    s = np.fft.ifft(S).real[:N]
    return s / (np.std(s) + 1e-12)


def delays(pos):
    return np.linalg.norm(MICS - np.asarray(pos, float), axis=1) / 1000.0 / C


def frame_fft(pos, s):
    d = delays(pos)
    out = np.empty((6, NFFT), complex)
    for i in range(6):
        out[i] = np.fft.fft(s, NFFT) * np.exp(-2j * np.pi * freqs * d[i])
    return out


def steering(pos):
    d = delays(pos)
    return np.exp(-2j * np.pi * freqs[:, None] * d[None, :])   # (NFFT, 6)


def run_case(interf_db, delta_mm):
    gain_das, gain_mvdr, tx_das, tx_mvdr = [], [], [], []
    a_nom = steering(SRC)
    bins = np.where(BAND)[0]
    for _ in range(N_TRIAL):
        Xt = np.empty((K_FRAMES, 6, NFFT), complex)
        Xi = np.zeros_like(Xt)
        u = rng.standard_normal(3)
        p_hat = SRC + delta_mm * u / np.linalg.norm(u)        # 单位 mm, 对准误差 delta_mm
        for k in range(K_FRAMES):
            st = colored_source()
            Xt[k] = frame_fft(SRC, st)
            if interf_db is not None:
                si = colored_source()
                Xi[k] = frame_fft(INTERF, si) * 10 ** (interf_db / 20)
        # 白噪按带内每 bin 功率定 SNR = 10 dB (避免 Parseval 尺度错误)
        pbin = np.mean(np.abs(Xt[:, 0, bins]) ** 2)
        sigma_f = np.sqrt(pbin / 10.0)
        Xn = np.zeros_like(Xt)
        Xn[:, :, bins] = sigma_f * (rng.standard_normal((K_FRAMES, 6, len(bins)))
                                    + 1j * rng.standard_normal((K_FRAMES, 6, len(bins)))) / np.sqrt(2)
        X = Xt + Xi + Xn
        # 协方差(带内 bin)
        Xb = X[:, :, bins]                                   # (K,6,Fb)
        R = np.einsum('kif,kjf->fij', Xb, np.conj(Xb)) / K_FRAMES
        tr = np.trace(R, axis1=1, axis2=2).real / 6
        R = R + (1e-2 * tr)[:, None, None] * np.eye(6)[None]
        Rinv = np.linalg.inv(R)
        ab = a_nom[bins]                                     # (Fb,6) 无误差参考
        a_e = steering(p_hat)[bins]
        # DAS
        w_das = a_e / 6.0
        # MVDR
        Ri_a = np.einsum('fij,fj->fi', Rinv, a_e)
        den = np.einsum('fi,fi->f', np.conj(a_e), Ri_a)
        w_mvd = Ri_a / den[:, None]
        for w, g, t in ((w_das, gain_das, tx_das), (w_mvd, gain_mvdr, tx_mvdr)):
            Yt = np.einsum('fi,kif->kf', np.conj(w), Xt[:, :, bins])
            Yin = np.einsum('fi,kif->kf', np.conj(w), (Xi + Xn)[:, :, bins])
            snr_out = np.mean(np.abs(Yt) ** 2) / (np.mean(np.abs(Yin) ** 2) + 1e-30)
            snr_in = np.mean(np.abs(Xt[:, 0, bins]) ** 2) / \
                (np.mean(np.abs((Xi + Xn)[:, 0, bins]) ** 2) + 1e-30)
            g.append(10 * np.log10(snr_out / snr_in + 1e-30))
            t.append(10 * np.log10(np.mean(np.abs(Yt) ** 2) /
                                   (np.mean(np.abs(Xt[:, 0, bins]) ** 2) + 1e-30) + 1e-30))
    return (float(np.mean(gain_das)), float(np.mean(gain_mvdr)),
            float(np.mean(tx_das)), float(np.mean(tx_mvdr)))


def main():
    rows = []
    print("干扰条件      delta(mm)   DAS增益  MVDR增益  DAS透射  MVDR透射   (dB)")
    for tag, idb in (("无干扰", None), ("干扰-6dB", -6), ("干扰0dB", 0)):
        for delta in (0, 2, 5, 10, 20):
            g_d, g_m, t_d, t_m = run_case(idb, delta)
            print(f"{tag:<12}{delta:>8}{g_d:>10.2f}{g_m:>10.2f}{t_d:>9.2f}{t_m:>9.2f}")
            rows.append(dict(interf=tag, delta_mm=delta,
                             das_gain_db=round(g_d, 2), mvdr_gain_db=round(g_m, 2),
                             das_tx_db=round(t_d, 2), mvdr_tx_db=round(t_m, 2)))
    out = os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results"), "s3_results.csv")
    with open(out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["interf", "delta_mm", "das_gain_db",
                                          "mvdr_gain_db", "das_tx_db", "mvdr_tx_db"])
        w.writeheader(); w.writerows(rows)
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(8, 4.2))
        for tag, en, mk in (("无干扰", "no-interf", "o"), ("干扰-6dB", "intf-6dB", "s"),
                            ("干扰0dB", "intf0dB", "^")):
            rr = [r for r in rows if r["interf"] == tag]
            xs = [r["delta_mm"] for r in rr]
            ax.plot(xs, [r["das_gain_db"] for r in rr], mk + "--", label=f"DAS {en}")
            ax.plot(xs, [r["mvdr_gain_db"] for r in rr], mk + "-", label=f"MVDR {en}")
        ax.set_xlabel("steering error delta (mm)")
        ax.set_ylabel("array gain over single mic (dB)")
        ax.set_title("S3: beamforming gain vs localization error")
        ax.legend(fontsize=8); ax.grid(alpha=0.3)
        fig.tight_layout()
        fig.savefig(os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results"),
                                 "s3_gain_curve.png"), dpi=130)
        plt.close(fig)
    except Exception as e:
        print(f"(绘图跳过: {e})")
    print(f"\n结果 -> {out}")


if __name__ == "__main__":
    main()

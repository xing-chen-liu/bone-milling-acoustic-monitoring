# -*- coding: utf-8 -*-
"""
M1b: 宽窗 TDOA 重估 + 物理通道排列反推
目标:
  1) 用 ±45 采样宽窗(覆盖 40mm 全基线)重估 15 对时延, 消除 M1 的搜索窗顶格假象;
  2) 闭合误差复查(几何+偏移无关的估计质量);
  3) 720 种通道排列 x 声源位置网格搜索 -> 反推物理排列与声源位置,
     解决 README"延时模板超出声程几何上限"遗留问题。
输出: 控制台报告 + m1b_results.csv
"""
import numpy as np
from scipy.io import wavfile
import csv, os, itertools

C = 343.0
D_ADJ = 0.008
FS_EXPECT = 352800
FRAME = 8192
HOP = 4096
MAX_LAG = 45          # ±127.5 us, 覆盖 40mm 基线(116.6us)
BANDS = {"1-10kHz": (1000.0, 10000.0), "0.3-20kHz": (300.0, 20000.0)}
BASE = r"D:\bone\data\raw"
SESSIONS = ["session01", "session02"]
PAIRS = [(i, j) for i in range(6) for j in range(i + 1, 6)]
TRIPLES = [(i, j, k) for i in range(6) for j in range(i + 1, 6) for k in range(j + 1, 6)]


def load_session(name):
    chans = []
    for c in range(1, 7):
        fs, x = wavfile.read(os.path.join(BASE, name, f"ch{c}.wav"))
        if fs != FS_EXPECT:
            raise RuntimeError(f"fs={fs}")
        chans.append(x.astype(np.float32) / 32768.0)
    N = min(len(x) for x in chans)
    return np.stack([x[:N] for x in chans])


def detect_active(x, fs):
    win = int(0.010 * fs)
    mono = np.mean(x, axis=0)
    n = len(mono) // win
    rms = np.sqrt(np.mean(mono[:n*win].reshape(n, win) ** 2, axis=1))
    floor = np.percentile(rms, 10)
    idx = np.where(rms > max(4 * floor, 1e-4))[0]
    return idx[0] * win / fs, (idx[-1] + 1) * win / fs


def gcc_phat_tau(Fi, Fj, mask, max_lag):
    G = Fi * np.conj(Fj) * mask
    G /= (np.abs(G) + 1e-12)
    cc = np.fft.ifft(G).real
    seg = np.concatenate((cc[-max_lag:], cc[:max_lag + 1]))
    k = int(np.argmax(seg))
    tau = k - max_lag
    if 0 < k < len(seg) - 1:
        y0, ym, yp = seg[k], seg[k - 1], seg[k + 1]
        den = ym - 2 * y0 + yp
        if abs(den) > 1e-18:
            tau = tau + 0.5 * (ym - yp) / den
    return tau / FS_EXPECT


def session_medians(x, fs, name, out_rows):
    t0, t1 = detect_active(x, fs)
    starts = np.arange(int(t0 * fs), int(t1 * fs) - FRAME, HOP)
    nfft = FRAME
    freqs = np.fft.fftfreq(nfft, 1 / fs)
    F = np.zeros((len(starts), 6, nfft), dtype=np.complex64)
    for fi, s in enumerate(starts):
        for ch in range(6):
            F[fi, ch] = np.fft.fft(x[ch, s:s + nfft])
    meds = {}
    print(f"\n=== {name}: 活跃段 {t0:.2f}-{t1:.2f} s, {len(starts)} 帧 ===")
    for bname, (lo, hi) in BANDS.items():
        mask = ((np.abs(freqs) >= lo) & (np.abs(freqs) <= hi)).astype(np.float64)
        taus = np.zeros((len(starts), 15))
        for pi, (i, j) in enumerate(PAIRS):
            for fi in range(len(starts)):
                taus[fi, pi] = gcc_phat_tau(F[fi, i], F[fi, j], mask, MAX_LAG)
        med = np.median(taus, axis=0)
        meds[bname] = med
        print(f"\n-- {bname} --")
        print("pair  tau_med(us)  sigma_c(us)  达窗边?")
        for pi, (i, j) in enumerate(PAIRS):
            t = taus[:, pi]
            sig = np.std(t - np.median(t)) * 1e6
            edge = "窗边!" if abs(med[pi] * 1e6) > (MAX_LAG - 1) / FS_EXPECT * 1e6 else ""
            print(f"({i+1},{j+1})  {med[pi]*1e6:+8.2f}   {sig:7.2f}   {edge}")
            out_rows.append(dict(session=name, band=bname, pair=f"{i+1}-{j+1}",
                                 tau_med_us=round(med[pi] * 1e6, 3),
                                 sigma_us=round(sig, 3)))
        # 闭合误差
        cls = []
        for (i, j, k) in TRIPLES:
            e = med[PAIRS.index((i, j))] + med[PAIRS.index((j, k))] - med[PAIRS.index((i, k))]
            cls.append(e * 1e6)
        cl = np.array(cls)
        print(f"闭合误差(中位): std={np.std(cl):.2f} us  |max|={np.max(np.abs(cl)):.1f} us")
        out_rows.append(dict(session=name, band=bname, pair="CLOSURE",
                             tau_med_us="", sigma_us=round(float(np.std(cl)), 3)))
    return meds


def fit_permutation(med):
    """720 排列 x 声源网格: 拟合 m_ij ~ (r_i - r_j)/c, r_i=sqrt((p_i-x)^2+y^2)"""
    xs = np.arange(-60, 161, 5.0)     # mm
    ys = np.arange(20, 401, 5.0)      # mm
    GX, GY = np.meshgrid(xs, ys, indexing="ij")
    G = np.stack([GX.ravel(), GY.ravel()], axis=1)   # (G,2)
    results = []
    for perm in itertools.permutations(range(6)):
        p = np.array(perm, float) * 8.0               # 位置 mm
        r = np.sqrt((p[None, :] - G[:, 0:1]) ** 2 + G[:, 1:2] ** 2)   # (G,6) mm
        resid = np.empty((len(G), 15))
        for pi, (i, j) in enumerate(PAIRS):
            pred = (r[:, i] - r[:, j]) * 1e-3 / C * 1e6      # mm->m, us
            resid[:, pi] = med[pi] * 1e6 - pred
        rmse = np.sqrt(np.mean(resid ** 2, axis=1))
        b = int(np.argmin(rmse))
        results.append((float(rmse[b]), perm, float(G[b, 0]), float(G[b, 1])))
    results.sort()
    return results[:5]


def main():
    out_rows = []
    meds = {}
    for name in SESSIONS:
        x = load_session(name)
        meds[name] = session_medians(x, FS_EXPECT, name, out_rows)
        del x
    for bname in BANDS:
        print(f"\n############ 排列反推（{bname} 中位时延）############")
        for name in SESSIONS:
            top = fit_permutation(meds[name][bname])
            print(f"\n{name}:")
            for rmse, perm, xs, ys in top:
                print(f"  RMSE={rmse:6.2f} us  排列(文件ch1..ch6→物理槽位)={perm}  "
                      f"声源 x={xs:.0f} mm  y={ys:.0f} mm")
            print(f"  [对照] 顺序排列(0,1,2,3,4,5)的最优 RMSE: ", end="")
            p = np.arange(6) * 8.0
            xs = np.arange(-60, 161, 5.0); ys = np.arange(20, 401, 5.0)
            GX, GY = np.meshgrid(xs, ys, indexing="ij")
            G = np.stack([GX.ravel(), GY.ravel()], axis=1)
            r = np.sqrt((p[None, :] - G[:, 0:1]) ** 2 + G[:, 1:2] ** 2)
            resid = np.empty((len(G), 15))
            for pi, (i, j) in enumerate(PAIRS):
                pred = (r[:, i] - r[:, j]) / C * 1e6
                resid[:, pi] = meds[name][bname][pi] * 1e6 - pred
            rmse_id = float(np.min(np.sqrt(np.mean(resid ** 2, axis=1))))
            print(f"{rmse_id:.2f} us")
    out = os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results"), "m1b_results.csv")
    with open(out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["session", "band", "pair", "tau_med_us", "sigma_us"])
        w.writeheader(); w.writerows(out_rows)
    print(f"\n结果 -> {out}")


if __name__ == "__main__":
    main()

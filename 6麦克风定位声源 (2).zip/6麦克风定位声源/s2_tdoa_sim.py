# -*- coding: utf-8 -*-
"""
S2: 时延估计仿真 (信号级, 推导 sigma_tau)
合成: ch2.wav 真实切削谱模板 -> 新交错环几何(R=16, dz=±4, H=30)真值时差
退化模型(M1 实测): 白噪 SNR 扫描 / 多径回波(峰跳跃) / 结构声早到相干分量
估计器对比: GCC / GCC-PHAT / GCC-SCOT / GCC-Roth, 频段: 1-10k / 5-9k / 0.3-20k
指标: sigma_tau(std), bias, 粗差率(|err|>15us)
输出: s2_results.csv + 控制台报告
"""
import numpy as np
from scipy.io import wavfile
from scipy.signal import welch
import csv, os

C = 343.0
FS = 96000                 # 设计采样率
N = 2400                   # 25 ms 帧
NFFT = 4096
MAX_LAG = 12               # ±125 us 搜索窗(含可捕获回波)
N_TRIAL = 200
SEED = 42
rng = np.random.default_rng(SEED)

# --- 新交错环几何(A系) ---
MICS = np.array([[16, 0, 4], [8, 13.9, -4], [-8, 13.9, 4],
                 [-16, 0, -4], [-8, -13.9, 4], [8, -13.9, -4]], float)  # mm
SRC = np.array([0.0, 0.0, -30.0])     # mm 名义声源
PAIRS = [(i, j) for i in range(6) for j in range(i + 1, 6)]

freqs = np.fft.fftfreq(NFFT, 1 / FS)
t_idx = np.arange(N)


def true_taus():
    r = np.linalg.norm(MICS - SRC, axis=1) / 1000.0     # m
    return np.array([(r[i] - r[j]) / C for (i, j) in PAIRS]), r


def load_psd_template():
    fs, x = wavfile.read(r"D:\bone\data\raw\session01\ch2.wav")
    seg = x[int(9.44 * fs):int(15.70 * fs)].astype(np.float64) / 32768.0
    f, P = welch(seg, fs=fs, nperseg=8192)
    grid = np.abs(freqs)
    Pint = np.interp(grid, f, P, left=P[0], right=P[-1] * 1e-4)
    return Pint


PSD = load_psd_template()


def colored_source():
    """谱模板着色的高斯源信号 (0.3-22 kHz)"""
    band = (np.abs(freqs) >= 300) & (np.abs(freqs) <= 22000)
    S = (rng.standard_normal(NFFT) + 1j * rng.standard_normal(NFFT)) * np.sqrt(PSD)
    S[~band] = 0
    s = np.fft.ifft(S).real[:N]
    return s / (np.std(s) + 1e-12)


def delay(sig, dt):
    """FFT 分数时延"""
    S = np.fft.fft(sig, NFFT)
    return np.fft.ifft(S * np.exp(-2j * np.pi * freqs * dt)).real[:N]


def synth(tau_pair, r, snr_db, echoes=(), struct=None, extra_srcs=(), src_pos=None):
    s = colored_source()
    x = np.zeros((6, N))
    sp = SRC if src_pos is None else np.asarray(src_pos, float)
    r0 = np.linalg.norm(MICS - sp, axis=1) / 1000.0
    for i in range(6):
        d = r0[i] / C
        x[i] = delay(s, d)                       # 直达
        for (amp_db, dt) in echoes:              # 回波(每通道微扰)
            a = 10 ** (amp_db / 20) * (1 + 0.15 * rng.standard_normal())
            x[i] += a * delay(s, d + dt * (1 + 0.05 * rng.standard_normal()))
        if struct is not None:
            amp_db, lead = struct                 # 结构声: 早到 lead 秒, 各通道近似等延迟
            a = 10 ** (amp_db / 20)
            x[i] += a * delay(s, d - lead + 2e-6 * rng.standard_normal())
        for (pos, amp_db) in extra_srcs:          # 竞争声源(如主轴/电机)
            rr = np.linalg.norm(np.asarray(pos, float) - MICS[i]) / 1000.0
            x[i] += 10 ** (amp_db / 20) * delay(s, rr / C)
    # 噪声: 按直达分量功率定 SNR
    p_sig = np.mean(x[0] ** 2) * 0.7             # 近似直达功率
    sigma = np.sqrt(p_sig / 10 ** (snr_db / 10))
    x += sigma * rng.standard_normal(x.shape)
    return x


def est_tau(x, kind, band):
    lo, hi = band
    m = (np.abs(freqs) >= lo) & (np.abs(freqs) <= hi)
    X = np.fft.fft(x, NFFT, axis=1)
    out = np.zeros(len(PAIRS))
    for pi, (i, j) in enumerate(PAIRS):
        G = X[i] * np.conj(X[j])
        if kind == "gcc":
            W = 1.0
        elif kind == "phat":
            W = 1.0 / (np.abs(G) + 1e-12)
        elif kind == "scot":
            k = 15
            si = np.convolve(np.abs(X[i]) ** 2, np.ones(k) / k, mode="same")
            sj = np.convolve(np.abs(X[j]) ** 2, np.ones(k) / k, mode="same")
            W = 1.0 / (np.sqrt(si * sj) + 1e-12)
        elif kind == "roth":
            k = 15
            si = np.convolve(np.abs(X[i]) ** 2, np.ones(k) / k, mode="same")
            W = 1.0 / (si + 1e-12)
        R = np.fft.ifft(G * W * m).real
        seg = np.concatenate((R[-MAX_LAG:], R[:MAX_LAG + 1]))
        k2 = int(np.argmax(seg))
        tau = k2 - MAX_LAG
        if 0 < k2 < len(seg) - 1:
            y0, ym, yp = seg[k2], seg[k2 - 1], seg[k2 + 1]
            den = ym - 2 * y0 + yp
            if abs(den) > 1e-18:
                tau += 0.5 * (ym - yp) / den
        out[pi] = tau / FS
    return out


ESTS = ["gcc", "phat", "scot", "roth"]
BANDS = {"1-10kHz": (1000, 10000), "5-9kHz": (5000, 9000), "0.3-20kHz": (300, 20000)}
CONDS = [
    ("C0 clean 20dB", dict(snr_db=20)),
    ("C1 clean 10dB", dict(snr_db=10)),
    ("C2 clean 5dB", dict(snr_db=5)),
    ("C3 clean 0dB", dict(snr_db=0)),
    ("C4 echo-light", dict(snr_db=10, echoes=(( -10, 120e-6),))),
    ("C5 echo-heavy", dict(snr_db=10, echoes=((-8, 80e-6), (-12, 180e-6), (-16, 320e-6)))),
    ("C6 struct-early", dict(snr_db=10, struct=(-10, 35e-6))),
    ("C7 echo+struct", dict(snr_db=10, echoes=((-10, 120e-6),), struct=(-10, 35e-6))),
    ("C8 strong-echo", dict(snr_db=10, echoes=((-3, 60e-6),))),
    ("C9 dual-source", dict(snr_db=10, extra_srcs=(((30, 20, -25), 0),))),
]


def run_condition(tag, kw, band=(1000, 10000), ests=ESTS):
    tau_true, r = true_taus()
    errs = {e: [] for e in ests}
    for _ in range(N_TRIAL):
        x = synth(None, r, **kw)
        for e in ests:
            errs[e].append(est_tau(x, e, band) - tau_true)
    rows = []
    for e in ests:
        E = np.concatenate(errs[e]) * 1e6
        sig = float(np.std(E)); bias = float(np.mean(E))
        out = float(np.mean(np.abs(E) > 15) * 100)
        rows.append((tag, e, f"{band[0]/1000:g}-{band[1]/1000:g}k", sig, bias, out))
    return rows


def main():
    all_rows = []
    print("条件                 估计器   频段      sigma(us)  bias(us)  粗差%")
    for tag, kw in CONDS:
        for (t, e, b, s, bi, o) in run_condition(tag, kw):
            print(f"{t:<20}{e:<8}{b:<9}{s:>8.2f}{bi:>10.2f}{o:>8.1f}")
            all_rows.append(dict(cond=t, est=e, band=b,
                                 sigma_us=round(s, 3), bias_us=round(bi, 3),
                                 outlier_pct=round(o, 1)))
    # 颦段对比(C1 条件, 全估计器)
    print("\n-- 频段对比 (C1 clean 10dB) --")
    for bname, band in BANDS.items():
        for (t, e, b, s, bi, o) in run_condition("C1-band", dict(snr_db=10), band=band):
            print(f"{t:<20}{e:<8}{b:<9}{s:>8.2f}{bi:>10.2f}{o:>8.1f}")
            all_rows.append(dict(cond=t, est=e, band=b,
                                 sigma_us=round(s, 3), bias_us=round(bi, 3),
                                 outlier_pct=round(o, 1)))
    out = os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results"), "s2_results.csv")
    with open(out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["cond", "est", "band", "sigma_us",
                                          "bias_us", "outlier_pct"])
        w.writeheader(); w.writerows(all_rows)
    print(f"\n结果 -> {out}")


if __name__ == "__main__":
    main()

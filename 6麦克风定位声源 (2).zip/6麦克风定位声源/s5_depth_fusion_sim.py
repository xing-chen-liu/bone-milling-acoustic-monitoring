# -*- coding: utf-8 -*-
"""
S5: 深度回归 + 卡尔曼融合仿真
物理模型: 剩余壁厚 w 递减 -> 谱质心升 / 低频比降(幂律), M3 实测 CV 做噪声;
工况扰动: 转速/进给系数; 回归: 对数域线性化 + 岭回归(留一工况交叉验证);
融合: 卡尔曼双观测(z_geo sigma=10mm(S1 CRLB) + 声学 sigma=回归残差);
场景: 正常 / 声学标定漂移(z_geo 兜底)。验收: MAE<=1.5mm 且融合优于单路。
输出: s5_results.csv + s5_traj.png + 控制台
"""
import numpy as np
import csv, os

W0 = 8.0            # mm 初始壁厚
SEED = 45
rng = np.random.default_rng(SEED)


def trajectory(feed_f, rpm_f, n=160, dt=0.05):
    """w(t) 线性递减(进给), 返回 w 序列"""
    feed = 1.0 * feed_f        # mm/s
    w = W0 - feed * dt * np.arange(n)
    return np.clip(w, 0.02, None)


def observe(w, feed_f, rpm_f):
    """物理特征观测(幂律 + 工况系数 + 噪声, CV 按 M3 实测)"""
    n = len(w)
    x1 = 1200 * (W0 / w) ** 0.5 * (1 + 0.15 * (rpm_f - 1)) \
        * (1 + 0.10 * (feed_f - 1)) * (1 + 0.24 * rng.standard_normal(n))  # centroid
    x2 = 0.85 * (w / W0) ** 0.6 * (1 - 0.10 * (rpm_f - 1)) \
        * (1 + 0.04 * rng.standard_normal(n))                              # low_ratio
    x3 = -30 + 2.5 * np.log10(W0 / w) * feed_f \
        * (1 + 0.03 * rng.standard_normal(n))                              # log_rms
    return np.stack([x1, x2, x3], axis=1)


def design(F):
    """对数域线性化设计矩阵(幂律 -> 线性): log(centroid), log(low_ratio), log_rms(dB)"""
    return np.column_stack([np.ones(len(F)), np.log(F[:, 0]), np.log(F[:, 1]), F[:, 2]])


def ridge_fit(F, w, lam=1.0):
    X = design(F); y = np.log(w)
    A = X.T @ X + lam * np.eye(X.shape[1])
    beta = np.linalg.solve(A, X.T @ y)
    res = np.std(y - X @ beta)
    return beta, res


def ridge_pred(F, beta):
    return np.exp(design(F) @ beta)


def kalman(z_geo, w_ac, sig_ac, Q=0.05 ** 2, R_geo=10.0 ** 2, adaptive=False):
    """adaptive: 新息监控 - z_geo 与声学持续分歧(>3sigma, 20帧)时膨胀 R_ac(声学失效兜底)"""
    n = len(z_geo)
    w_est = np.empty(n); P = 10.0
    x = z_geo[0]
    R_ac = sig_ac ** 2
    dis = 0
    for k in range(n):
        P += Q
        if adaptive:
            if abs(z_geo[k] - w_ac[k]) > 3 * np.sqrt(sig_ac ** 2 + 10.0 ** 2):
                dis += 1
            else:
                dis = 0
            R_ac = sig_ac ** 2 * (1000.0 if dis > 20 else 1.0)
        K1 = P / (P + R_geo)
        x = x + K1 * (z_geo[k] - x); P = (1 - K1) * P
        K2 = P / (P + R_ac)
        x = x + K2 * (w_ac[k] - x); P = (1 - K2) * P
        w_est[k] = x
    return w_est


CONDS = [(1.0, 1.0), (0.9, 1.15), (1.15, 0.85)]


def main():
    # 留一工况交叉验证
    mae_ac, mae_geo, mae_fus, mae_fus_drift, mae_ac_drift = [], [], [], [], []
    mae_ac_fail, mae_fus_fail, mae_fusa_fail = [], [], []
    for hold in range(3):
        train = [c for i, c in enumerate(CONDS) if i != hold]
        Fs, ws = [], []
        for (ff, rf) in train:
            w = trajectory(ff, rf)
            Fs.append(observe(w, ff, rf)); ws.append(w)
        beta, sig = ridge_fit(np.vstack(Fs), np.concatenate(ws))
        # 测试工况
        ff, rf = CONDS[hold]
        w_true = trajectory(ff, rf)
        F = observe(w_true, ff, rf)
        w_ac = ridge_pred(F, beta)
        z_geo = w_true + 10.0 * rng.standard_normal(len(w_true))
        # 场景a: 正常
        fus = kalman(z_geo, w_ac, sig)
        # 场景b: 声学标定漂移 +2mm 线性
        drift = np.linspace(0, 2.0, len(w_true))
        w_ac_d = w_ac + drift
        fus_d = kalman(z_geo, w_ac_d, sig)
        mae_ac.append(np.mean(np.abs(w_ac - w_true)))
        mae_geo.append(np.mean(np.abs(z_geo - w_true)))
        mae_fus.append(np.mean(np.abs(fus - w_true)))
        mae_fus_drift.append(np.mean(np.abs(fus_d - w_true)))
        mae_ac_drift.append(np.mean(np.abs(w_ac_d - w_true)))
        # 场景c: 声学严重失效(标定崩坏, 偏置增至 10mm), 固定权重 vs 新息自适应
        fail = np.linspace(0, 10.0, len(w_true))
        w_ac_f = w_ac + fail
        fus_f = kalman(z_geo, w_ac_f, sig)
        fus_fa = kalman(z_geo, w_ac_f, sig, adaptive=True)
        mae_ac_fail.append(np.mean(np.abs(w_ac_f - w_true)))
        mae_fus_fail.append(np.mean(np.abs(fus_f - w_true)))
        mae_fusa_fail.append(np.mean(np.abs(fus_fa - w_true)))
        if hold == 0:
            traj = (w_true, z_geo, w_ac, fus)

    def fmt(v):
        return f"MAE {np.mean(v):.2f} ± {np.std(v):.2f} mm"

    print("留一工况交叉验证 (3 折):")
    print(f"  仅声学回归      {fmt(mae_ac)}")
    print(f"  仅几何 z_geo    {fmt(mae_geo)}")
    print(f"  卡尔曼融合      {fmt(mae_fus)}")
    print(f"  [漂移场景] 仅声学 {fmt(mae_ac_drift)}")
    print(f"  [漂移场景] 融合  {fmt(mae_fus_drift)}")
    print(f"  [严重失效偏置->10mm] 仅声学        {fmt(mae_ac_fail)}")
    print(f"  [严重失效] 融合(固定权重)          {fmt(mae_fus_fail)}")
    print(f"  [严重失效] 融合(新息自适应)        {fmt(mae_fusa_fail)}")

    rows = [dict(method="acoustic_only", mae_mm=round(float(np.mean(mae_ac)), 3)),
            dict(method="geo_only", mae_mm=round(float(np.mean(mae_geo)), 3)),
            dict(method="fused", mae_mm=round(float(np.mean(mae_fus)), 3)),
            dict(method="acoustic_drift", mae_mm=round(float(np.mean(mae_ac_drift)), 3)),
            dict(method="fused_drift", mae_mm=round(float(np.mean(mae_fus_drift)), 3)),
            dict(method="acoustic_fail10", mae_mm=round(float(np.mean(mae_ac_fail)), 3)),
            dict(method="fused_fail10_fixed", mae_mm=round(float(np.mean(mae_fus_fail)), 3)),
            dict(method="fused_fail10_adaptive", mae_mm=round(float(np.mean(mae_fusa_fail)), 3))]
    out = os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results"), "s5_results.csv")
    with open(out, "w", newline="", encoding="utf-8-sig") as f:
        wcsv = csv.DictWriter(f, fieldnames=["method", "mae_mm"])
        wcsv.writeheader(); wcsv.writerows(rows)

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        w_true, z_geo, w_ac, fus = traj
        t = np.arange(len(w_true)) * 0.05
        fig, ax = plt.subplots(figsize=(9, 4.2))
        ax.plot(t, w_true, "k-", lw=2, label="true w")
        ax.plot(t, z_geo, ".", ms=2, color="#888888", label="z_geo (CRLB 10mm)")
        ax.plot(t, w_ac, "-", lw=1, color="#E67E22", label="acoustic ridge")
        ax.plot(t, fus, "-", lw=1.5, color="#02743B", label="kalman fused")
        ax.set_xlabel("time (s)"); ax.set_ylabel("remaining wall w (mm)")
        ax.set_title("S5: depth estimation, leave-one-condition-out")
        ax.legend(fontsize=8); ax.grid(alpha=0.3)
        fig.tight_layout()
        fig.savefig(os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results"),
                                 "s5_traj.png"), dpi=130)
        plt.close(fig)
    except Exception as e:
        print(f"(绘图跳过: {e})")
    print(f"\n结果 -> {out}")


if __name__ == "__main__":
    main()

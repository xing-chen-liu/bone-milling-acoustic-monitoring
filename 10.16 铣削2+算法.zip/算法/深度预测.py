# -*- coding: utf-8 -*-
"""用 算法\\depth_model.json（第一次版模型）识别 tem\\1-7.txt"""
import csv
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
sys_path = os.path.dirname(BASE)
import sys
sys.path.insert(0, sys_path)
from depth_recognition import DepthRecognizer, compute_all_features

for f in ["Microsoft YaHei", "SimHei", "SimSun"]:
    try:
        matplotlib.rcParams["font.sans-serif"] = [f]
        break
    except Exception:
        continue
matplotlib.rcParams["axes.unicode_minus"] = False

SRC = os.path.join(sys_path, "tem")
OUT = os.path.join(BASE, "tem_results")
os.makedirs(OUT, exist_ok=True)

rec = DepthRecognizer(os.path.join(BASE, "depth_model.json"))
labels = {"rms": "RMS幅值", "p_0p5_170k": "总功率(0.5-170k)",
          "b_8_20k": "8-20kHz频带能量", "ratio_8_60k": "8-60k占比"}

rows = []
for i in range(1, 8):
    x = np.loadtxt(os.path.join(SRC, f"{i}.txt"), dtype=np.float64)
    x = x - x.mean()
    feats = compute_all_features(x, 0, len(x))
    d = max(rec.recognize(feats), 0.0)
    rows.append([f"tem{i}", d, feats])

    fig, axes = plt.subplots(5, 1, figsize=(7.5, 7.5))
    for ax, (k, lbl) in zip(axes[:4], labels.items()):
        ax.bar([f"tem{i}"], [feats[k]], color="#1f77b4")
        ax.set_ylabel(lbl, fontsize=9)
    axes[4].bar([f"tem{i}"], [d], color="#d62728")
    axes[4].set_ylabel("识别深度 (mm)", fontsize=9)
    axes[4].set_ylim(0, 1.2)
    fig.suptitle(f"tem{i} 识别深度: {d:.3f} mm  (第一次版模型)", fontsize=12)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, f"tem{i}_detail.png"), dpi=120)
    plt.close(fig)

with open(os.path.join(OUT, "tem_depth_summary.csv"), "w", newline="", encoding="utf-8-sig") as fh:
    w = csv.writer(fh)
    w.writerow(["group", "识别深度_mm", "RMS", "总功率0.5-170k", "8-20kHz能量", "8-60k占比"])
    for g, d, f in rows:
        w.writerow([g, f"{d:.4f}", f"{f['rms']:.6f}", f"{f['p_0p5_170k']:.4f}",
                    f"{f['b_8_20k']:.4f}", f"{f['ratio_8_60k']:.6f}"])

groups = [r[0] for r in rows]
depths = [r[1] for r in rows]
fig, ax = plt.subplots(figsize=(8.5, 5))
bars = ax.bar(groups, depths, color=plt.cm.viridis(np.linspace(0.2, 0.9, len(groups))))
for b, d in zip(bars, depths):
    ax.text(b.get_x() + b.get_width() / 2, d + 0.005, f"{d:.3f}", ha="center", fontsize=9)
ax.set_ylabel("识别深度 (mm)")
ax.set_title("tem 1-7 铣削深度识别（第一次版算法模型）")
ax.set_ylim(0, max(depths) * 1.25 + 0.05)
fig.tight_layout()
fig.savefig(os.path.join(OUT, "tem_depth_summary_bar.png"), dpi=130)
plt.close(fig)

print("=" * 40)
print("  tem 1-7 识别（第一次版模型）")
print("=" * 40)
for g, d, _f in rows:
    print(f"  {g} : {d:.4f} mm")
print("=" * 40)
print("结果目录:", OUT)
# -*- coding: utf-8 -*-
"""
铣削切割深度拟合算法（今日第一次版本，仅 10.7 主目录 14 段）
================================================================
输入:  10.7 目录下 1.txt ~ 14.txt（14 段 2s 音频，拼接成一条连续信号）
物理规律: 前 ~8.65s 空转(深度0) -> 匀速下切 0.1mm/s 持续10s -> 之后恒深 1.0mm
特征:   4 个声学特征 (RMS / 总功率0.5-170k / 8-20kHz频带能量 / 8-60k能量占比)
拟合:   加权最小二乘(线性回归) -> 得到 depth(mm) = w·特征 + b
输出:   depth_model.json + fit_curve.png + training_data.csv（保存到本文件所在目录）

用法:   E:\\python\\python.exe fit_depth_model.py
"""
import csv
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
for f in ["Microsoft YaHei", "SimHei", "SimSun"]:
    try:
        matplotlib.rcParams["font.sans-serif"] = [f]
        break
    except Exception:
        continue
matplotlib.rcParams["axes.unicode_minus"] = False

# ============ 参数（与原校准一致） ============
FS = 352800          # 采样率 Hz
NFFT = 8192          # FFT 点数
HOP = 4096           # 帧跳步（频谱平均用）
WIN_SEC = 2.0        # 窗口长度 s
HOP_SEC = 1.0        # 窗口步进 s
RATE_MM_S = 0.1      # 下切速率 mm/s
CUT_SECONDS = 10.0   # 下切持续时间 s
MAX_DEPTH = 1.0      # 恒深 mm
FEATURES = ("rms", "p_0p5_170k", "b_8_20k", "ratio_8_60k")


# ============ 底层工具 ============
def _make_hann(n):
    """汉宁窗"""
    return 0.5 - 0.5 * np.cos(2 * np.pi * np.arange(n) / (n - 1))


def compute_all_features(x, start, end=None):
    """在一个音频窗口上一次性算出四特征：rms / p_0p5_170k / b_8_20k / ratio_8_60k"""
    if end is None:
        end = len(x)
    seg = x[start:end]
    if seg.size == 0:
        return {k: 0.0 for k in FEATURES}
    rms = float(np.sqrt(np.mean(seg ** 2)))
    if seg.size < NFFT:
        return {"rms": rms, "p_0p5_170k": 0.0, "b_8_20k": 0.0, "ratio_8_60k": 0.0}

    win = _make_hann(NFFT)
    nframes = (seg.size - NFFT) // HOP + 1
    idx = start + np.arange(nframes)[:, None] * HOP + np.arange(NFFT)[None, :]
    frames = x[idx] * win[None, :]
    spec = np.fft.rfft(frames, NFFT, axis=1)
    psd = np.mean(spec.real ** 2 + spec.imag ** 2, axis=0)
    freqs = np.fft.rfftfreq(NFFT, 1 / FS)

    mb = (freqs >= 500) & (freqs < 170000)
    p_total = float(np.sum(psd[mb]))                                    # 总功率 0.5-170kHz
    b8 = float(np.sum(psd[(freqs >= 8000) & (freqs < 20000)]))          # 8-20kHz 频带能量
    r_8_60 = b8 + float(np.sum(psd[(freqs >= 20000) & (freqs < 60000)]))  # 8-60kHz 能量
    ratio = r_8_60 / p_total if p_total else 0.0                        # 8-60k 占比

    return {"rms": rms, "p_0p5_170k": p_total, "b_8_20k": b8, "ratio_8_60k": ratio}


def detect_onset(x):
    """短时 RMS 阈值法检测声音变化起点(切割开始时刻)"""
    rms_win = int(0.1 * FS)
    hop = int(0.02 * FS)
    n = (len(x) - rms_win) // hop + 1
    t_frames = (np.arange(n) * hop + rms_win / 2) / FS
    rms_curve = np.array([np.sqrt(np.mean(x[s:s + rms_win] ** 2))
                          for s in range(0, n * hop, hop)])
    baseline = np.median(rms_curve[: int(0.3 * len(rms_curve))])
    over = np.where(rms_curve > baseline * 1.5)[0]
    return t_frames[over[0]] if len(over) else 0.0


def slide_windows(x):
    """2s 窗口 / 1s 步进滑窗，返回 (窗口中心时间, 特征dict列表)"""
    win, stp = int(WIN_SEC * FS), int(HOP_SEC * FS)
    times, feats = [], []
    s = 0
    while s + win <= len(x):
        times.append((s + win / 2) / FS)
        feats.append(compute_all_features(x, s, s + win))
        s += stp
    return np.array(times), feats


# ============ 主流程：加载 14 段 -> 拼接 -> 拟合 ============
def main():
    data_dir = os.path.dirname(BASE)   # 14 段 txt 在 10.7 根目录
    parts = [np.loadtxt(os.path.join(data_dir, "%d.txt" % i), dtype=np.float64) for i in range(1, 15)]
    full = np.concatenate([p - p.mean() for p in parts])

    onset = detect_onset(full)
    times, feats = slide_windows(full)
    depth_true = np.minimum(np.maximum(0.0, (times - onset) * RATE_MM_S), MAX_DEPTH)

    X = np.array([[f[k] for k in FEATURES] for f in feats], dtype=float)
    y = depth_true
    A = np.column_stack([X, np.ones(len(X))])
    coef_all, *_ = np.linalg.lstsq(A, y, rcond=None)
    coef = {k: float(c) for k, c in zip(FEATURES, coef_all[:4])}
    intercept = float(coef_all[4])
    pred = A @ coef_all

    ss_res = float(np.sum((y - pred) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
    mae = float(np.mean(np.abs(y - pred)))
    print("=" * 50)
    print("  铣削深度拟合（今日第一次版 / 14段）")
    print("=" * 50)
    print("切割起点 onset = %.3f s（RMS阈值检测）" % onset)
    print("训练窗口数    = %d" % len(y))
    print("真实深度范围  = %.3f ~ %.3f mm" % (y.min(), y.max()))
    print("拟合质量: R²=%.4f  MAE=%.4f mm" % (r2, mae))
    print("模型公式: depth = %.4f" % intercept
          + " + %.4f*rms" % coef["rms"]
          + " + %.4g*p_0p5_170k" % coef["p_0p5_170k"]
          + " + %.4g*b_8_20k" % coef["b_8_20k"]
          + " + %.4f*ratio_8_60k" % coef["ratio_8_60k"])

    # 保存模型
    model = {"features": list(FEATURES), "coef": coef, "intercept": intercept,
             "onset_s": onset, "rate_mm_s": RATE_MM_S, "cut_seconds": CUT_SECONDS,
             "max_depth_mm": MAX_DEPTH, "n_windows": int(len(y)),
             "r2": r2, "mae": mae, "data": "10.7 main 14 segments (2s each)"}
    with open(os.path.join(BASE, "depth_model.json"), "w", encoding="utf-8") as fh:
        json.dump(model, fh, indent=2, ensure_ascii=False)
    print("模型已保存: %s\\depth_model.json" % BASE)

    # 训练数据 CSV
    with open(os.path.join(BASE, "training_data.csv"), "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["窗口中心时间_s", "真实深度_mm", "RMS", "总功率0.5-170k", "8-20kHz能量", "8-60k占比", "拟合深度_mm"])
        for t, yy, xx, pp in zip(times, y, X, pred):
            w.writerow(["%.3f" % t, "%.4f" % yy, "%.6f" % xx[0], "%.4f" % xx[1],
                        "%.4f" % xx[2], "%.6f" % xx[3], "%.4f" % pp])

    # 拟合效果图
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(times, y, "o-", ms=4, lw=1, color="k", label="真实深度（物理规律）")
    ax.plot(times, pred, "s--", ms=4, lw=1, color="#d62728", label="拟合预测深度")
    ax.axvline(onset, color="tab:blue", ls="--", lw=1, label="切割起点 %.2fs" % onset)
    ax.set_xlabel("窗口中心时间 (s)")
    ax.set_ylabel("深度 (mm)")
    ax.set_title("14 段拼接拟合效果  R²=%.4f  MAE=%.4f mm" % (r2, mae))
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(BASE, "fit_curve.png"), dpi=130)
    plt.close(fig)
    print("图示已保存: %s\\fit_curve.png" % BASE)


if __name__ == "__main__":
    main()

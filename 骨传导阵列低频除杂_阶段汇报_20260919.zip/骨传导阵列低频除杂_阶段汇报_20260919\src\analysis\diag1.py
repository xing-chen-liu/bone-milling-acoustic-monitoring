# -*- coding: utf-8 -*-
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from load_data import load_all, load_ref, CACHE
from scipy.signal import welch, coherence, csd, stft

FS = 352800.0
six = load_all().astype(np.float64)
raw = load_ref("raw", r"C:/Users/刘星辰/Desktop/bone/9.18/9.18/原音频.txt").astype(np.float64)
out = load_ref("out01", r"C:/Users/刘星辰/Desktop/bone/9.18/9.18/01 去噪结果.txt").astype(np.float64)
n = six.shape[1]
print(f"fs={FS} n={n} dur={n/FS:.3f}s  mics={six.shape[0]}")

print("\n--- channel stats ---")
for i in range(6):
    x = six[i]
    print(f"ch{i+1}: mean={x.mean():+.3e} std={x.std():.3e} ptp={np.ptp(x):.3e} "
          f"DC={x.mean():.2e} crest={np.ptp(x)/(np.sqrt((x**2).mean())*2+1e-12):.1f}")

print("\n--- raw vs ch1 (is 原音频 == a channel?) ---")
for i in range(6):
    c = np.corrcoef(raw[:n], six[i][:n])[0,1]
    print(f"corr(raw, ch{i+1}) = {c:+.4f}   ratio_rms={np.sqrt((raw**2).mean())/np.sqrt((six[i]**2).mean()):.3f}")
print(f"corr(raw, mean6)  = {np.corrcoef(raw[:n], six.mean(0))[0,1]:+.4f}")
print(f"corr(out, raw)    = {np.corrcoef(out[:n], raw)[0,1]:+.4f}")

bands = [(0,20),(20,50),(50,100),(100,200),(200,400),(400,800),(800,1600),
         (1600,3200),(3200,6400),(6400,12500),(12500,20000),(20000,40000),(40000,80000),(80000,176400)]
P, freqs = welch(six[0], fs=FS, nperseg=16384, noverlap=8192)
print("\n--- band energy share, ch1 (Welch, 16k seg) ---")
tot = np.trapezoid(P, freqs)
print(f"{'band':>14} {'Hz':>12} {'%E':>7} {'dB/Hz@fc':>10}")
for lo,hi in bands:
    m=(freqs>=lo)&(freqs<hi)
    if m.sum()<2: continue
    e=np.trapezoid(P[m],freqs[m])
    print(f"{lo:>6}-{hi:<7} {e/tot*100:11.3f} {10*np.log10(P[m].mean()+1e-30):9.1f} ")
print(f"total power={tot:.3e}  <20Hz={np.trapezoid(P[freqs<20],freqs[freqs<20])/tot*100:.3f}%  "
      f"<100Hz={np.trapezoid(P[freqs<100],freqs[freqs<100])/tot*100:.3f}%  "
      f"<400Hz={np.trapezoid(P[freqs<400],freqs[freqs<400])/tot*100:.3f}%")

print("\n--- top spectral peaks below 3kHz (ch1) ---")
m=(freqs>5)&(freqs<3000)
f2,freqs2 = freqs[m], freqs[m]
idx=np.argsort(P[m])[::-1]
seen=[]
for k in idx:
    fq=f2[k]
    if any(abs(fq-s)<40 for s in seen): continue
    seen.append(fq)
    print(f"  peak {fq:8.1f} Hz  {10*np.log10(P[m][k]+1e-30):7.1f} dB/Hz")
    if len(seen)>=12: break

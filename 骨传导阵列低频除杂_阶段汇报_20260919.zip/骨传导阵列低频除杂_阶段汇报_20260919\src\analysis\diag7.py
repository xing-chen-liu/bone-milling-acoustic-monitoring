# -*- coding: utf-8 -*-
"""抽取到语音带宽后, 用"宽频相位斜率回归"稳健估计各频带 ITD, 判定低频成分归属"""
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from scipy.signal import butter, sosfiltfilt, decimate, stft
six, raw = data(); n = six.shape[1]

# 抽取: 352800 -> 44100 (x8), 抗混叠 4阶 18kHz
def dec(x, q=8, fs=FS):
    sos = butter(8, (fs/q/2*0.9)/(fs/2), output='sos')
    return sosfiltfilt(sos, x)[::q]
FD = FS/8
d = np.stack([dec(six[i]) for i in range(6)])
ref_d = dec(raw)
print(f"抽取后 fs={FD}  n={d.shape[1]}  ch1 rms={np.sqrt((d[0]**2).mean()):.2e}")

f, t, Z = stft(d[0], fs=FD, nperseg=4096, noverlap=3072)
Zs = np.stack([stft(d[i], fs=FD, nperseg=4096, noverlap=3072)[2] for i in range(6)])
np.save(os.path.join(CACHE, "Z_dec.npy"), Zs.astype(np.complex64))
print(f"bin={FD/4096:.2f} Hz  nfreq={len(f)} frames={len(t)}")

print("\n=== 各频带 ITD (相位斜率回归, 单位: 44.1kHz 样本 / us / sin(theta)_farfield) ===")
d_far_8mm = 0.008/343.0*FD
print(f"  d_far(44.1k,8mm)={d_far_8mm:.3f} 样本")
print(f"{'pair':>7}{'20-60':>16}{'60-150':>16}{'150-400':>16}{'400-900':>16}{'900-2000':>16}{'2-4.5k':>16}{'4.5-9k':>16}")
def itd_reg(A, B, f, flo, fhi, w=None):
    m = (f >= flo) & (f <= fhi)
    if m.sum() < 4: return np.nan, 0
    A2=A[m]; B2=B[m]                      # (nbins, frames)
    dphi=np.angle(B2*np.conj(A2))
    ang=(2*np.pi*f[m])[:,None]
    ww=np.abs(A2)*np.abs(B2)
    num=np.sum(ww*dphi*ang,axis=0); den=np.sum(ww*ang*ang,axis=0)+1e-30
    tau=num/den                            # 每帧一个 ITD(秒)
    return float(-np.median(tau)*FD), m.sum()   # 样本(正=B晚于A)
res = {}
for i in range(5):
    row = f"ch{i+1}-{i+2}".rjust(7)
    for lo, hi in [(20,60),(60,150),(150,400),(400,900),(900,2000),(2000,4500),(4500,9000)]:
        tau, k = itd_reg(Zs[i], Zs[i+1], f, lo, hi)
        res.setdefault((lo,hi),[]).append(tau)
        row += f"{tau:>9.2f}({k})"
    print(row)
print("\n  各频带平均 sin(theta) = mean_tau / d_far :")
for (lo,hi),v in res.items():
    v=np.array(v); th=np.degrees(np.arcsin(np.clip(v.mean()/d_far_8mm,-1,1)))
    print(f"   {lo:>5.0f}-{hi:<5.0f} tau={v.mean():+6.2f}+-{v.std():.2f}  sin={v.mean()/d_far_8mm:+.3f}  theta={th:+6.1f}deg(远场等效)")
print("\n=== 参考(目标)在各频带的到达方向(用 ch1..ch6 vs ref 的回归) ===")
r = np.stack([stft(ref_d, fs=FD, nperseg=4096, noverlap=3072)[2]]*6)
for lo,hi in [(60,150),(150,400),(400,900),(900,2000),(2000,4500)]:
    taus=[]
    for i in range(6):
        tau,_=itd_reg(r[0],Zs[i],f,lo,hi); taus.append(tau)
    print(f"   {lo:>5.0f}-{hi:<5.0f} ref->ch2..6 tau = {np.round(taus[1:],2)}")

print("\n=== 低频(20-150Hz)时域结构: 每50ms能量(dB) ch1 ===")
lf = bp(d[0], 20, 150)
seg = int(0.05*FD)
e = np.array([np.log10((lf[k*seg:(k+1)*seg]**2).mean()+1e-20)*10 for k in range(len(lf)//seg)])
print("   ", np.round(e - e.max(), 1)[:60])
print(f"   LF峰均比={e.max()-np.median(e):.1f} dB ; mid(900-2000)对比:")
mid = bp(d[0], 900, 2000)
em = np.array([np.log10((mid[k*seg:(k+1)*seg]**2).mean()+1e-20)*10 for k in range(len(mid)//seg)])
print(f"   MID峰均比={em.max()-np.median(em):.1f} dB")

# -*- coding: utf-8 -*-
"""表征低频成分：方向、时频结构、以及去噪结果里低频到底是目标还是残留"""
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from load_data import load_all, load_ref
from scipy.signal import butter, sosfiltfilt, welch, fftconvolve
FS=352800.0; NCH=6
six=load_all().astype(np.float64); n=six.shape[1]
raw=load_ref("raw", r"C:/Users/刘星辰/Desktop/bone/9.18/9.18/原音频.txt").astype(np.float64)
old=load_ref("out01", r"C:/Users/刘星辰/Desktop/bone/9.18/9.18/01 去噪结果.txt").astype(np.float64)

def bp(x,lo,hi,order=4):
    sos=butter(order,np.array([lo,hi])/(FS/2),btype='band',output='sos')
    return sosfiltfilt(sos,x,axis=-1)
def hp(x,lo,order=4):
    sos=butter(order,lo/(FS/2),btype='high',output='sos')
    return sosfiltfilt(sos,x,axis=-1)

print("=== 1) 低频成分幅度 (带通 20-400Hz) vs 中频 (800-4000Hz) ===")
for i in range(6):
    lo=np.sqrt((bp(six[i],20,400)**2).mean()); mid=np.sqrt((bp(six[i],800,4000)**2).mean())
    print(f"  ch{i+1}: LF_rms={lo:.3e}  MID_rms={mid:.3e}  LF/MID={lo/mid*100:6.2f}%")

print("\n=== 2) 低频干涉方向：细分频段相邻对 GCC-TDOA(样本) ===")
def gcc(a,b,maxlag=400):
    x=a-a.mean(); y=b-b.mean()
    c=fftconvolve(x[::-1],y,mode='full'); L=len(c)//2
    seg=c[L-maxlag:L+maxlag]; j=int(np.argmax(np.abs(seg)))
    return j-maxlag, abs(seg[j])/np.sqrt((x**2).sum()*(y**2).sum()+1e-30)
d_far=0.008/343.0*FS
print(f"  远场相邻对最大TDOA d_far = {d_far:.2f} 样本 ({0.008/343*1e6:.1f} us)")
print(f"{'sub-band':>14}" + "".join(f"{'p%d'%(i+1):>14}" for i in range(5)) + "   sin(theta)   theta")
for lo,hi in [(25,60),(60,120),(120,250),(250,400),(400,800),(800,1600),(1600,3200),(3200,6400)]:
    row=f"{lo:>5.0f}-{hi:<8.0f}"; tds=[]
    for i in range(5):
        l,cc=gcc(bp(six[i],lo,hi),bp(six[i+1],lo,hi)); tds.append(l)
        row+=f"{l:>7d}({cc:.2f})".rjust(14)
    th=np.degrees(np.arcsin(np.clip(np.mean(tds)/d_far,-1,1)))
    row+=f"  {np.mean(tds)/d_far:+.3f}   {th:+6.1f}deg"
    print(row)

print("\n=== 3) 参考对齐稳定性：分段 best-lag (raw vs ch4) ===")
for k in range(6):
    s=slice(k*FS,(k+1)*FS)
    l,cc=gcc(raw[s],six[3][int(s.start):int(s.stop)],maxlag=200000,fb=None) if False else (None,None)
for k in range(6):
    a=raw[int(k*FS):int((k+1)*FS)]; b=six[3][int(k*FS):int((k+1)*FS)]
    x=bp(a,400,7000); y=bp(b,400,7000)
    c=fftconvolve(x[::-1],y,mode='full'); L=len(c)//2; ml=200000
    seg=c[L-ml:L+ml]; j=int(np.argmax(np.abs(seg)))
    print(f"  seg{k} [{k}-{k+1}s]: lag={j-ml:+7d} ({(j-ml)/FS*1e6:+9.1f} us) cc={abs(seg[j])/np.sqrt((x**2).sum()*(y**2).sum()):.3f}")

print("\n=== 4) 各频带相关性: 参考(clean target) vs 各输入通道 / vs 现有去噪结果 ===")
LAG=13609   # raw -> out01 global best lag (raw 领先)
ref_al = raw[LAG:LAG+n] if LAG>0 else raw   # shift raw to align with out
def nc(a,b):
    m=min(len(a),len(b)); a=a[:m]-a[:m].mean(); b=b[:m]-b[:m].mean()
    return float((a*b).sum()/(np.sqrt((a*a).sum()*(b*b).sum())+1e-30))
print(f"{'band':>13}{'ch1':>8}{'ch4':>8}{'ch6':>8}{'mean6':>8}{'out01':>8}")
for lo,hi in [(20,50),(50,100),(100,200),(200,400),(400,800),(800,1600),(1600,3200),(3200,6400),(6400,12500),(12500,19000)]:
    r=bp(ref_al,lo,hi)
    vals=[nc(r,bp(six[0],lo,hi)),nc(r,bp(six[3],lo,hi)),nc(r,bp(six[5],lo,hi)),
          nc(r,bp(six.mean(0),lo,hi)),nc(r,bp(old,lo,hi))]
    print(f"{lo:>5.0f}-{hi:<7.0f}"+"".join(f"{v:8.3f}" for v in vals))

# -*- coding: utf-8 -*-
import numpy as np, sys, os, time
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from alg02 import alg02
six, raw = data()
base = np.load(os.path.join(CACHE,"base.npy"))
NOMASK = dict(f_guard=0.0, lf_mode='none', hf_mode='none', sm_f=1, sm_t=1, sharp=1.0, floor_lf=0, floor_hf=0)
def run(tag, **kw):
    t0=time.time(); o=alg02(six, **kw); dt=time.time()-t0
    r=evaluate(o, raw, tag=f"{tag} [{dt:.1f}s]"); r['t']=dt; return o,r
print("\n--- 阶段A: 逐步叠加(先看 DS/前端 的贡献) ---")
run("A1 仅DS(无掩码,不抽取)", decim=1, fsub=0, **NOMASK)
run("A2 +抽取8", decim=8, fsub=0, **NOMASK)
run("A3 +高通25Hz", decim=8, fsub=25, **NOMASK)
run("A4 +守护带静音90Hz", decim=8, fsub=25, **{**NOMASK,'f_guard':90.0})
print("\n--- 阶段B: 低频帧级判决 ---")
run("B1 LF帧级(90-1200)", decim=8, fsub=25, lf_mode='frame', hf_mode='none', sm_f=1,sm_t=1,sharp=1.0,floor_hf=0)
run("B2 LF帧级+HF-CRLB掩码", decim=8, fsub=25, lf_mode='frame', hf_mode='sigma')
print("\n--- 阶段C: 模板对比 ---")
run("C1 模板=算法01", tmpl_override=[15.21,17.72,19.47,17.13,14.82])
run("C2 模板=GCC实测/8", tmpl_override=[16,17,17,15,13])
run("C3 模板=自动slope", lf_mode='frame', hf_mode='sigma')
for q in [0.5,0.65,0.8,0.9]:
    run(f"C4 qhi={q}", qhi=q)
for b in [(800,4000),(1200,6400),(2000,6400),(1200,9000),(400,2000)]:
    run(f"C5 band={b}", template_band=b)

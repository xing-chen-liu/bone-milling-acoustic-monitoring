﻿// 骨传导阵列低频除杂 —— 阶段汇报 PPT 生成
// 正式工作汇报风格 | 16:9 | PptxGenJS
import { pptx, ShapeType, ChartType } from './ppt.mjs';
import { C, F, PAGE, RHY } from './tokens.mjs';
import {
  header, footer, sourceNote, panel, accentBar, chip, numToken,
  table, takeaway, step, arrowRight,
} from './primitives.mjs';

pptx.layout = 'LAYOUT_WIDE';
pptx.author = '算法组';
pptx.subject = '六通道骨传导麦克风阵列低频除杂 阶段一/阶段二汇报';
pptx.title = '骨传导阵列低频除杂 阶段汇报';
pptx.company = '';
pptx.lang = 'zh-CN';
pptx.theme = {
  headFontFace: F.cn, bodyFontFace: F.cn, lang: 'zh-CN',
};

const { mx } = PAGE;
const CW = PAGE.w - 2 * mx;

// ---------- 数据 ----------
const BANDS = ['50-100', '100-200', '200-400', '400-800', '800-1600', '1600-3200', '3200-6400'];
const R = {
  DS:    [-22.34, -3.25, -7.73, -5.48, -6.36, -1.73, 2.56],
  BASE:  [-40.89, -5.63, -7.94, -4.19, -5.25, -4.97, -1.42],
  SLM:   [-14.14, -3.08, -7.77, -6.03, -7.45, -0.84, 1.87],
  JOINT: [-39.45, -4.50, -7.33, -0.71, -1.58, -0.94, 2.42],
  MWF:   [-24.07, -3.23, -6.03, -0.58, -0.99, -0.45, 2.43],
  OIRM:  [-20.43, -1.54, -2.76, 2.40, 1.27, 1.76, 4.48],
  OMWF:  [-18.67, -1.63, -3.51, 2.75, 5.50, 3.74, 3.49],
};
const FULL = { DS: -1.68, BASE: -4.33, SLM: -0.73, JOINT: 0.24, MWF: 0.61, OIRM: 2.67, OMWF: 3.62 };
const fmt = (v) => (v > 0 ? `+${v.toFixed(2)}` : v.toFixed(2));
const vcell = (v, opts = {}) => ({
  t: fmt(v), num: true, align: 'center',
  color: opts.color || (v >= 0 ? C.positive : C.ink),
  bold: opts.bold, fill: opts.fill, size: opts.size,
});

// =====================================================================
// S1 封面
// =====================================================================
{
  const s = pptx.addSlide();
  s.background = { color: C.bg };
  // 左侧装饰竖条
  s.addShape(ShapeType.rect, { x: 0, y: 0, w: 0.18, h: PAGE.h, fill: { color: C.accent }, line: { type: 'none' } });
  // 右上角抽象阵列 + 波前(原生可编辑形状)
  for (let k = 1; k <= 3; k++) {
    s.addShape(ShapeType.ellipse, {
      x: 10.05 - k * 0.52, y: 1.15 - k * 0.18, w: 2.2 + k * 1.04, h: 2.2 + k * 1.04,
      fill: { type: 'none' }, line: { color: k === 1 ? C.accent2 : C.hairline2, width: k === 1 ? 1 : 0.75, transparency: k === 1 ? 30 : 45 },
    });
  }
  for (let k = 0; k < 6; k++) {
    s.addShape(ShapeType.ellipse, {
      x: 9.55 + k * 0.42, y: 1.95 + k * 0.1, w: 0.13, h: 0.13,
      fill: { color: C.accent }, line: { color: C.white, width: 0.75 },
    });
  }
  s.addText('技术汇报 · 阶段一 / 阶段二', {
    x: 0.85, y: 1.5, w: 8, h: 0.3, margin: 0,
    fontFace: F.cn, fontSize: 12, bold: true, color: C.accent, charSpacing: 2,
  });
  s.addText('六通道骨传导麦克风阵列', {
    x: 0.82, y: 2.15, w: 9.5, h: 0.85, margin: 0,
    fontFace: F.cn, fontSize: 34, bold: true, color: C.ink,
  });
  s.addText('低频除杂算法汇报', {
    x: 0.82, y: 3.0, w: 9.5, h: 0.85, margin: 0,
    fontFace: F.cn, fontSize: 34, bold: true, color: C.ink,
  });
  s.addShape(ShapeType.line, { x: 0.85, y: 4.15, w: 4.6, h: 0, line: { color: C.hairline2, width: 1 } });
  s.addText('长时积分"相位斜率假设检验 + ILD"联合似然软掩码（阶段一）\n→ 分段多通道维纳方向滤波：时变 MPDR + 分块掩码 MWF（阶段二）', {
    x: 0.85, y: 4.35, w: 9.6, h: 0.85, margin: 0,
    fontFace: F.cn, fontSize: 13, color: C.ink2, lineSpacingMultiple: 1.35,
  });
  // 底部信息条
  panel(s, 0.85, 5.85, 11.6, 0.78, { fill: C.surface, line: false });
  s.addText([
    { text: '汇报日期　', options: { color: C.muted, fontSize: 11 } },
    { text: '2026-09-19', options: { color: C.ink, fontSize: 11, bold: true, fontFace: F.num } },
  ], { x: 1.1, y: 5.85, w: 2.4, h: 0.78, margin: 0, valign: 'middle', fontFace: F.cn });
  s.addText([
    { text: 'full SI-SDR　', options: { color: C.muted, fontSize: 11 } },
    { text: 'DS −1.68 dB', options: { color: C.ink, fontSize: 11, fontFace: F.num } },
    { text: '  →  ', options: { color: C.muted, fontSize: 11 } },
    { text: 'joint +0.24 dB', options: { color: C.amber, fontSize: 11, bold: true, fontFace: F.num } },
    { text: '  →  ', options: { color: C.muted, fontSize: 11 } },
    { text: 'MWF +0.61 dB', options: { color: C.accent, fontSize: 12, bold: true, fontFace: F.num } },
  ], { x: 3.7, y: 5.85, w: 8.6, h: 0.78, margin: 0, valign: 'middle', fontFace: F.cn });
}

// =====================================================================
// S2 执行摘要
// =====================================================================
{
  const s = pptx.addSlide();
  header(s, '执行摘要', '两阶段累计增益 +2.29 dB，中频段填平约 5 dB 谷底');
  const kpis = [
    { v: '+0.61 dB', label: 'full SI-SDR（MWF）', sub: 'DS −1.68 → joint +0.24 → MWF +0.61', color: C.accent },
    { v: '−4.82 dB', label: '50–100Hz 目标帧保留率', sub: '门限 > −6 dB，唯一达标项', color: C.positive },
    { v: '0.38', label: 'RTF 实时率（6s 音频 2.3s）', sub: '阶段一 0.35，均近实时', color: C.ink },
    { v: '2.3%', label: '深压 TF 格占比（音乐噪声）', sub: '阶段一 joint 为 32.6%，大幅缓解', color: C.amber },
  ];
  const kw = (CW - 3 * 0.22) / 4;
  kpis.forEach((k, i) => {
    const x = mx + i * (kw + 0.22);
    panel(s, x, 1.42, kw, 1.62, { fill: C.surface });
    accentBar(s, x, 1.42, 0.07, k.color, 0.07);
    numToken(s, k.v, x + 0.1, 1.62, kw - 0.2, 0.55, { size: 25, color: k.color });
    s.addText(k.label, { x: x + 0.14, y: 2.22, w: kw - 0.28, h: 0.32, margin: 0, fontFace: F.cn, fontSize: 10.5, bold: true, color: C.ink });
    s.addText(k.sub, { x: x + 0.14, y: 2.53, w: kw - 0.28, h: 0.44, margin: 0, fontFace: F.cn, fontSize: 8.8, color: C.muted, lineSpacingMultiple: 1.05 });
  });
  // 三条核心结论
  s.addText('三条核心结论', { x: mx, y: 3.35, w: 4, h: 0.3, margin: 0, fontFace: F.cn, fontSize: 13, bold: true, color: C.ink });
  const items = [
    ['中频段改善最大', '400–800Hz 由 −5.48 → −0.58 dB、800–1600Hz 由 −6.36 → −0.99 dB；MWF 在 100–400Hz 与 800–3200Hz 全面优于阶段一，3200–6400Hz 保持 DS 的 +2.43 dB。'],
    ['门限整体未达标', '六项承诺门限仅 50–100Hz 保留率达标；full 差 0.89 dB，400–800 / 800–1600 分别差 0.58 / 0.99 dB。'],
    ['差距性质已定位', '<400Hz 为 8mm 阵列孔径决定的物理瓶颈（oracle 空间滤波也仅 −1.6 / −3.5 dB）；400Hz 以上差距来自掩码加权协方差污染（oMWF 上限 +3.62 dB）。'],
  ];
  items.forEach((it, i) => {
    const y = 3.78 + i * 0.88;
    s.addShape(ShapeType.ellipse, { x: mx, y: y + 0.04, w: 0.3, h: 0.3, fill: { color: C.accent }, line: { type: 'none' } });
    numToken(s, String(i + 1), mx, y + 0.04, 0.3, 0.3, { size: 11, color: C.white });
    s.addText([
      { text: it[0] + '　', options: { bold: true, color: C.ink, fontSize: 11.5 } },
      { text: it[1], options: { color: C.ink2, fontSize: 11 } },
    ], { x: mx + 0.45, y, w: CW - 0.45, h: 0.78, margin: 0, valign: 'top', fontFace: F.cn, lineSpacingMultiple: 1.12 });
  });
  footer(s, 2);
}

// =====================================================================
// S3 背景与难点
// =====================================================================
{
  const s = pptx.addSlide();
  header(s, '任务背景', '电小阵列低频段：空间证据随频率线性消失');
  const pw = (CW - 0.3) / 2;
  panel(s, mx, 1.42, pw, 5.0, { fill: C.surface });
  accentBar(s, mx, 1.42, pw, C.accent, 0.06);
  s.addText('信号形态', { x: mx + 0.25, y: 1.6, w: pw - 0.5, h: 0.32, margin: 0, fontFace: F.cn, fontSize: 14, bold: true, color: C.ink });
  const left = [
    ['采集', '6 通道麦克风阵列，间距 8 mm；原始采样 352.8 kHz，处理域 44.1 kHz'],
    ['目标', '近场演奏信号，低频为稀疏持续线谱（约 43 / 48 / 146 / 309 Hz）'],
    ['干扰', '空间方向不同，相邻通道延时 ≈ 0 样本；平稳宽带 + 线谱成分'],
    ['矛盾', '目标与干扰在 <400Hz 频谱高度重叠，频域不可分，只能依赖空间线索'],
  ];
  left.forEach((r, i) => {
    const y = 2.1 + i * 1.02;
    s.addText(r[0], { x: mx + 0.25, y, w: 0.75, h: 0.3, margin: 0, fontFace: F.cn, fontSize: 11, bold: true, color: C.accent });
    s.addText(r[1], { x: mx + 1.05, y, w: pw - 1.3, h: 0.9, margin: 0, fontFace: F.cn, fontSize: 11, color: C.ink2, lineSpacingMultiple: 1.15 });
  });
  const x2 = mx + pw + 0.3;
  panel(s, x2, 1.42, pw, 5.0, { fill: C.surface });
  accentBar(s, x2, 1.42, pw, C.risk, 0.06);
  s.addText('核心难点', { x: x2 + 0.25, y: 1.6, w: pw - 0.5, h: 0.32, margin: 0, fontFace: F.cn, fontSize: 14, bold: true, color: C.ink });
  s.addText([
    { text: 'σ²φ ≈ (1−MSC) / (2·MSC) ∝ 1/f', options: { fontFace: F.num, fontSize: 15, bold: true, color: C.risk } },
  ], { x: x2 + 0.25, y: 2.12, w: pw - 0.5, h: 0.4, margin: 0 });
  const right = [
    '相邻通道相位差 IPD = 2πf·τ 随频率线性缩小：200Hz 波长约 1.7 m，孔径仅 8 mm（孔径/波长 ≈ 0.005）',
    '单快拍逐帧 IPD/TDOA 判决在 <400Hz 失效：目标与干扰的相位差都淹没在估计方差里',
    '频域栅格粗：86.13 Hz/bin（352.8k 域）→ 抽取后 21.5 Hz/bin，低频 bin 数不足',
    '低频干扰与目标空间签名接近共线（可去除分量仅 7%），子空间零陷无的放矢',
  ];
  right.forEach((t, i) => {
    const y = 2.68 + i * 0.88;
    s.addShape(ShapeType.rect, { x: x2 + 0.27, y: y + 0.07, w: 0.09, h: 0.09, fill: { color: C.risk }, line: { type: 'none' } });
    s.addText(t, { x: x2 + 0.5, y, w: pw - 0.78, h: 0.82, margin: 0, fontFace: F.cn, fontSize: 10.5, color: C.ink2, lineSpacingMultiple: 1.14 });
  });
  takeaway(s, '低频除杂的本质矛盾：目标基音必须保留，而该频段恰是阵列空间分辨力最弱的区域。');
  footer(s, 3);
}

// =====================================================================
// S4 承诺门限
// =====================================================================
{
  const s = pptx.addSlide();
  header(s, '验收门限', '阶段一承诺六项门限：五项频带指标 + 一项目标保真指标');
  const rows = [
    [{ t: '全频带', bold: true }, { t: 'full SI-SDR' }, { t: '≥ +1.5 dB', num: true, bold: true, color: C.accent }, { t: '400–7000Hz 粗对齐 + 100–12500Hz 分数延时精对齐后整段 SI-SDR' }],
    [{ t: '中频', bold: true }, { t: '400–800 Hz' }, { t: '≥ 0 dB', num: true, bold: true, color: C.accent }, { t: '分带 SI-SDR（带通滤波后计算）' }],
    [{ t: '中频', bold: true }, { t: '800–1600 Hz' }, { t: '≥ 0 dB', num: true, bold: true, color: C.accent }, { t: '分带 SI-SDR' }],
    [{ t: '低频', bold: true }, { t: '200–400 Hz' }, { t: '≥ −4 dB', num: true, bold: true, color: C.amber }, { t: '分带 SI-SDR' }],
    [{ t: '低频', bold: true }, { t: '100–200 Hz' }, { t: '≥ −1.5 dB', num: true, bold: true, color: C.amber }, { t: '分带 SI-SDR' }],
    [{ t: '极低频', bold: true }, { t: '50–100 Hz 目标帧能量损失' }, { t: '< 6 dB', num: true, bold: true, color: C.positive }, { t: '参考能量 top30% 帧的输出/参考能量比（> −6 dB）' }],
  ];
  table(s,
    ['类别', '指标', '承诺门限', '验收口径'],
    rows, mx, 1.55, [1.3, 3.1, 1.9, 5.79], { rowH: 0.62, fontSize: 11, width: CW });
  s.addText('说明：50–100Hz 目标线谱与干扰完全重叠，SI-SDR 不适用，改用"目标活跃帧保留率"单独验收；其余指标全部在统一对齐口径下计算。',
    { x: mx, y: 5.55, w: CW, h: 0.5, margin: 0, fontFace: F.cn, fontSize: 10, color: C.muted, lineSpacingMultiple: 1.15 });
  takeaway(s, '门限在项目启动时冻结，所有算法迭代（SLM / joint / MWF）均以同一口径、同一参考、同一对齐流程打分。');
  footer(s, 4);
}

// =====================================================================
// S5 统一评测口径
// =====================================================================
{
  const s = pptx.addSlide();
  header(s, '评测口径', '统一前端、STFT、分数延时对齐与分带指标，七组结果可直接比较');
  const steps = [
    ['前端降采样', '352.8 kHz → 44.1 kHz（8 倍抽取）；20 Hz 零相位高通，保住 43 Hz 目标线谱（不能用 25 Hz）'],
    ['STFT', 'nperseg = 2048，75% 重叠（hop 512，约 11.6 ms/帧）；频栅 21.5 Hz，共 518 帧'],
    ['分数延时对齐', '400–7000Hz 互相关整数粗对齐；±4 样本内步长 0.125 精对齐，以 100–12500Hz SI-SDR 最大为准'],
    ['分带指标', '7 个频带 SI-SDR + full；低频残留比 LFres(50–400/400–6400)；50–100Hz 目标帧保留率'],
    ['上限对照', 'DS+oIRM（单通道掩码上限）与分块 oMWF（多通道空间上限）量化物理/估计差距'],
  ];
  const sw = (CW - 4 * 0.34) / 5;
  steps.forEach((st, i) => {
    const x = mx + i * (sw + 0.34);
    step(s, i + 1, x, 1.7, sw, st[0], st[1], 2.55);
    if (i < 4) arrowRight(s, x + sw + 0.03, 2.83, 0.28);
  });
  panel(s, mx, 4.7, CW, 1.5, { fill: C.surface });
  s.addText('目标 TDOA 模板（自校准后，样本 @44.1kHz）', { x: mx + 0.25, y: 4.9, w: 6, h: 0.3, margin: 0, fontFace: F.cn, fontSize: 11.5, bold: true, color: C.ink });
  s.addText('相邻通道延时：2.62 / 2.82 / 2.89 / 2.48 / 2.28　|　干扰相邻延时 ≈ 0（−0.015 ~ 0.057）', {
    x: mx + 0.25, y: 5.25, w: CW - 0.5, h: 0.32, margin: 0, fontFace: F.cn, fontSize: 11, color: C.ink2,
  });
  s.addText('模板由 1200–6400Hz 相位斜率回归 + 无监督相干增益尺度校准（0.8–2.2 网格）得到，不使用参考信号。', {
    x: mx + 0.25, y: 5.62, w: CW - 0.5, h: 0.4, margin: 0, fontFace: F.cn, fontSize: 9.5, color: C.muted,
  });
  takeaway(s, '全部方法（DS / 算法01 / SLM / joint / MWF / 两个 oracle）共用同一份对齐参考与分带定义。');
  footer(s, 5);
}

// =====================================================================
// S6 阶段一方法
// =====================================================================
{
  const s = pptx.addSlide();
  header(s, '阶段一 · 方法', '长时积分"相位斜率假设检验 + 近场 ILD"联合似然软掩码');
  const pw = 7.7;
  const blocks = [
    ['①', '相位斜率假设检验', '对"目标 TDOA / 干扰 TDOA"双假设计算相邻通道相位残差，31 帧（0.36 s）滑窗、逐 bin 累积 LLR；相位方差由时间平均互谱 MSC 给出（单快拍 MSC 期望有偏、放大约 130×，不可用）。'],
    ['②', '静态指纹 L_s（最强指纹）', '全程 518 帧积分的逐 bin LLR：目标持续线谱 bin 稳定为正（+0.1 ~ +0.54），干扰线谱 bin 为负（−1 ~ −4）；动态窗 L 仅以其对 L_s 的偏离量作时变修正。'],
    ['③', '近场 ILD 似然', '60–200Hz 逐通道对数能量：目标模板取 1600–6400Hz 主导带中位、干扰模板取低频带中位；ILD 权重在 120Hz 以上按 1.0 → 0.5 → 0.15 → 0 淡出。'],
  ];
  blocks.forEach((b, i) => {
    const y = 1.45 + i * 1.32;
    panel(s, mx, y, pw, 1.18, { fill: C.surface });
    s.addShape(ShapeType.rect, { x: mx, y, w: 0.5, h: 1.18, fill: { color: C.accent }, line: { type: 'none' } });
    s.addText(b[0], { x: mx, y, w: 0.5, h: 1.18, margin: 0, align: 'center', valign: 'middle', fontFace: F.num, fontSize: 17, bold: true, color: C.white });
    s.addText(b[1], { x: mx + 0.66, y: y + 0.12, w: pw - 0.85, h: 0.3, margin: 0, fontFace: F.cn, fontSize: 12, bold: true, color: C.ink });
    s.addText(b[2], { x: mx + 0.66, y: y + 0.44, w: pw - 0.9, h: 0.7, margin: 0, fontFace: F.cn, fontSize: 9.6, color: C.ink2, lineSpacingMultiple: 1.1 });
  });
  // 右侧判决面板
  const x2 = mx + pw + 0.3;
  const pw2 = CW - pw - 0.3;
  panel(s, x2, 1.45, pw2, 3.82, { fill: 'FFFFFF', lineColor: C.hairline2 });
  accentBar(s, x2, 1.45, 0.06, C.amber);
  s.addText('联合判决', { x: x2 + 0.22, y: 1.62, w: pw2 - 0.4, h: 0.3, margin: 0, fontFace: F.cn, fontSize: 13, bold: true, color: C.ink });
  s.addText('z = k_s·L_s + k_p·(L−L_s) + k_i·w(f)·l_ILD\nmask = σ(z)', {
    x: x2 + 0.22, y: 2.1, w: pw2 - 0.4, h: 0.75, margin: 0, fontFace: F.num, fontSize: 12.5, color: C.ink, lineSpacingMultiple: 1.3,
  });
  const params = [
    ['k_s', '2.5（静态指纹权重，扫参最优）'],
    ['k_p', '1.0（时变偏离量）'],
    ['k_i', '1.5（ILD 权重）'],
    ['f_lf', '2200 Hz（作用上界，3000+ 压坏 1600–3200）'],
    ['保底', '≤100Hz 直通；floor_lf = 0.05'],
    ['高频', '>2200Hz 保持 DS（sigma 掩码实测有害）'],
  ];
  params.forEach((p, i) => {
    const y = 3.0 + i * 0.36;
    s.addText(p[0], { x: x2 + 0.22, y, w: 0.75, h: 0.3, margin: 0, fontFace: F.num, fontSize: 10.5, bold: true, color: C.amber });
    s.addText(p[1], { x: x2 + 1.0, y, w: pw2 - 1.2, h: 0.3, margin: 0, fontFace: F.cn, fontSize: 9.6, color: C.ink2 });
  });
  takeaway(s, '设计要点：证据在时间维长时累积（不跨 bin 池化），静态全程指纹决定身份、动态窗只做修正。');
  footer(s, 6);
}

// =====================================================================
// S7 阶段二方法
// =====================================================================
{
  const s = pptx.addSlide();
  header(s, '阶段二 · 方法', '分段多通道维纳：每个频段只保留一条证据最强的抑制链');
  const rows = [
    [{ t: '< 100 Hz', num: true, bold: true }, { t: 'DS 直通', bold: true, color: C.ink }, { t: '空间签名共线，保目标基音（目标帧保留 −4.82 dB）' }],
    [{ t: '100–400 Hz', num: true, bold: true, color: C.accent }, { t: '时变 MPDR', bold: true, color: C.accent }, { t: '63 帧滑窗混合协方差 R_x(t) + 相对对角加载 λ=0.12；无需 VAD，纯空间零陷' }],
    [{ t: '400–800 Hz', num: true, bold: true, color: C.amber }, { t: 'joint 软掩码 × DS', bold: true, color: C.amber }, { t: '阶段一证据最强链路（盲 MWF 该带更差）' }],
    [{ t: '800–2200 Hz', num: true, bold: true, color: C.accent }, { t: '分块掩码 MWF', bold: true, color: C.accent }, { t: '秩1：MVDR + 后置维纳；63 帧/块掩码加权 Φ_s/Φ_n，λ=0.02' }],
    [{ t: '> 2200 Hz', num: true, bold: true }, { t: 'DS', bold: true, color: C.ink }, { t: '高频 sigma 掩码退化为静态衰减，实测有害，关闭' }],
  ];
  table(s, ['频段', '链路', '选择依据 / 关键参数'], rows, mx, 1.5, [1.7, 2.3, 8.09],
    { rowH: 0.6, fontSize: 11, width: CW });
  panel(s, mx, 4.85, CW, 1.35, { fill: C.surface });
  s.addText('为什么是分段而不是全带统一 MWF？', { x: mx + 0.25, y: 5.02, w: 7, h: 0.3, margin: 0, fontFace: F.cn, fontSize: 12, bold: true, color: C.ink });
  s.addText([
    { text: '探针实验：', options: { bold: true, color: C.accent } },
    { text: '静态 oracle MWF 上限仅 +2.9 dB，分块（31 帧）oracle MWF 达 +3.6 dB —— 时变空间统计是增益主源；但盲掩码协方差在 400–800Hz 污染严重、在 100–400Hz 掩码本身不可靠。统一加载量 = λ·trace(R)/M，与频带绝对能量无关。', options: { color: C.ink2 } },
  ], { x: mx + 0.25, y: 5.36, w: CW - 0.5, h: 0.75, margin: 0, fontFace: F.cn, fontSize: 10.3, lineSpacingMultiple: 1.15 });
  takeaway(s, '秩1 MWF = MVDR 空间零陷 + 后置单通道维纳；MPDR 段解决无掩码可用的低频，MWF 段用空间零陷替代标量掩码。');
  footer(s, 7);
}

// =====================================================================
// S8 已排除方向
// =====================================================================
{
  const s = pptx.addSlide();
  header(s, '阶段二 · 消歧记录', '七个候选方向经实验证伪，避免后续重复试错');
  const rows = [
    [{ t: '跨 bin 子带池化相位', bold: true }, { t: '被宽带干扰主导，池化后 LLR ≈ 0，目标线谱指纹被淹没' }],
    [{ t: '单快拍 MSC 估方差', bold: true }, { t: '期望有偏、方差触顶放大约 130×，LLR 整体被压没' }],
    [{ t: '包络调制线索', bold: true }, { t: '干扰/目标帧能量与 HF 包络相关 0.93–0.98（共调制），无区分度' }],
    [{ t: 'deflate 子空间抵消', bold: true }, { t: '低频干扰可去除分量 remov ≈ 0.07，与目标签名几乎共线；μ=0.5/1/1.5 全部劣化' }],
    [{ t: '投影法 Φ_n = B·R_x·B', bold: true }, { t: '投影零空间包含目标导向矢量，数学上必然退化为 DS，实测增益为 0' }],
    [{ t: 'GEVD-MWF', bold: true }, { t: '掩码协方差秩亏时主特征向量病态，800–1600Hz 暴跌至 −12.8 dB' }],
    [{ t: '平稳底噪谱减', bold: true }, { t: '目标几乎不停歇，分位数噪声估计中全含目标；过减只损伤目标' }],
  ];
  table(s, ['候选方向', '实验现象 / 证伪依据'], rows, mx, 1.5, [3.7, 8.39],
    { rowH: 0.55, fontSize: 10.5, width: CW });
  takeaway(s, '后处理（谱减/门控/包络）无法替代空间零陷；而空间零陷在 <400Hz 受孔径物理约束 —— 两条杠杆的边界均已实测确认。');
  footer(s, 8);
}

// =====================================================================
// S9 分带结果总表
// =====================================================================
{
  const s = pptx.addSlide();
  header(s, '评测结果 · 总表', '分带 SI-SDR：MWF 在除 50–100Hz 外所有频带为盲方法最优');
  const colW = [1.2, 1.35, 1.35, 1.35, 1.45, 1.72, 1.35, 1.37];
  const mkRow = (name, arr, full, opts = {}) => {
    const cells = [{ t: name, bold: true, fill: opts.nameFill || C.surface2, align: 'left' }];
    arr.forEach((v, bi) => cells.push(vcell(v, {
      bold: opts.bold || bi === 6,
      fill: opts.fill,
      color: opts.mwf ? (v >= 0 ? C.positive : C.accent) : undefined,
      size: opts.mwf ? 10 : 9.3,
    })));
    cells.push(vcell(full, { bold: true, fill: opts.fill, color: opts.mwf ? C.accent : C.ink, size: opts.mwf ? 10 : 9.3 }));
    return cells;
  };
  const rows = [
    mkRow('DS（纯空间）', R.DS, FULL.DS),
    mkRow('算法01 基线', R.BASE, FULL.BASE),
    mkRow('SLM', R.SLM, FULL.SLM),
    mkRow('joint（阶段一）', R.JOINT, FULL.JOINT, { bold: false }),
    mkRow('MWF（阶段二）', R.MWF, FULL.MWF, { mwf: true, fill: 'EAF0F6', nameFill: 'DCE7F2' }),
    mkRow('oIRM 上限', R.OIRM, FULL.OIRM),
    mkRow('oMWF 分块上限', R.OMWF, FULL.OMWF),
  ];
  table(s,
    ['频带 Hz', '50–100†', '100–200', '200–400', '400–800', '800–1600', '1600–3200', 'full'],
    rows, mx, 1.42, colW, { rowH: 0.37, fontSize: 9.3, width: CW, headFill: '2F3D4F', zebra: false });
  s.addText('† 50–100Hz 按保底策略直通，以目标帧保留率验收（joint −5.73 dB / MWF −4.82 dB，均通过 >−6 dB），该列 SI-SDR 不具比较意义。表中未列 3200–6400Hz 单列：DS +2.56 / joint +2.42 / MWF +2.43 / oIRM +4.48 / oMWF +3.49。',
    { x: mx, y: 4.5, w: CW, h: 0.62, margin: 0, fontFace: F.cn, fontSize: 9, color: C.muted, lineSpacingMultiple: 1.15 });
  // 三个增益标注
  const gains = [
    ['400–800Hz', '−5.48 → −0.58', '+4.90 dB'],
    ['800–1600Hz', '−6.36 → −0.99', '+5.37 dB'],
    ['full', '−1.68 → +0.61', '+2.29 dB'],
  ];
  const gw = (CW - 2 * 0.22) / 3;
  gains.forEach((g, i) => {
    const x = mx + i * (gw + 0.22);
    panel(s, x, 5.25, gw, 0.95, { fill: C.surface });
    s.addText(g[0], { x: x + 0.18, y: 5.38, w: gw - 0.3, h: 0.26, margin: 0, fontFace: F.cn, fontSize: 10, color: C.muted });
    s.addText(g[1], { x: x + 0.18, y: 5.62, w: gw - 1.4, h: 0.3, margin: 0, fontFace: F.num, fontSize: 11.5, color: C.ink });
    numToken(s, g[2], x + gw - 1.55, 5.55, 1.45, 0.45, { size: 16, color: C.positive, align: 'right' });
  });
  sourceNote(s, '数据：joint_eval.py 2026-09-19 实测；统一 44.1kHz / 分数延时对齐口径。', 6.32);
  footer(s, 9);
}

// =====================================================================
// S10 增益图
// =====================================================================
{
  const s = pptx.addSlide();
  header(s, '评测结果 · 增益形态', '中频谷底被填平；MWF 与 oracle 的差距随频率升高而拉大');
  const labels = ['100-200', '200-400', '400-800', '800-1600', '1600-3200', '3200-6400'];
  const pick = (a) => [a[1], a[2], a[3], a[4], a[5], a[6]];
  const data = [
    { name: 'DS', labels, values: pick(R.DS) },
    { name: 'joint（阶段一）', labels, values: pick(R.JOINT) },
    { name: 'MWF（阶段二）', labels, values: pick(R.MWF) },
    { name: 'oMWF 空间上限', labels, values: pick(R.OMWF) },
  ];
  s.addChart(ChartType.bar, data, {
    x: mx, y: 1.4, w: 8.35, h: 5.05,
    barDir: 'col', barGrouping: 'clustered',
    chartColors: [C.dsGray, C.jointAm, C.accent, '6B8F71'],
    showLegend: true, legendPos: 'b', legendFontFace: F.cn, legendFontSize: 10,
    catAxisLabelFontFace: F.num, catAxisLabelFontSize: 9, catAxisLabelColor: C.ink2,
    valAxisLabelFontFace: F.num, valAxisLabelFontSize: 9, valAxisLabelColor: C.muted,
    valAxisMinVal: -8, valAxisMaxVal: 7, valAxisMajorUnit: 2,
    valGridLine: { color: C.hairline, size: 0.5 },
    catGridLine: { style: 'none' },
    showValue: false, showTitle: false,
    barGapWidthPct: 60,
  });
  // 读图面板
  const x2 = mx + 8.6, pw2 = CW - 8.6;
  const notes = [
    ['中频谷底', 'DS 在 400–1600Hz 约 −6 dB 的谷底，MWF 填平到 −1 dB 附近。'],
    ['差距随频率拉大', '100–200Hz 盲方法与 oracle 差 1.6 dB；800–1600Hz 差 6.5 dB —— 协方差污染在高频更伤。'],
    ['低频四线纠缠', '<400Hz 四条柱挤在一起：空间滤波的物理上限就在 −1.5 ~ −3.5 dB。'],
  ];
  notes.forEach((n, i) => {
    const y = 1.4 + i * 1.72;
    panel(s, x2, y, pw2, 1.5, { fill: C.surface });
    accentBar(s, x2, y, 1.5, i === 0 ? C.accent : i === 1 ? C.amber : C.risk, 0.06);
    s.addText(n[0], { x: x2 + 0.2, y: y + 0.14, w: pw2 - 0.35, h: 0.3, margin: 0, fontFace: F.cn, fontSize: 11.5, bold: true, color: C.ink });
    s.addText(n[1], { x: x2 + 0.2, y: y + 0.5, w: pw2 - 0.4, h: 0.92, margin: 0, fontFace: F.cn, fontSize: 10, color: C.ink2, lineSpacingMultiple: 1.16 });
  });
  sourceNote(s, '注：50–100Hz 因保底策略未纳入图表（MWF −24.07 dB 为直通结果，以保留率验收）。', 6.62);
  footer(s, 10);
}

// =====================================================================
// S11 门限对照
// =====================================================================
{
  const s = pptx.addSlide();
  header(s, '门限达成情况', '六项门限一项达标；差距按"物理瓶颈 / 估计问题"分两类');
  const gateRows = [
    ['full SI-SDR', '≥ +1.5 dB', '+0.61 dB', '−0.89', '未达', 'risk'],
    ['400–800 Hz', '≥ 0 dB', '−0.58 dB', '−0.58', '未达', 'risk'],
    ['800–1600 Hz', '≥ 0 dB', '−0.99 dB', '−0.99', '未达', 'risk'],
    ['200–400 Hz', '≥ −4 dB', '−6.03 dB', '−2.03', '未达', 'risk'],
    ['100–200 Hz', '≥ −1.5 dB', '−3.23 dB', '−1.73', '未达', 'risk'],
    ['50–100Hz 保留率', '> −6 dB', '−4.82 dB', '+1.18', '达标', 'positive'],
  ];
  const rows = gateRows.map((r, i) => {
    const isLow = i >= 3 && i <= 4;
    return [
      { t: r[0], bold: true, align: 'left' },
      { t: r[1], num: true, color: C.ink2 },
      { t: r[2], num: true, bold: true, color: r[5] === 'positive' ? C.positive : C.accent },
      { t: r[3] + ' dB', num: true, color: C.muted },
      { t: r[5] === 'positive' ? '达标' : '未达', align: 'center', bold: true,
        color: r[5] === 'positive' ? C.positive : C.risk },
    ];
  });
  table(s, ['门限项', '承诺', 'MWF 实测', '差距', '状态'], rows,
    mx, 1.5, [3.1, 2.1, 2.1, 1.9, 2.89], { rowH: 0.48, fontSize: 11, width: CW });
  // 差距结构
  panel(s, mx, 4.95, (CW - 0.3) / 2, 1.35, { fill: 'FBF1EE' });
  accentBar(s, mx, 4.95, 0.06, C.risk);
  s.addText('物理瓶颈（<400Hz）', { x: mx + 0.2, y: 5.1, w: 5.5, h: 0.3, margin: 0, fontFace: F.cn, fontSize: 12, bold: true, color: C.risk });
  s.addText('oracle 空间上限在 100–200 / 200–400Hz 也仅 −1.63 / −3.51 dB，对应门限在当前 8mm 孔径下数学上不可达。',
    { x: mx + 0.2, y: 5.45, w: (CW - 0.3) / 2 - 0.4, h: 0.8, margin: 0, fontFace: F.cn, fontSize: 10, color: C.ink2, lineSpacingMultiple: 1.15 });
  const x2 = mx + (CW - 0.3) / 2 + 0.3;
  panel(s, x2, 4.95, (CW - 0.3) / 2, 1.35, { fill: 'EEF4FA' });
  accentBar(s, x2, 4.95, 0.06, C.accent);
  s.addText('估计问题（400–1600Hz，可争取）', { x: x2 + 0.2, y: 5.1, w: 6, h: 0.3, margin: 0, fontFace: F.cn, fontSize: 12, bold: true, color: C.accent });
  s.addText('oMWF 在 400–800 / 800–1600Hz 达 +2.75 / +5.50 dB，门限在上限之内；差距来自掩码加权 Φ_s/Φ_n 污染，是阶段三的主攻方向。',
    { x: x2 + 0.2, y: 5.45, w: (CW - 0.3) / 2 - 0.4, h: 0.8, margin: 0, fontFace: F.cn, fontSize: 10, color: C.ink2, lineSpacingMultiple: 1.15 });
  footer(s, 11);
}

// =====================================================================
// S12 质量指标
// =====================================================================
{
  const s = pptx.addSlide();
  header(s, '评测结果 · 辅指标', '抑制更温和：音乐噪声大幅下降，低频残留与参考持平');
  const cards = [
    ['2.3%', '深压 TF 格占比', 'joint 32.6% → MWF 2.3%（<0.1 倍 DS 功率的时频格比例），音乐噪声显著缓解', C.accent],
    ['−20.9 dB', '低频残留比 LFres', '参考为 −21.0 dB，MWF 与参考持平；joint −24.8 dB 属过度压制', C.positive],
    ['0.38', 'RTF', '6s 音频处理 2.3s（Python/NumPy），阶段一 0.35，仍近实时', C.ink],
    ['−4.82 dB', '50–100Hz 目标保留率', 'joint −5.73 dB；门限 >−6 dB，两阶段均通过', C.amber],
  ];
  const cw = (CW - 0.3) / 2, ch = 2.1;
  cards.forEach((c, i) => {
    const x = mx + (i % 2) * (cw + 0.3);
    const y = 1.55 + Math.floor(i / 2) * (ch + 0.28);
    panel(s, x, y, cw, ch, { fill: C.surface });
    accentBar(s, x, y, 0.07, c[3]);
    numToken(s, c[0], x + 0.3, y + 0.28, 3.4, 0.7, { size: 34, color: c[3], align: 'left' });
    s.addText(c[1], { x: x + 0.32, y: y + 1.08, w: cw - 0.6, h: 0.32, margin: 0, fontFace: F.cn, fontSize: 13, bold: true, color: C.ink });
    s.addText(c[2], { x: x + 0.32, y: y + 1.42, w: cw - 0.6, h: 0.6, margin: 0, fontFace: F.cn, fontSize: 10, color: C.muted, lineSpacingMultiple: 1.15 });
  });
  takeaway(s, 'MWF 以空间零陷替代标量深压：在 SI-SDR 更高的同时，可听伪影更少、目标低频谱更完整。');
  footer(s, 12);
}

// =====================================================================
// S13 物理上限与差距定位
// =====================================================================
{
  const s = pptx.addSlide();
  header(s, '上限分析', 'oracle 实验把剩余差距切分为"不可达"与"可争取"两部分');
  const pw = 5.4;
  panel(s, mx, 1.45, pw, 4.9, { fill: C.surface });
  s.addText('oracle 上限实测（dB）', { x: mx + 0.25, y: 1.62, w: pw - 0.5, h: 0.3, margin: 0, fontFace: F.cn, fontSize: 13, bold: true, color: C.ink });
  const oRows = [
    ['静态 oracle MWF（全程协方差）', '+2.89'],
    ['分块 oracle MWF（31 帧/块）', '+3.49 ~ +3.62'],
    ['DS + oIRM（单通道掩码上限）', '+2.67'],
  ];
  oRows.forEach((r, i) => {
    const y = 2.1 + i * 0.42;
    s.addText(r[0], { x: mx + 0.25, y, w: 3.9, h: 0.34, margin: 0, valign: 'middle', fontFace: F.cn, fontSize: 10.5, color: C.ink2 });
    s.addText(r[1], { x: mx + pw - 1.55, y, w: 1.3, h: 0.34, margin: 0, align: 'right', valign: 'middle', fontFace: F.num, fontSize: 11, bold: true, color: C.accent });
  });
  s.addShape(ShapeType.line, { x: mx + 0.25, y: 3.45, w: pw - 0.5, h: 0, line: { color: C.hairline, width: 0.75 } });
  s.addText('分块 oMWF 逐频带（vs MWF 盲方法）', { x: mx + 0.25, y: 3.6, w: pw - 0.5, h: 0.3, margin: 0, fontFace: F.cn, fontSize: 11, bold: true, color: C.ink });
  const pairs = [
    ['100–200', -1.63, -3.23], ['200–400', -3.51, -6.03], ['400–800', 2.75, -0.58],
    ['800–1600', 5.50, -0.99], ['1600–3200', 3.74, -0.45],
  ];
  pairs.forEach((p, i) => {
    const y = 4.0 + i * 0.42;
    s.addText(p[0], { x: mx + 0.25, y, w: 1.2, h: 0.34, margin: 0, valign: 'middle', fontFace: F.num, fontSize: 10.5, color: C.ink2 });
    s.addText(`oMWF ${fmt(p[1])}`, { x: mx + 1.5, y, w: 1.7, h: 0.34, margin: 0, valign: 'middle', fontFace: F.num, fontSize: 10.5, color: '6B8F71' });
    s.addText(`MWF ${fmt(p[2])}`, { x: mx + 3.25, y, w: 1.7, h: 0.34, margin: 0, valign: 'middle', fontFace: F.num, fontSize: 10.5, color: C.accent });
  });
  // 右侧两类差距
  const x2 = mx + pw + 0.3, pw2 = CW - pw - 0.3;
  panel(s, x2, 1.45, pw2, 2.3, { fill: 'FBF1EE' });
  accentBar(s, x2, 1.45, 0.07, C.risk);
  s.addText('不可达：<400Hz 物理瓶颈', { x: x2 + 0.25, y: 1.62, w: pw2 - 0.5, h: 0.3, margin: 0, fontFace: F.cn, fontSize: 13, bold: true, color: C.risk });
  s.addText('oracle 空间滤波 100–200 / 200–400Hz 仅 −1.63 / −3.51 dB；ILD 帧差仅 0.23、包络共调制 0.93–0.98、可去除分量 0.07 —— 相位/ILD/包络/子空间/谱减五条线索均已探底。',
    { x: x2 + 0.25, y: 2.0, w: pw2 - 0.5, h: 1.65, margin: 0, fontFace: F.cn, fontSize: 10.3, color: C.ink2, lineSpacingMultiple: 1.2 });
  panel(s, x2, 3.95, pw2, 2.4, { fill: 'EEF4FA' });
  accentBar(s, x2, 3.95, 0.07, C.accent);
  s.addText('可争取：协方差估计污染', { x: x2 + 0.25, y: 4.12, w: pw2 - 0.5, h: 0.3, margin: 0, fontFace: F.cn, fontSize: 13, bold: true, color: C.accent });
  s.addText('800–1600Hz：oMWF +5.50 dB vs 盲 MWF −0.99 dB（差 6.5 dB）。根因：掩码加权 Φ_s/Φ_n 时目标与干扰 TF 不独立、掩码概率未校准，两矩阵互相泄漏，秩1后置增益失准。',
    { x: x2 + 0.25, y: 4.5, w: pw2 - 0.5, h: 1.75, margin: 0, fontFace: F.cn, fontSize: 10.3, color: C.ink2, lineSpacingMultiple: 1.2 });
  footer(s, 13);
}

// =====================================================================
// S14 结论与下一步
// =====================================================================
{
  const s = pptx.addSlide();
  header(s, '结论与下一步', '杠杆在协方差估计层，而非再加后置掩码');
  // 左: 结论
  const pw = (CW - 0.3) / 2;
  panel(s, mx, 1.45, pw, 4.55, { fill: C.surface });
  s.addText('阶段结论', { x: mx + 0.25, y: 1.63, w: pw - 0.5, h: 0.32, margin: 0, fontFace: F.cn, fontSize: 14, bold: true, color: C.ink });
  const concl = [
    ['+2.29 dB', 'full SI-SDR 从 DS −1.68 提升至 MWF +0.61，中频 400–1600Hz 改善约 5 dB'],
    ['1 / 6', '门限仅 50–100Hz 目标保留率达标；full 差 0.89 dB'],
    ['0.38 RTF', '近实时；深压 TF 格 32.6% → 2.3%，LFres 与参考持平'],
  ];
  concl.forEach((c, i) => {
    const y = 2.15 + i * 1.18;
    numToken(s, c[0], mx + 0.25, y, 1.85, 0.5, { size: 19, color: C.accent, align: 'left' });
    s.addText(c[1], { x: mx + 2.2, y: y + 0.02, w: pw - 2.45, h: 1.0, margin: 0, fontFace: F.cn, fontSize: 10.8, color: C.ink2, lineSpacingMultiple: 1.2 });
  });
  // 右: 行动
  const x2 = mx + pw + 0.3;
  panel(s, x2, 1.45, pw, 4.55, { fill: 'FFFFFF', lineColor: C.hairline2 });
  accentBar(s, x2, 1.45, 0.07, C.amber);
  s.addText('阶段三行动（协方差层）', { x: x2 + 0.25, y: 1.63, w: pw - 0.5, h: 0.32, margin: 0, fontFace: F.cn, fontSize: 14, bold: true, color: C.ink });
  const acts = [
    ['在线秩-1 PSD 递推', '目标/干扰功率谱改用在线秩-1 更新，替代静态软掩码加权，阻断 Φ_s/Φ_n 互相泄漏'],
    ['RMT 自适应对角加载', '按随机矩阵论由样本量与阵元数（6 通道）整定加载量，抑制小样本协方差特征值发散'],
    ['块长 / 遗忘因子整定', '时变块长与跟踪遗忘因子联合优化（当前固定 63 帧），适配干扰统计的非平稳段'],
  ];
  acts.forEach((a, i) => {
    const y = 2.15 + i * 1.18;
    s.addShape(ShapeType.rect, { x: x2 + 0.25, y: y + 0.04, w: 0.34, h: 0.34, fill: { color: C.amber }, line: { type: 'none' } });
    numToken(s, String(i + 1), x2 + 0.25, y + 0.04, 0.34, 0.34, { size: 13, color: C.white });
    s.addText(a[0], { x: x2 + 0.72, y, w: pw - 1.0, h: 0.3, margin: 0, fontFace: F.cn, fontSize: 12, bold: true, color: C.ink });
    s.addText(a[1], { x: x2 + 0.72, y: y + 0.34, w: pw - 1.0, h: 0.78, margin: 0, fontFace: F.cn, fontSize: 9.8, color: C.ink2, lineSpacingMultiple: 1.14 });
  });
  // 底部说明
  s.addShape(ShapeType.rect, { x: mx, y: 6.18, w: CW, h: 0.02, fill: { color: C.hairline }, line: { type: 'none' } });
  s.addText('备注：若需 <400Hz 门限继续下探，算法侧已近极限，建议引入骨传导通道或增加阵元孔径。',
    { x: mx, y: 6.32, w: CW, h: 0.3, margin: 0, fontFace: F.cn, fontSize: 10, italic: true, color: C.muted });
  footer(s, 14);
}

// ---------- 输出 ----------
const outPath = process.argv[2] || '骨传导阵列低频除杂_汇报PPT_20260919.pptx';
await pptx.writeFile({ fileName: outPath });
console.log('written:', outPath, 'slides:', pptx._slides.length);


# -*- coding: utf-8 -*-
"""阶段一原型(joint)分带对比
统一口径: 所有输出降至 44.1kHz, 参考在 44.1kHz 域做整数+0.125样本分数延时对齐。
对比: 纯DS / 算法01 / 算法02-SLM(当前最优) / 算法02-joint(阶段一) / DS+oIRM(掩码上限)
"""
import numpy as np, sys, os, time
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from common import _shift
from alg02 import alg02, front_end
from scipy.signal import stft, istft
from scipy.signal import fftconvolve
from load_data import CACHE

six, raw = data()
FS = 352800.0
BANDS = [(50, 100), (100, 200), (200, 400), (400, 800), (800, 1600), (1600, 3200), (3200, 6400)]
NPER, NOVER = 2048, 1536

# ---------- DS 输出(与算法内同一模板) ----------
x, fsd = front_end(six, fsub=20.0, decim=8)
Z = np.stack([stft(x[i], fs=fsd, nperseg=NPER, noverlap=NOVER)[2] for i in range(6)])
f = np.fft.rfftfreq(NPER, 1.0 / fsd)
pair_t = np.array([2.622, 2.85, 2.892, 2.499, 2.278])
cum_t = np.concatenate([[0.0], np.cumsum(pair_t)])
aligned0 = np.zeros((Z.shape[1], Z.shape[2]), dtype=complex)
for i in range(6):
    aligned0 += Z[i] * np.exp(1j * 2 * np.pi * f[:, None] * cum_t[i] / fsd)
aligned0 /= 6
ds = istft(aligned0, fs=fsd, nperseg=NPER, noverlap=NOVER)[1][:x.shape[1]]

rd, _ = front_end(raw[None, :], fs=FS, fsub=0.0, decim=8)
rd = rd[0]


def coarse_lag(ref, sig, maxlag=30000):
    a = bp(ref, 400, 7000, fs=fsd); b = bp(sig, 400, 7000, fs=fsd)
    m = min(len(a), len(b))
    c = fftconvolve(a[:m][::-1], b[:m], mode='full'); L = len(c) // 2
    seg = c[L - maxlag:L + maxlag]
    return int(np.argmax(seg) - maxlag)


def align_ref(sig):
    """整数粗对齐 + 0.125 样本精对齐(100-12500Hz SI-SDR 最大)"""
    coarse = coarse_lag(rd, sig)
    best = (-1e9, coarse)
    for d in np.arange(coarse - 4.0, coarse + 4.0 + 1e-9, 0.125):
        a = _shift(rd, d, len(sig), fsd)
        v = si_sdr(bb(sig, 100, 12500, fs=fsd), bb(a, 100, 12500, fs=fsd))
        if v > best[0]:
            best = (v, d)
    return _shift(rd, best[1], len(sig), fsd)


results = {}
def measure(tag, sig, verbose_extra=None):
    a = align_ref(sig)
    n = min(len(a), len(sig)); sig = sig[:n]; a = a[:n]
    vals = {f'{lo}-{hi}': si_sdr(bb(sig, lo, hi, fs=fsd), bb(a, lo, hi, fs=fsd)) for lo, hi in BANDS}
    lf = np.sum(bb(sig, 50, 400, fs=fsd) ** 2); mb = np.sum(bb(sig, 400, 6400, fs=fsd) ** 2)
    lfc = np.sum(bb(a, 50, 400, fs=fsd) ** 2); mbc = np.sum(bb(a, 400, 6400, fs=fsd) ** 2)
    r = dict(vals=vals, full=si_sdr(sig, a),
             LFres=10 * np.log10(lf / (mb + 1e-40)), LFref=10 * np.log10(lfc / (mbc + 1e-40)),
             rms=float(np.sqrt((sig ** 2).mean())))
    results[tag] = r
    cells = ' '.join(f'{vals[f"{lo}-{hi}"]:+6.2f}' for lo, hi in BANDS)
    print(f'{tag:<22}{cells}   full={r["full"]:+6.2f} LFres={r["LFres"]:+6.1f} (ref {r["LFref"]:+.1f})')
    if verbose_extra:
        print('    ' + verbose_extra)
    return r, sig, a


print('band:               ' + ' '.join(f'{lo}-{hi}'.rjust(7) for lo, hi in BANDS))
measure('DS(纯空间)', ds)

# 算法01 / 算法02-SLM 降采样后同口径评测
base = np.load(os.path.join(CACHE, 'base.npy'))
slm = np.load(os.path.join(CACHE, 'alg02_best.npy'))
b_d, _ = front_end(base[None, :], fs=FS, fsub=0.0, decim=8)
s_d, _ = front_end(slm[None, :], fs=FS, fsub=0.0, decim=8)
measure('算法01(基线)', b_d[0])
measure('算法02-SLM', s_d[0])

# ---------- 阶段一 joint (扫参后定版) ----------
# 证据: 逐bin 全程斜率指纹 Ls(ks) + 0.36s 窗内偏离量(kp) + <250Hz ILD(ki);
#       相位掩码到 2200Hz, 以上保持 DS(高频 sigma 在混叠下退化为静态衰减, 实测有害)
JOINT = dict(fsub=20.0, f_guard=0.0, f_lf=2200.0, lf_mode='joint',
             lf_band=(60, 1200), joint_win=31, joint_ks=2.5, joint_kp=1.0,
             joint_ki=1.5, joint_ild_hi=200.0, joint_lo_f=100.0, joint_lo_floor=1.0,
             hf_mode='none', calib=(0.8, 2.2),
             sm_f=3, sm_t=5, sharp=1.0, floor_lf=0.05, floor_hf=0.05)
oj, dj = alg02(six, return_diag=True, **JOINT)
t0 = time.time()
for _ in range(3):
    alg02(six, **JOINT)
dt = (time.time() - t0) / 3.0
oj_d, _ = front_end(oj[None, :], fs=FS, fsub=0.0, decim=8)
mk = dj['mask']; ff = dj['f']
mstats = []
for lo, hi in [(20, 60), (60, 120), (120, 250), (250, 500), (500, 800), (800, 1200), (1200, 2200)]:
    mm = (ff >= lo) & (ff < hi)
    mstats.append(f'{lo}-{hi}:{mk[mm].mean():.2f}')
occ = (mk[(ff >= 50) & (ff < 2200)] < 0.1).mean()
rj, sj, aj = measure('算法02-joint', oj_d[0],
                     f't={dt:.1f}s RTF={dt/6.0:.3f}  掩码均值 ' + ' '.join(mstats)
                     + f'  深压(mask<0.1)占比={occ*100:.1f}%')
np.save(os.path.join(CACHE, 'alg02_joint.npy'), oj)

# ---------- 阶段二: 分段多通道维纳 (tvMPDR | joint | block-MWF) ----------
MWF = dict(fsub=20.0, f_guard=0.0, f_lf=2200.0, lf_mode='mwf',
           lf_band=(60, 1200), joint_win=31, joint_ks=2.5, joint_kp=1.0, joint_ki=1.5,
           joint_ild_hi=200.0, joint_lo_f=100.0, joint_lo_floor=1.0,
           mwf_keep=100.0, mwf_mpdr=400.0, mwf_mask=800.0, mwf_f=2200.0,
           mwf_win=63, mwf_block=63, mwf_nbin=3, mwf_lam_lo=0.12, mwf_lam_hi=0.02,
           hf_mode='none', calib=(0.8, 2.2),
           sm_f=3, sm_t=5, sharp=1.0, floor_lf=0.05, floor_hf=0.05)
om, dm = alg02(six, return_diag=True, **MWF)
t0 = time.time()
for _ in range(3):
    alg02(six, **MWF)
dtm = (time.time() - t0) / 3.0
om_d, _ = front_end(om[None, :], fs=FS, fsub=0.0, decim=8)
Ym = dm['spec_out']; fm = dm['f']
ds_pow = np.abs(dj['aligned']) ** 2
deep = ((np.abs(Ym) ** 2 < 0.1 * (ds_pow + 1e-30))
        & (fm[:, None] >= 50) & (fm[:, None] < 2200)).mean()
rm, sm, am = measure('算法02-MWF(阶段二)', om_d[0],
                     f't={dtm:.1f}s RTF={dtm/6.0:.3f}  深压TF格(<0.1倍DS功率)占比={deep*100:.1f}%')
np.save(os.path.join(CACHE, 'alg02_mwf.npy'), om)

# ---------- 50-100Hz 目标帧保留率(验收口径) ----------
n = min(len(sj), len(aj))
Zso = stft(sj[:n], fs=fsd, nperseg=NPER, noverlap=NOVER)[2]
Zre = stft(aj[:n], fs=fsd, nperseg=NPER, noverlap=NOVER)[2]
K = min(Zso.shape[1], Zre.shape[1])
m50 = (f >= 50) & (f < 100)
eo = np.sum(np.abs(Zso[m50, :K]) ** 2, axis=0)
er = np.sum(np.abs(Zre[m50, :K]) ** 2, axis=0)
tgt = er > np.quantile(er, 0.7)
ret = 10 * np.log10(eo[tgt].sum() / (er[tgt].sum() + 1e-30) + 1e-30)
print(f'\n50-100Hz 目标帧保留率  joint: {ret:+.2f} dB', end='')
# MWF 同口径
n2 = min(len(sm), len(am))
Zmo = stft(sm[:n2], fs=fsd, nperseg=NPER, noverlap=NOVER)[2]
Zmr = stft(am[:n2], fs=fsd, nperseg=NPER, noverlap=NOVER)[2]
Km = min(Zmo.shape[1], Zmr.shape[1])
eom = np.sum(np.abs(Zmo[m50, :Km]) ** 2, axis=0)
erm = np.sum(np.abs(Zmr[m50, :Km]) ** 2, axis=0)
tgtm = erm > np.quantile(erm, 0.7)
retm = 10 * np.log10(eom[tgtm].sum() / (erm[tgtm].sum() + 1e-30) + 1e-30)
print(f'   MWF: {retm:+.2f} dB   (门限 > -6 dB)')

# ---------- oIRM 上限(DS 上) ----------
a_ds = align_ref(ds)
n = min(len(a_ds), len(ds))
Za = stft(a_ds[:n], fs=fsd, nperseg=NPER, noverlap=NOVER)[2]
Zd = stft(ds[:n], fs=fsd, nperseg=NPER, noverlap=NOVER)[2]
K = min(Za.shape[1], Zd.shape[1])
Ca, Cd = np.abs(Za[:, :K]), np.abs(Zd[:, :K])
Nn = np.maximum(Cd - Ca, 0)
y_irm = istft(Zd[:, :K] * (Ca / (Ca + Nn + 1e-30)), fs=fsd, nperseg=NPER, noverlap=NOVER)[1][:n]
measure('DS+oIRM(上限)', y_irm)

# ---------- oracle 分块 MWF 上限(逐块 LS 投影构造真 Phi_s/Phi_n) ----------
Zo = Z[:, :, :K]
Sro = Za[:, :K]
Ko = K
cum_o = dm['cum_t']
ao = np.exp(-1j * 2 * np.pi * f[:, None] * cum_o[None, :] / fsd)
BL = 31
Yom = np.zeros((len(f), Ko), complex)
for t0 in range(0, Ko, BL):
    t1 = min(Ko, t0 + BL)
    for fi in range(1, len(f)):
        Xb = Zo[:, fi, t0:t1]
        Sb = Sro[fi, t0:t1]
        cc = (Xb @ Sb.conj()) / (np.vdot(Sb, Sb) + 1e-30)
        Xs = cc[:, None] * Sb[None, :]
        Xn = Xb - Xs
        Ps = Xs @ Xs.conj().T / len(Sb)
        Pn = Xn @ Xn.conj().T / len(Sb)
        Ps = 0.5 * (Ps + Ps.conj().T)
        Pn = 0.5 * (Pn + Pn.conj().T)
        av = ao[fi]
        Rinv = np.linalg.inv(Pn + 1e-3 * np.trace(Pn).real / 6 * np.eye(6))
        u = Rinv @ av
        den = complex(av.conj() @ u).real + 1e-30
        sig2 = max(0.0, complex(av.conj() @ Ps @ av).real / complex(av.conj() @ av).real)
        Gw = sig2 / (sig2 + 1.0 / den)
        Yom[fi, t0:t1] = (Gw * u / den).conj() @ Xb
y_omw = istft(Yom, fs=fsd, nperseg=NPER, noverlap=NOVER)[1][:n]
measure('oMWF分块(空间上限)', y_omw)

print('\n=== 汇总: 各方法分带 SI-SDR (dB) ===')
order = ['DS(纯空间)', '算法01(基线)', '算法02-SLM', '算法02-joint', '算法02-MWF(阶段二)',
         'DS+oIRM(上限)', 'oMWF分块(空间上限)']
print(f'{"band":>10}' + ''.join(f'{t.split("(")[0]:>10}' for t in order))
for lo, hi in BANDS:
    k = f'{lo}-{hi}'
    print(f'{k:>10}' + ''.join(f'{results[t]["vals"][k]:10.2f}' for t in order))
print(f'{"full":>10}' + ''.join(f'{results[t]["full"]:10.2f}' for t in order))

# -*- coding: utf-8 -*-
"""分频带上限(oracle IRM/IBM) 与 最优配置逐带明细"""
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from alg02 import alg02, front_end
from scipy.signal import stft, istft
six, raw = data()
BEST = dict(f_guard=120.0, f_lf=2000.0, hf_mode='sigma', hf_k=2.0, hf_floor=0.5, hf_cap=1.5,
            lf_mode='slm', calib=(0.8, 2.2), sharp=1.0, sm_f=3, sm_t=5, floor_lf=0.0, floor_hf=0.05)
o_b, dg = alg02(six, return_diag=True, **BEST)
base = np.load(os.path.join(CACHE, "base.npy"))
fsd = dg['fsd']; f = dg['f']
print("cfg:", BEST)
print(f"模板 pair={np.round(dg['pair_t'],3)} cum={np.round(dg['cum_t'],2)} "
      f"f_unamb={float(dg['f_unamb']):.0f}Hz 相干增益={float(dg['cg']):.2f}dB")
rb = evaluate(base, raw, tag="算法01", verbose=False)
ro = evaluate(o_b, raw, tag="算法02-best", verbose=False)
np.save(os.path.join(CACHE, "alg02_best.npy"), o_b)

# --- 把参考降到与 DS 输出同一时间轴/采样率/栅格 ---
lag = best_lag(raw, o_b)
a_full = align(raw, o_b, lag)
a_dec, _ = front_end(a_full[None, :], fs=FS, fsub=0.0, decim=8)
a_dec = a_dec[0][:dg['aligned'].shape[1] * 4 + 8192]
N = min(len(a_dec), dg['x'].shape[1])
a_dec = a_dec[:N]
Za = stft(a_dec, fs=fsd, nperseg=2048, noverlap=1536)[2]
Zd = dg['aligned'][:, :Za.shape[1]]
print("\n" + f"{'band':>12}{'算法01':>10}{'算法02':>10}{'Δ':>8}{'oIRM':>9}{'oIBM':>9}{'oIRM-LF':>9}")
BANDS = [(20, 50), (50, 100), (100, 200), (200, 400), (400, 800), (800, 1600),
         (1600, 3200), (3200, 6400)]
for lo, hi in BANDS:
    m = (f >= lo) & (f < hi)
    if m.sum() < 2:
        print(f"{lo:>4.0f}-{hi:<7.0f}   低于频率栅格")
        continue
    def rec(M):
        Z = Zd.copy(); Z[m] = Z[m] * M
        return istft(Z, fs=fsd, nperseg=2048, noverlap=1536)[1]
    Ca, Cd = np.abs(Za[m]), np.abs(Zd[m])
    Nn = np.maximum(Cd - Ca, 0)
    irm = Ca / (Ca + Nn + 1e-30)
    ibm = (Ca > Nn).astype(float)
    fb_o, fb_b = rec(irm), rec(ibm)
    a_b = bp(a_dec, lo, hi, fs=fsd)
    print(f"{lo:>4.0f}-{hi:<7.0f}{rb['bands'][(lo,hi)]:10.2f}{ro['bands'][(lo,hi)]:10.2f}"
          f"{ro['bands'][(lo,hi)]-rb['bands'][(lo,hi)]:8.2f}"
          f"{si_sdr(bp(fb_o,lo,hi,fs=fsd),a_b):9.2f}{si_sdr(bp(fb_b,lo,hi,fs=fsd),a_b):9.2f}"
          f"{np.mean(irm):9.3f}")
print("\n各配置逐带 SI-SDR:")
for tag, r in [("算法01", rb), ("算法02", ro)]:
    print(f"  {tag:<8}" + "  ".join(f"{lo}-{hi}:{r['bands'][(lo,hi)]:+.2f}" for lo, hi in BANDS))

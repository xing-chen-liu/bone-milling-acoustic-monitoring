# -*- coding: utf-8 -*-
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from load_data import load_all, load_ref
from scipy.signal import welch, fftconvolve

FS=352800.0
six=load_all().astype(np.float64); n=six.shape[1]
raw=load_ref("raw", r"C:/Users/刘星辰/Desktop/bone/9.18/9.18/原音频.txt").astype(np.float64)
out=load_ref("out01", r"C:/Users/刘星辰/Desktop/bone/9.18/9.18/01 去噪结果.txt").astype(np.float64)

bands=[(0,20),(20,50),(50,100),(100,200),(200,400),(400,800),(800,1600),(1600,3200),
       (3200,6400),(6400,12500),(12500,20000),(20000,40000)]
PSD=[]
for i in range(6):
    f,P=welch(six[i],fs=FS,nperseg=16384,noverlap=8192); PSD.append((f,P))
f,P0=PSD[0]; tot=np.trapezoid(P0,f)
print("=== ch1..ch6 band energy share (% of that channel's total) ===")
print(f"{'band':>13}"+"".join(f"{'ch%d'%(i+1):>8}" for i in range(6)))
for lo,hi in bands:
    m=(f>=lo)&(f<hi)
    row=f"{lo:>5.0f}-{hi:<7.0f}"
    for i in range(6):
        Pi=PSD[i][1]; row+=f"{np.trapezoid(Pi[m],f[m])/np.trapezoid(Pi,f)*100:8.2f}"
    print(row)

def gcc(a,b,maxlag=60000,fb=None):
    x,y=a.copy(),b.copy()
    if fb:
        from scipy.signal import butter, sosfiltfilt
        sos=butter(4,np.array(fb)/(FS/2),btype='band',output='sos')
        x=sosfiltfilt(sos,x); y=sosfiltfilt(sos,y)
    x-=x.mean(); y-=y.mean()
    c=fftconvolve(x[::-1],y,mode='full'); lags=np.arange(len(c))-(len(c)//2)
    k=np.argmin(np.abs(lags-np.argmax(np.abs(c[max(0,len(c)//2-maxlag):len(c)//2+maxlag])+ (len(c)//2-maxlag))))
    seg=c[len(c)//2-maxlag:len(c)//2+maxlag]; j=int(np.argmax(np.abs(seg)))
    lag=j-maxlag
    return lag, abs(seg[j])/np.sqrt((x**2).sum()*(y**2).sum())

print("\n=== per-pair TDOA (samples) by band, via cross-correlation ===")
print(f"{'pair':>8}"+"".join(f"{str(b):>18}" for b in [(20,400),(50,300),(400,2000),(2000,7000),(7000,13000),(13000,19000)]))
for i in range(5):
    row=f"ch{i+1}-{i+2}".rjust(8)
    for fb in [(20,400),(50,300),(400,2000),(2000,7000),(7000,13000),(13000,19000)]:
        lag,cc=gcc(six[i],six[i+1],maxlag=6000,fb=fb)
        row+=f"{lag:>9d}({cc:.2f})".rjust(18)
    print(row)
print("\n=== cumulative TDOA vs ch1 ===")
for i in range(1,6):
    lag,cc=gcc(six[0],six[i],maxlag=60000,fb=(400,7000))
    print(f"  ch1-ch{i+1}: {lag:+6d} samples ({lag/FS*1e6:+.1f} us) cc={cc:.3f}")

print("\n=== raw reference alignment ===")
for i in range(6):
    lag,cc=gcc(raw,six[i],maxlag=200000,fb=(400,7000))
    print(f"  raw->ch{i+1}: {lag:+6d} ({lag/FS*1e6:+.1f} us) cc={cc:.3f}")
ds=six.mean(0)
lag,cc=gcc(raw,ds,maxlag=200000,fb=(400,7000)); print(f"  raw->mean6: {lag:+6d} cc={cc:.3f}")
lag,cc=gcc(raw,out,maxlag=200000,fb=(400,7000)); print(f"  raw->out01: {lag:+6d} cc={cc:.3f}")
lag,cc=gcc(out,ds,maxlag=20000,fb=(400,7000)); print(f"  mean6->out01: {lag:+6d} cc={cc:.3f}")
for i in range(6):
    lag,cc=gcc(out,six[i],maxlag=20000,fb=(400,7000)); print(f"  ch{i+1}->out01: {lag:+6d} cc={cc:.3f}")

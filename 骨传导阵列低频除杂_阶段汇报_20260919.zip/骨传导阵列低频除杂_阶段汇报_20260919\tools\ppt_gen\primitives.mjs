﻿// 基础元件: 页眉/页脚、面板、表格、状态徽章、KPI、流程节点
import { ShapeType } from './ppt.mjs';
import { C, F, PAGE, RHY, T } from './tokens.mjs';
import { addSingleLineToken } from './scripts/pptx-text-guards.mjs';

const { mx } = PAGE;

export function header(slide, label, title) {
  slide.addText(label, { x: mx, y: RHY.labelY, w: 9, h: 0.26, margin: 0, ...T.sectionLabel });
  slide.addText(title, { x: mx, y: RHY.titleY, w: PAGE.w - 2 * mx, h: 0.5, margin: 0, ...T.claim });
  slide.addShape(ShapeType.line, {
    x: mx, y: RHY.ruleY, w: PAGE.w - 2 * mx, h: 0,
    line: { color: C.hairline, width: 0.75 },
  });
}

export function footer(slide, folio, deckName = '骨传导阵列低频除杂 · 阶段汇报') {
  slide.addShape(ShapeType.line, {
    x: mx, y: 7.0, w: PAGE.w - 2 * mx, h: 0,
    line: { color: C.hairline, width: 0.5 },
  });
  slide.addText(deckName, { x: mx, y: 7.06, w: 6, h: 0.24, margin: 0, ...T.source });
  addSingleLineToken(slide, String(folio).padStart(2, '0'), {
    x: PAGE.w - mx - 0.5, y: 7.06, w: 0.5, h: 0.24,
    fontFace: F.num, fontSize: 8.5, color: C.muted, align: 'right',
  });
}

export function sourceNote(slide, text, y) {
  slide.addText(text, { x: mx, y, w: PAGE.w - 2 * mx, h: 0.24, margin: 0, ...T.source });
}

export function panel(slide, x, y, w, h, opts = {}) {
  slide.addShape(ShapeType.rect, {
    x, y, w, h,
    fill: { color: opts.fill || C.surface },
    line: opts.line === false ? { type: 'none' } : { color: opts.lineColor || C.hairline, width: 0.5 },
    rectRadius: opts.radius || 0,
  });
}

export function accentBar(slide, x, y, h, color = C.accent, w = 0.06) {
  slide.addShape(ShapeType.rect, {
    x, y, w, h, fill: { color }, line: { type: 'none' },
  });
}

// 状态徽章
export function chip(slide, x, y, text, kind = 'positive', w = 0.78) {
  const color = kind === 'positive' ? C.positive : kind === 'caution' ? C.caution : C.risk;
  slide.addShape(ShapeType.roundRect, {
    x, y, w, h: 0.26,
    fill: { color }, line: { type: 'none' }, rectRadius: 0.05,
  });
  slide.addText(text, {
    x, y: y + 0.015, w, h: 0.23, margin: 0, align: 'center',
    fontFace: F.cn, fontSize: 9, bold: true, color: C.white,
  });
}

// 单行数字令牌(不走普通段落, 杜绝折行)
export function numToken(slide, value, x, y, w, h, opts = {}) {
  addSingleLineToken(slide, value, {
    x, y, w, h, margin: 0, align: opts.align || 'center', valign: 'middle',
    fontFace: F.num, fontSize: opts.size || 26, bold: opts.bold !== false,
    color: opts.color || C.accent, minFontSize: opts.minSize || 10,
  });
}

// 统一表格: headers[], rows[][ {t, opts} | string ], colW[]
export function table(slide, headers, rows, x, y, colW, opts = {}) {
  const fs = opts.fontSize || 9.5;
  const headOpts = {
    fill: { color: opts.headFill || '2F3D4F' },
    color: C.white, bold: true, fontSize: fs, fontFace: F.cn,
    align: 'center', valign: 'middle', margin: [2, 4, 2, 4],
    border: { type: 'solid', color: '43536A', pt: 0.5 },
  };
  const head = [headers.map((h) => ({ text: h, options: headOpts }))];
  const body = rows.map((r, ri) => r.map((cell) => {
    const isObj = typeof cell === 'object' && cell !== null;
    const o = isObj ? cell : { t: String(cell) };
    const zebra = ri % 2 === 1 ? C.surface : C.white;
    return {
      text: o.t,
      options: {
        fill: { color: o.fill || (opts.zebra === false ? C.white : zebra) },
        color: o.color || C.ink,
        bold: !!o.bold,
        fontSize: o.size || fs,
        fontFace: o.num ? F.num : F.cn,
        align: o.align || 'center',
        valign: 'middle',
        margin: [2, 4, 2, 4],
        border: { type: 'solid', color: C.hairline, pt: 0.5 },
      },
    };
  }));
  slide.addTable(head.concat(body), {
    x, y, w: opts.width,
    colW,
    rowH: opts.rowH || 0.32,
    autoPage: false,
    fontFace: F.cn,
  });
}

// 结论条(页面底部暗示区)
export function takeaway(slide, text, y = 6.52) {
  accentBar(slide, mx, y, 0.42, C.accent);
  slide.addShape(ShapeType.rect, {
    x: mx + 0.06, y, w: PAGE.w - 2 * mx - 0.06, h: 0.42,
    fill: { color: C.surface }, line: { type: 'none' },
  });
  slide.addText(
    [{ text: '结论  ', options: { bold: true, color: C.accent } }, { text }],
    { x: mx + 0.2, y, w: PAGE.w - 2 * mx - 0.35, h: 0.42, margin: 0,
      valign: 'middle', fontFace: F.cn, fontSize: 10.5, color: C.ink2 });
}

// 流程步骤(编号方块 + 标题 + 描述)
export function step(slide, i, x, y, w, title, desc, h = 1.5) {
  panel(slide, x, y, w, h, { fill: C.surface });
  slide.addShape(ShapeType.rect, {
    x, y, w: 0.42, h: 0.42, fill: { color: C.accent }, line: { type: 'none' },
  });
  addSingleLineToken(slide, String(i), {
    x, y, w: 0.42, h: 0.42, margin: 0, align: 'center', valign: 'middle',
    fontFace: F.num, fontSize: 15, bold: true, color: C.white,
  });
  slide.addText(title, {
    x: x + 0.52, y: y + 0.04, w: w - 0.62, h: 0.34, margin: 0,
    fontFace: F.cn, fontSize: 11.5, bold: true, color: C.ink,
  });
  slide.addText(desc, {
    x: x + 0.14, y: y + 0.52, w: w - 0.28, h: h - 0.62, margin: 0,
    fontFace: F.cn, fontSize: 9.5, color: C.ink2, lineSpacingMultiple: 1.08,
  });
}

export function arrowRight(slide, x, y, w = 0.3) {
  slide.addShape(ShapeType.chevron, {
    x, y, w, h: 0.3, fill: { color: C.hairline2 }, line: { type: 'none' },
  });
}


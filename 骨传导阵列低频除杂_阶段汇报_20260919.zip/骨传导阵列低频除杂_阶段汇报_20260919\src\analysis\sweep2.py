# -*- coding: utf-8 -*-
import numpy as np, sys, os, time
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from alg02 import alg02, coherence_gain, front_end, template_tdoa
from scipy.signal import stft
six, raw = data()
def run(tag, **kw):
    t0=time.time(); o=alg02(six, **kw); dt=time.time()-t0
    r=evaluate(o, raw, tag=f"{tag} [{dt:.1f}s]", verbose=False)
    print(f"  {tag:<42} t={dt:4.1f}s SI-SDR={r['si_sdr_full']:+6.2f} 加权={r['si_sdr_wavg']:+6.2f} "
          f"最差3带={r['si_sdr_lo3']:+6.2f} LF={r['LF_residue_dB']:+6.1f}dB rms={r['rms']:.2e}")
    return r, o
print("=== 基线 ===")
r=evaluate(np.load(os.path.join(CACHE,"base.npy")), raw, tag="算法01", verbose=False)
print(f"  {'算法01(基线)':<42} t= 6.3s SI-SDR={r['si_sdr_full']:+6.2f} 加权={r['si_sdr_wavg']:+6.2f} "
      f"最差3带={r['si_sdr_lo3']:+6.2f} LF={r['LF_residue_dB']:+6.1f}dB rms={r['rms']:.2e}")
print("\n=== 低频掩码策略 (模板=qhi0.65, f_guard=120, HF=CRLB掩码) ===")
COM=dict(f_guard=120.0, f_lf=1200.0, hf_mode='sigma')
for m in ['none','frame','slm','both']:
    run(f"lf_mode={m}", lf_mode=m, **COM)
print("\n=== 模板自校准 calib (lf_mode=slm) ===")
for c in [None,(0.8,2.2)]:
    run(f"calib={c}", lf_mode='slm', calib=c, **COM)
print("\n=== 守护带截止 f_guard ===")
for g in [0.0,60.0,90.0,120.0,160.0,220.0,300.0]:
    run(f"f_guard={g:.0f}", f_guard=g, f_lf=1200.0, hf_mode='sigma', lf_mode='slm', calib=(0.8,2.2))
print("\n=== 低频上边界 f_lf (slm 生效区间上限) ===")
for L in [600.,1200.,2000.,3000.,4500.]:
    run(f"f_lf={L:.0f}", f_guard=120.0, f_lf=L, hf_mode='sigma', lf_mode='slm', calib=(0.8,2.2))
print("\n=== HF 掩码核宽 ===")
for k,fl,cp in [(1.0,0.5,3.0),(2.0,0.5,3.0),(2.0,1.0,3.0),(3.0,1.0,4.0),(2.0,0.5,1.5),(5.0,1.0,8.0),('const',0,0)]:
    if k=='const': run("hf=const(算法01式)", f_guard=120.,f_lf=1200.,lf_mode='slm',calib=(0.8,2.2),hf_mode='const')
    else: run(f"hf_k={k} floor={fl} cap={cp}", f_guard=120.0,f_lf=1200.0,lf_mode='slm',calib=(0.8,2.2),hf_k=k,hf_floor=fl,hf_cap=cp)
print("\n=== 掩码整形 ===")
for sh,sf,stt,flf in [(0.5,3,5,0.0),(1.0,3,5,0.0),(0.35,3,5,0.0),(0.5,1,3,0.0),(0.5,5,9,0.0),(0.5,3,5,0.05),(0.7,3,7,0.0)]:
    run(f"sharp={sh} sm_f={sf} sm_t={stt} fl_lf={flf}", f_guard=120.0,f_lf=1200.0,lf_mode='slm',
        calib=(0.8,2.2),hf_mode='sigma',sharp=sh,sm_f=sf,sm_t=stt,floor_lf=flf)

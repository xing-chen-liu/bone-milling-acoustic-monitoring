# -*- coding: utf-8 -*-
"""低频除杂效果专业可视化:
  fig1_waveform.png     除杂前(DS)/除杂后(MWF) 波形对比: 全程 6s + 0.6s 局部放大
  fig2_spectrogram.png 语谱图对比: 全频 0-8kHz + 低频噪声区 0-1.2kHz 放大
  fig3_spectrum.png     振幅-频率谱(PSD)对比 + 7 频带能量柱状对比
统一口径: 44.1kHz, STFT 2048/1536; 除杂前=DS 波束输出, 除杂后=阶段二 MWF。
"""
import os, sys
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
from common import data, _shift, bp
from alg02 import alg02, front_end
from scipy.signal import stft, spectrogram, fftconvolve
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.colors import LinearSegmentedColormap

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 10.5
plt.rcParams['axes.edgecolor'] = '#4A5563'
plt.rcParams['axes.labelcolor'] = '#1B2430'
plt.rcParams['xtick.color'] = '#4A5563'
plt.rcParams['ytick.color'] = '#4A5563'

C_BEFORE = '#B24A3F'   # 除杂前(砖红)
C_AFTER  = '#1F5C99'    # 除杂后(蓝)
C_REF    = '#2E7D46'    # 参考(绿)
C_NOISE  = '#C98A2B'    # 噪声区标注(琥珀)
GREY     = '#6E7C8D'

OUT = os.path.join(os.path.dirname(__file__), '..', 'docs', 'figures')
os.makedirs(OUT, exist_ok=True)

FS0 = 352800.0
NPER, NOVER = 2048, 1536

# ---------- 载入并统一到 44.1kHz ----------
six, raw = data()
x, fsd = front_end(six, fsub=20.0, decim=8)
Z = np.stack([stft(x[i], fs=fsd, nperseg=NPER, noverlap=NOVER)[2] for i in range(6)])
f = np.fft.rfftfreq(NPER, 1.0 / fsd)
pair_t = np.array([2.622, 2.85, 2.892, 2.499, 2.278])
cum_t = np.concatenate([[0.0], np.cumsum(pair_t)])
DS = np.mean([Z[i] * np.exp(1j * 2 * np.pi * f[:, None] * cum_t[i] / fsd)
             for i in range(6)], axis=0)
from scipy.signal import istft
before = istft(DS, fs=fsd, nperseg=NPER, noverlap=NOVER)[1][:x.shape[1]]

mwf = np.load(os.path.join(os.path.dirname(__file__), 'cache', 'alg02_mwf.npy'))
after_d, _ = front_end(mwf[None, :], fs=FS0, fsub=0.0, decim=8)
after = after_d[0][:len(before)]
before = before[:len(after)]
n = len(after)
t = np.arange(n) / fsd

# 能量归一化到同一 RMS, 公平比较振幅(保留形状, 仅对齐刻度)
before = before / (np.sqrt(np.mean(before ** 2)) + 1e-30)
after = after / (np.sqrt(np.mean(after ** 2)) + 1e-30)

# 参考(对齐)
rd, _ = front_end(raw[None, :], fs=FS0, fsub=0.0, decim=8)
rd = rd[0]
aa = bp(rd, 400, 7000, fs=fsd); bb_ = bp(after, 400, 7000, fs=fsd)
m = min(len(aa), len(bb_))
c = fftconvolve(aa[:m][::-1], bb_[:m], 'full'); L = len(c) // 2
seg = c[L - 30000:L + 30000]
lag = int(np.argmax(seg) - 30000)
best = (-1e9, lag)
for d in np.arange(lag - 4, lag + 4.001, 0.125):
    sh = _shift(rd, d, len(after), fsd)
    from common import si_sdr, bb
    v = si_sdr(bb(after, 100, 12500, fs=fsd), bb(sh[:len(after)], 100, 12500, fs=fsd))
    if v > best[0]:
        best = (v, d)
ref = _shift(rd, best[1], len(after), fsd)
ref = ref / (np.sqrt(np.mean(ref ** 2)) + 1e-30)

print('signals ready:', before.shape, after.shape, ref.shape, 'fs=', fsd)

# 自定义语谱图色板
CMAP = LinearSegmentedColormap.from_list(
    'spec', ['#0E1726', '#16324F', '#1F5C99', '#4E8FC4', '#A8CCE8', '#F2E9C8', '#E8B04B', '#C13B2E'])


def spec_db(sig, fmax=8000):
    ff, tt, Sxx = spectrogram(sig, fs=fsd, nperseg=NPER, noverlap=NOVER, window='hann')
    Sxx = 20 * np.log10(Sxx + 1e-18)
    km = ff <= fmax
    return tt, ff[km], Sxx[km]


# =====================================================================
# 图1: 波形对比
# =====================================================================
fig, axes = plt.subplots(2, 2, figsize=(13.2, 6.6),
                         gridspec_kw={'width_ratios': [2.0, 1], 'hspace': 0.42, 'wspace': 0.18})
# 左列: 全程全频波形; 右列: 50-400Hz 带通波形(低频噪声本体)
before_lf = bp(before, 50, 400, fs=fsd)
after_lf = bp(after, 50, 400, fs=fsd)
lf_scale = max(np.abs(before_lf).max(), np.abs(after_lf).max()) + 1e-12
panels1 = [
    (t, before, '除杂前（DS 波束输出）', '全程波形（全频带，6 s）', (-4.2, 4.2), axes[0][0]),
    (t, after, '除杂后（阶段二 MWF）', None, (-4.2, 4.2), axes[1][0]),
    (t, before_lf / lf_scale, '除杂前 · 50–400 Hz 带通', '低频成分波形（50–400 Hz 带通，6 s）', (-1.15, 1.15), axes[0][1]),
    (t, after_lf / lf_scale, '除杂后 · 50–400 Hz 带通', None, (-1.15, 1.15), axes[1][1]),
]
for (tt, sig, name, tag, ylim, ax_) in panels1:
    ax_.plot(tt, sig, color=C_BEFORE if '除杂前' in name else C_AFTER, lw=0.55)
    ax_.set_facecolor('#FAFBFC')
    ax_.grid(True, color='#E2E7ED', lw=0.6)
    ax_.set_ylim(*ylim)
    ax_.set_ylabel('归一化振幅', fontsize=10)
    ax_.text(0.012, 0.9, name, transform=ax_.transAxes, fontsize=10.5,
             va='top', ha='left', color='#1B2430',
             bbox=dict(boxstyle='round,pad=0.3', fc='white', ec='#D8DEE6', alpha=0.9))
    if tag:
        ax_.set_title(tag, fontsize=12, fontweight='bold', color='#1B2430', pad=8)
for ax_ in axes[0]:
    ax_.set_xticklabels([])
for ax_ in axes[1]:
    ax_.set_xlabel('时间 t / s')
fig.suptitle('图 1　除杂前（上）与除杂后（下）波形对比：全频带（左）与 50–400 Hz 低频成分（右）',
             fontsize=14, fontweight='bold', y=0.985)
fig.text(0.5, 0.012,
         '说明：统一 RMS 归一化、成对共用纵轴刻度；右列为 50–400Hz 带通信号（同量程），除杂后低频噪声包络显著收敛。',
         ha='center', fontsize=9.5, color=GREY)
fig.savefig(os.path.join(OUT, 'fig1_waveform.png'), dpi=300, bbox_inches='tight')
plt.close(fig)
print('fig1 done')

# =====================================================================
# 图2: 语谱图对比(全频 + 低频噪声区放大)
# =====================================================================
fig2, axes2 = plt.subplots(2, 2, figsize=(13.2, 7.0),
                             gridspec_kw={'hspace': 0.32, 'wspace': 0.12})
panels = [
    (before, 8000, '除杂前 · 全频语谱图（0–8 kHz）', axes2[0][0], False),
    (after, 8000, '除杂后 · 全频语谱图（0–8 kHz）', axes2[0][1], False),
    (before, 1200, '除杂前 · 低频噪声区放大（0–1.2 kHz）', axes2[1][0], False),
    (after, 1200, '除杂后 · 低频噪声区放大（0–1.2 kHz）', axes2[1][1], True),
]
vmin_full, vmax_full = -150, -30
vmin_lf, vmax_lf = -150, -30
ims_all = []
for sig, fmax, title, ax, annotate in panels:
    tt, ff, Sxx = spec_db(sig, fmax)
    vmin, vmax = (vmin_full, vmax_full) if fmax == 8000 else (vmin_lf, vmax_lf)
    im = ax.pcolormesh(tt, ff, Sxx, cmap=CMAP, vmin=vmin, vmax=vmax, shading='auto')
    ax.set_title(title, fontsize=11.5, fontweight='bold', pad=7)
    ax.set_ylabel('频率 f / Hz', fontsize=10)
    ax.set_xlabel('时间 t / s', fontsize=10)
    if fmax == 1200:
        ax.set_yticks(np.arange(0, 1201, 200))
        # 干扰能量带底色(两图都画, 便于对照)
        ax.axhspan(60, 400, color=C_NOISE, alpha=0.10, zorder=0)
        ax.axhspan(400, 800, color=C_BEFORE, alpha=0.07, zorder=0)
        if annotate:
            ax.annotate('中频干扰带 400–800 Hz：除杂后明显压暗', xy=(0.25, 660), xytext=(1.5, 1030),
                        fontsize=9.5, color='#7A352C', fontweight='bold',
                        arrowprops=dict(arrowstyle='->', color='#7A352C', lw=1.2),
                        bbox=dict(boxstyle='round,pad=0.25', fc='white', ec=C_BEFORE, alpha=0.9))
            ax.annotate('低频干扰带 60–400 Hz（孔径受限，残余较多）', xy=(4.7, 300), xytext=(1.5, 120),
                        fontsize=9.5, color='#8A5A10', fontweight='bold',
                        arrowprops=dict(arrowstyle='->', color='#8A5A10', lw=1.2),
                        bbox=dict(boxstyle='round,pad=0.25', fc='white', ec=C_NOISE, alpha=0.9))
    ims_all.append((im, fmax, ax))
# 两个独立 colorbar
for fmax_target, pos in ((8000, [0.925, 0.62, 0.012, 0.27]),
                         (1200, [0.925, 0.14, 0.012, 0.27])):
    axp = fig2.add_axes(pos)
    im0 = [im for im, fm, _ in ims_all if fm == fmax_target][0]
    cb = fig2.colorbar(im0, cax=axp)
    cb.set_label('功率谱密度 / dB', fontsize=9)
    cb.ax.tick_params(labelsize=8.5)
fig2.suptitle('图 2　语谱图对比：低频噪声带（60–400 Hz）在除杂后显著衰减，目标线谱与中高频结构保留',
              fontsize=13.5, fontweight='bold', y=0.975)
fig2.savefig(os.path.join(OUT, 'fig2_spectrogram.png'), dpi=300, bbox_inches='tight')
plt.close(fig2)
print('fig2 done')

# =====================================================================
# 图3: 振幅-频率谱(PSD) + 分带能量
# =====================================================================
fig3, (axA, axB) = plt.subplots(1, 2, figsize=(13.2, 5.4),
                                gridspec_kw={'width_ratios': [1.75, 1], 'wspace': 0.22})
# PSD: Welch 平均幅度谱
from scipy.signal import welch
def db_psd(sig):
    wf_, P = welch(sig, fs=fsd, nperseg=4096, noverlap=3072, window='hann')
    return wf_, 20 * np.log10(np.sqrt(P) + 1e-18)   # 幅度谱(dB, 相对值)
fr, Ab = db_psd(before); _, Aa = db_psd(after); _, Ar = db_psd(ref)
km = fr <= 8000
axA.axvspan(60, 400, color=C_NOISE, alpha=0.12, zorder=0, label='低频强干扰带 60–400 Hz')
axA.plot(fr[km], Ab[km], color=C_BEFORE, lw=1.4, label='除杂前（DS）')
axA.plot(fr[km], Aa[km], color=C_AFTER, lw=1.4, label='除杂后（MWF）')
axA.plot(fr[km], Ar[km], color=C_REF, lw=1.2, ls='--', label='干净参考（原音频）')
axA.set_xlim(0, 8000)
axA.set_xticks(np.arange(0, 8001, 1000))
axA.set_xlabel('频率 f / Hz')
axA.set_ylabel('平均幅度谱 / dB（相对值）')
axA.set_title('振幅–频率关系：低频段幅度被压向参考水平', fontsize=12, fontweight='bold', pad=8)
axA.grid(True, color='#E2E7ED', lw=0.6)
axA.set_facecolor('#FAFBFC')
axA.legend(loc='upper right', fontsize=9.5, framealpha=0.95, edgecolor='#D8DEE6')
axA.annotate('60–400Hz 干扰能量显著下降', xy=(230, Ab[(fr >= 200)][0]), xytext=(2600, -42),
            fontsize=9.5, color='#8A5A10', fontweight='bold',
            arrowprops=dict(arrowstyle='->', color='#8A5A10', lw=1.3),
            bbox=dict(boxstyle='round,pad=0.3', fc='white', ec=C_NOISE, alpha=0.95))

# 分带能量
bands = [(50, 100), (100, 200), (200, 400), (400, 800), (800, 1600), (1600, 3200), (3200, 6400)]
labels = ['50–100', '100–200', '200–400', '400–800', '800–1600', '1600–3200', '3200–6400']
def band_e(sig):
    return np.array([np.sum(bp(sig, lo, hi, fs=fsd) ** 2) for lo, hi in bands])
Eb, Ea, Er2 = band_e(before), band_e(after), band_e(ref)
# 以参考为基准的相对能量 dB
def rel_db(E):
    return 10 * np.log10(E / (Er2 + 1e-30) + 1e-30)
xpos = np.arange(len(bands)); w = 0.27
axB.bar(xpos - w, rel_db(Eb), w, color=C_BEFORE, label='除杂前')
axB.bar(xpos, rel_db(Ea), w, color=C_AFTER, label='除杂后')
axB.bar(xpos + w, np.zeros_like(xpos, dtype=float), w, color=C_REF, alpha=0.55, label='干净参考(0 基准)')
axB.axhline(0, color=C_REF, lw=1.2, ls='--')
axB.set_xticks(xpos)
axB.set_xticklabels(labels, rotation=28, ha='right', fontsize=9)
axB.set_ylabel('相对参考的频带能量 / dB')
axB.set_title('分带能量偏差：中频带向参考收敛', fontsize=12, fontweight='bold', pad=8)
axB.grid(True, axis='y', color='#E2E7ED', lw=0.6)
axB.set_facecolor('#FAFBFC')
axB.legend(fontsize=9.5, framealpha=0.95, edgecolor='#D8DEE6')
for i, (vb_, va_) in enumerate(zip(rel_db(Eb), rel_db(Ea))):
    if abs(vb_) >= 0.2:
        axB.text(i - w, vb_ + (0.25 if vb_ >= 0 else -0.55), f'{vb_:+.1f}', ha='center', fontsize=7.8, color=C_BEFORE)
    if abs(va_) >= 0.2:
        axB.text(i, va_ + (0.25 if va_ >= 0 else -0.55), f'{va_:+.1f}', ha='center', fontsize=7.8, color=C_AFTER)
fig3.suptitle('图 3　除杂前后振幅谱与分带能量对比（44.1 kHz，Welch 平均，4096 点窗）',
              fontsize=13.5, fontweight='bold', y=1.0)
fig3.savefig(os.path.join(OUT, 'fig3_spectrum.png'), dpi=300, bbox_inches='tight')
plt.close(fig3)
print('fig3 done ->', OUT)

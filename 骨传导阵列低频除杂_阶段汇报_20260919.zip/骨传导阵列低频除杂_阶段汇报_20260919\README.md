# 骨传导 / 六通道麦克风阵列低频除杂 —— 阶段汇报材料包

**日期**：2026-09-19

## 目录结构

```
骨传导阵列低频除杂_阶段汇报_20260919/
├── README.md                         本说明
├── docs/
│   ├── 骨传导阵列低频除杂_阶段汇报报告.md   主汇报报告（先看这份）
│   └── figures/                      除杂效果专业配图（300 DPI PNG）
│       ├── fig1_waveform.png         除杂前后波形对比（全频 + 50–400Hz 带通）
│       ├── fig2_spectrogram.png    语谱图对比（全频 + 0–1.2kHz 噪声区放大）
│       └── fig3_spectrum.png        振幅–频率谱 + 分带能量对比
├── slides/
│   └── 骨传导阵列低频除杂_汇报PPT_20260919.pptx   14 页汇报 PPT（可直接放映/编辑）
├── src/
│   ├── analysis/                     阶段一/阶段二全部源码与评测脚本
│   │   ├── alg02.py                  核心算法（lf_mode='joint' / 'mwf'）
│   │   ├── joint_eval.py             统一口径正式评测（一键跑分入口）
│   │   ├── common.py                 SI-SDR、滤波、对齐等公共函数
│   │   ├── load_data.py              原始录音解析与缓存
│   │   ├── make_figures.py          除杂效果配图生成（3 张 PNG）
│   │   ├── eval02.py / ablate.py     评测与消融
│   │   ├── sweep.py / sweep2.py      参数扫描
│   │   ├── oracle.py / phys_limit.py oracle 上限 / 物理瓶颈分析
│   │   ├── diag1.py ~ diag7.py       机理诊断脚本
│   │   └── run_baseline.py           基线接入
│   └── baseline/
│       └── 算法01.py                  阶段一前基线算法
├── tools/ppt_gen/                    PPT 生成工程（PptxGenJS，可复现/改版）
│   ├── build_deck.mjs / tokens.mjs / primitives.mjs / ppt.mjs
│   └── 复现：npm install pptxgenjs && node build_deck.mjs
└── results/
    └── joint_eval_输出.txt            2026-09-19 正式跑分完整输出
```

## 一句话结论

full SI-SDR：纯 DS −1.68 dB → 阶段一 joint +0.24 dB → **阶段二分段 MWF +0.61 dB**；
中频段（400–1600 Hz）改善约 5 dB，50–100 Hz 目标帧保留 −4.82 dB 达标，
RTF≈0.38 近实时；<400 Hz 经 oracle 分析证实为阵列孔径物理瓶颈。
详见 `docs/骨传导阵列低频除杂_阶段汇报报告.md`。

## 复现方式

1. 环境：Python 3.13，依赖 `numpy scipy pandas`。
2. 将 6 个原始录音 txt（1.txt~6.txt）按 `load_data.py` 中的目录约定放置
   （原始数据约 175 MB，未随包提供；缓存 .npy 约 200 MB，亦未提供）。
   **注意**：`src/analysis/load_data.py` 中 `ROOT` 为原开发机绝对路径，
   换机器运行前需改成本地工程根目录。
3. 运行：

   ```powershell
   cd src/analysis
   python joint_eval.py
   ```

   输出 DS / 算法01 / SLM / joint / MWF / oIRM / oMWF 七组分带 SI-SDR、
   50–100 Hz 目标保留率、RTF 与音乐噪声统计，与 `results/joint_eval_输出.txt` 一致。

## 说明

- 包内仅含源代码、文档与跑分文本；不含原始录音、npy 缓存与 `__pycache__`。
- 定版算法参数直接写在 `joint_eval.py` 的 `JOINT` / `MWF` 字典中。

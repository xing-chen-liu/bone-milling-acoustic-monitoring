# -*- coding: utf-8 -*-
import numpy as np, sys, os, time
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from alg02 import alg02, template_tdoa, front_end
from scipy.signal import stft
six, raw = data()
FS=352800.0
x, fsd = front_end(six, fsub=25.0, decim=8)
Z=np.stack([stft(x[i],fs=fsd,nperseg=2048,noverlap=1536)[2] for i in range(6)])
f=np.fft.rfftfreq(2048,1.0/fsd)
for q in [0.65,0.8,0.9,0.95,0.99]:
    p,c=template_tdoa(Z,f,fsd,6,qhi=q)
    print(f"qhi={q}: pair={np.round(p,3)} sum={c[-1]:.2f} (x8={c[-1]*8:.1f})")
print("\n目标: GCC实测 ch1-ch6 = 107样本@352.8k = 13.4样本@44.1k")

def unsup(cum):
    """无监督判据: DS 输出在目标主导带(1.6-6.4k)的相干增益 = 输出能量 / 平均通道能量"""
    A=np.zeros(Z.shape[1:],dtype=complex)
    m=(f>=1600)&(f<=6400)
    for i in range(6): A+=Z[i]*np.exp(1j*2*np.pi*f[:,None]*cum[i]/fsd)
    A/=6
    po=(np.abs(A[m])**2).mean(); pi=(np.abs(Z[:,m])**2).mean()
    return 10*np.log10(po/pi)
p065,_=template_tdoa(Z,f,fsd,6,qhi=0.65); base_cum=np.concatenate([[0],np.cumsum(p065)])
print(f"\n无监督相干增益 自动(qhi=.65)模板: {unsup(base_cum):+.2f} dB")
for s in [0.8,1.0,1.2,1.4,1.6,1.8,2.0]:
    print(f"  scale={s:>4}: 无监督={unsup(base_cum*s):+6.2f} dB   ", end="")
    o=alg02(six, tmpl_override=p065*s, qhi=0.65, f_guard=120.0); r=evaluate(o,raw,tag=f"scale={s}",verbose=False)
    print(f"SI-SDR={r['si_sdr_full']:+.2f} 加权={r['si_sdr_wavg']:+.2f} LF={r['LF_residue_dB']:+.1f}")

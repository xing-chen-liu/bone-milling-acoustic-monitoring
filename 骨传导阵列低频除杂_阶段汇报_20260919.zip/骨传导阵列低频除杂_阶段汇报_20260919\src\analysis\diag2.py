# -*- coding: utf-8 -*-
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from load_data import load_all, load_ref
from scipy.signal import welch, coherence

FS = 352800.0
six = load_all().astype(np.float64)
raw = load_ref("raw", r"C:/Users/刘星辰/Desktop/bone/9.18/9.18/原音频.txt").astype(np.float64)
out = load_ref("out01", r"C:/Users/刘星辰/Desktop/bone/9.18/9.18/01 去噪结果.txt").astype(np.float64)

bands = [(0,20),(20,50),(50,100),(100,200),(200,400),(400,800),(800,1600),(1600,3200),
         (3200,6400),(6400,12500),(12500,20000),(20000,40000),(40000,80000),(80000,176400)]

def band_report(x, tag):
    freqs, P = welch(x, fs=FS, nperseg=16384, noverlap=8192)
    tot = np.trapezoid(P, freqs)
    print(f"\n=== {tag}  total={tot:.3e} ===")
    print(f"{'band(Hz)':>16}{'%E':>9}{'dB/Hz':>9}{'cum%E':>9}")
    cum=0
    for lo,hi in bands:
        m=(freqs>=lo)&(freqs<hi)
        if m.sum()<1: continue
        e=np.trapezoid(P[m],freqs[m]); cum+=e/tot*100
        print(f"{lo:>7.0f}-{hi:<8.0f}{e/tot*100:9.3f}{10*np.log10(P[m].mean()+1e-40):9.1f}{cum:9.2f}")
    for th in (20,50,100,200,400,800,1600,3200):
        print(f"   share <{th:>5}Hz = {np.trapezoid(P[freqs<th],freqs[freqs<th])/tot*100:7.3f}%")
    return freqs,P

band_report(six[0], "ch1 (raw 6-mic input)")
band_report(raw, "原音频.txt")
band_report(out, "01 去噪结果.txt")

print("\n=== inter-channel coherence (magnitude-squared, 16k seg) ===")
print(f"{'band(Hz)':>16}" + "".join(f"{f'{i}':>8}" for i in range(1,6)) + "   (ch1 vs chi+1)")
rows={}
for i in range(1,6):
    f,C = coherence(six[0], six[i], fs=FS, nperseg=16384, noverlap=8192)
    rows[i]=(f,C)
for lo,hi in bands:
    line=f"{lo:>7.0f}-{hi:<8.0f}"
    for i in range(1,6):
        f,C=rows[i]; m=(f>=lo)&(f<hi)
        line += f"{C[m].mean():8.3f}" if m.sum()>1 else f"{np.nan:8.3f}"
    print(line)

print("\n=== raw/out relation: best-lag correlation vs ch1 ===")
from scipy.signal import fftconvolve
def best_lag(a,b,maxlag=200000):
    a=a-a.mean(); b=b-b.mean()
    c=fftconvolve(a[::-1],b,mode='full')
    lo=max(0,len(c)//2-maxlag); hi=min(len(c),len(c)//2+maxlag)
    seg=c[lo:hi]; k=int(np.argmax(np.abs(seg)))
    return (lo+k-len(c)//2), c.max()/ (np.sqrt((a**2).sum()*(b**2).sum())+1e-30)
for i in range(6):
    lag,cc = best_lag(raw, six[i])
    print(f"  raw vs ch{i+1}: lag={lag} ({lag/FS*1000:.2f} ms)  |corr|={cc:.3f}")
np.save(os.path.join(os.path.dirname(__file__),"cache","_nothing.npy"), np.zeros(1))

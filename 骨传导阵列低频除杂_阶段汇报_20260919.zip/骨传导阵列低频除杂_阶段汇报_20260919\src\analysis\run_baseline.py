# -*- coding: utf-8 -*-
import numpy as np, sys, os, time
sys.path.insert(0, os.path.dirname(__file__)); sys.path.insert(0, r"C:/Users/刘星辰/Desktop/bone/9.18/9.18")
from load_data import load_all, load_ref, CACHE
import importlib.util
spec=importlib.util.spec_from_file_location("alg01", r"C:/Users/刘星辰/Desktop/bone/9.18/9.18/算法01.py")
alg=importlib.util.module_from_spec(spec); spec.loader.exec_module(alg)
six=load_all().astype(np.float64)
t0=time.time()
tdoas,pt=alg.estimate_target_tdoa(six,352800.0,6,0.008)
print("pair_tdoa_template =",np.round(pt,2)); print("cumulative tdoas =",np.round(tdoas,2)); print(f"TDOA est {time.time()-t0:.1f}s",flush=True)
t0=time.time(); out=alg.separate_target(six,fs=352800,num_mics=6,mic_spacing=0.008)
print(f"separate {time.time()-t0:.1f}s  shape={out.shape} rms={np.sqrt((out**2).mean()):.3e}",flush=True)
np.save(os.path.join(CACHE,"base.npy"),out)
ref=load_ref("raw", r"C:/Users/刘星辰/Desktop/bone/9.18/9.18/原音频.txt").astype(np.float64)
old=load_ref("out01", r"C:/Users/刘星辰/Desktop/bone/9.18/9.18/01 去噪结果.txt").astype(np.float64)
print("corr(repro, provided out01) =",np.corrcoef(out,old[:len(out)])[0,1])

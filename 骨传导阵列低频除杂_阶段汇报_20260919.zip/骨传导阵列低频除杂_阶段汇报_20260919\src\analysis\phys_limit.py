# -*- coding: utf-8 -*-
"""评测不确定性与低频可消除度的物理上限分析"""
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from common import *
six, raw = data()

# ---------- 1) 指标对对齐误差的敏感度 ----------
o = np.load(os.path.join(CACHE, "alg02_best.npy"))
L0 = best_lag(raw, o)
print(f"canonical lag = {L0}")
print(f"{'dlag':>6}{'SI-SDR':>10}{'加权':>10}")
for d in [-20, -10, -5, -2, 0, 2, 5, 10, 20]:
    a = align(raw, o, L0 + d)
    n = min(len(a), len(o))
    from common import si_sdr
    v = si_sdr(o[:n], a[:n])
    ws = []
    for lo, hi in EVAL_BANDS:
        ws.append((np.sum(bb(a[:n], lo, hi)**2), si_sdr(bb(o[:n], lo, hi), bb(a[:n], lo, hi))))
    w = sum(x*y for x, y in ws)/sum(x for x, _ in ws)
    print(f"{d:>6}{v:10.2f}{w:10.2f}")

# ---------- 2) 低频可消除度: 无失真约束下空间滤波的理论上限 ----------
NUM = 6
def removable(f, cum_t, cum_i, spacing_scale=1.0):
    """平面波假设下, 6元线阵以"目标无失真"为唯一约束时, 能抵消掉的干扰功率比例"""
    a_t = np.exp(1j*2*np.pi*f*np.asarray(cum_t)/1.0)
    a_i = np.exp(1j*2*np.pi*f*np.asarray(cum_i)/1.0)
    c = np.vdot(a_t, a_i)/np.sqrt(np.vdot(a_t, a_t).real*np.vdot(a_i, a_i).real)
    return 1 - abs(c)**2          # = ||B a_i||^2/||a_i||^2

CUM_T = np.array([0.0, 2.622, 5.472, 8.364, 10.863, 13.141])   # 44.1kHz 样本, ch1..ch6
FS_D = 44100.0
CUM_I = np.array([0, 0.35, 0.70, 1.05, 1.40, 1.75])
print(f"\n{'f(Hz)':>8}" + "".join(f"{s:>18}" for s in ["当前8mm基线", "24mm(3x)", "80mm(10x)"]))
print(f"{'':>8}" + "".join(f"{'消除量dB/可去除度':>18}" for _ in range(3)))
for fq in [100, 200, 400, 800, 1200, 2000, 3000, 4500, 7000]:
    row = f"{fq:>8}"
    for sc in [1.0, 3.0, 10.0]:
        r = removable(fq/FS_D, CUM_T*sc, CUM_I*sc)
        row += f"   {-10*np.log10(max(1-r,1e-9)):5.2f}dB/{r:5.2f}"
    print(row)
print("\n(消除量 = -10log10(1-可去除度), 即在目标完全无失真前提下, 空间滤波对该相干干扰的最大功率抑制)")

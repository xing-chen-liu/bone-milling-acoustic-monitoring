# -*- coding: utf-8 -*-
"""量化低频掩码失效机理：IPD-TDOA估计方差~1/f、频域栅格过粗、掩码分布"""
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from load_data import load_all, load_ref
from scipy.signal import stft, welch
FS=352800.0
six=load_all().astype(np.float64)
NP_=4096; NO_=NP_*3//4
Z=[]
for i in range(6):
    f,t,Zx=stft(six[i],fs=FS,nperseg=NP_,noverlap=NO_); Z.append(Zx)
Z=np.array(Z); nf,fr=len(f),Z.shape[2]
print(f"nperseg={NP_} -> 频率栅格 {FS/NP_:.2f} Hz/bin, n_freqs={nf}, frames={fr}")
pair=np.array([15.21,17.72,19.47,17.13,14.82]); sigma=max(pair.mean()*0.22,3.0)
f_limit=FS/(2*np.abs(pair).max()); d_far=0.008/343.0*FS
print(f"sigma(mask核宽)={sigma:.2f} 样本  f_limit(掩码上限)={f_limit:.0f} Hz  f_unamb(TDOA模板上限)={FS/(2*4*d_far):.0f} Hz")
print(f"低于20Hz的bin: k=0(DC) ; 20-400Hz 落在 bin {int(20/(FS/NP_))}..{int(400/(FS/NP_))} (共{int(400/(FS/NP_))-int(20/(FS/NP_))+1}个bin)")

w=np.abs(Z[0])
print("\n=== 每个频率 bin: IPD-TDOA估计的离散度 vs 掩码核宽 ===")
print(f"{'bin':>4}{'f(Hz)':>9}{'tdoa均值':>10}{'tdoa标准差':>12}{'std/sigma':>11}{'掩码均值':>10}{'P(mask<0.1)':>13}{'能量权重%':>11}")
tot_w=w.sum()
recs=[]
for fi in range(0,60):
    freq=f[fi]
    if freq<1: continue
    period=FS/freq
    ests=[]
    for i in range(5):
        ipd=np.angle(Z[i+1,fi]*np.conj(Z[i,fi]))
        raw_t=-ipd/(2*np.pi*freq)*FS
        k=np.round((pair[i]-raw_t)/period)
        ests.append(raw_t+k*period)
    ests=np.array(ests)
    dev=ests-pair[:,None]
    m=np.prod(np.exp(-(dev**2)/(2*sigma**2)),axis=0)**(1/5)
    wt=w[fi].sum()/tot_w*100
    print(f"{fi:>4}{freq:9.1f}{np.mean(ests):10.1f}{np.std(ests):12.1f}{np.std(ests)/sigma:11.1f}{m.mean():10.3f}{(m<0.1).mean()*100:12.1f}%{wt:10.2f}%")
    recs.append((freq,np.std(ests),m.mean(),wt))
print("\n=== 同上，1k-10kHz 抽样 ===")
for fi in range(int(1000/(FS/NP_)), nf, int(1000/(FS/NP_))):
    freq=f[fi]; period=FS/freq; ests=[]
    for i in range(5):
        ipd=np.angle(Z[i+1,fi]*np.conj(Z[i,fi])); rt=-ipd/(2*np.pi*freq)*FS
        k=np.round((pair[i]-rt)/period); ests.append(rt+k*period)
    ests=np.array(ests); dev=ests-pair[:,None]
    m=np.prod(np.exp(-(dev**2)/(2*sigma**2)),axis=0)**(1/5)
    print(f"{fi:>4}{freq:9.1f}{np.mean(ests):10.1f}{np.std(ests):12.1f}{np.std(ests)/sigma:11.1f}{m.mean():10.3f}{(m<0.1).mean()*100:12.1f}%{w[fi].sum()/tot_w*100:10.2f}%")

print("\n=== 窄带谱峰检测 (ch1, nperseg=65536) 20Hz-13kHz ===")
fq,P=welch(six[0],fs=FS,nperseg=65536,noverlap=32768)
med=np.array([P[(fq>=lo)&(fq<lo*1.3)].mean() for lo in fq])
m=(fq>20)&(fq<13000)
ii=np.argsort(P[m])[::-1]; seen=[]
for k in ii:
    v=fq[m][k]
    if any(abs(v-s)<80 for s in seen): continue
    seen.append(v)
    band=P[(fq>v-300)&(fq<v+300)]
    print(f"  峰 {v:8.1f} Hz  PSD={10*np.log10(P[m][k]):7.1f} dB/Hz  局部对比度={10*np.log10(P[m][k]/(np.median(band)+1e-40)):5.1f} dB")
    if len(seen)>=10: break

# -*- coding: utf-8 -*-
import numpy as np, sys, os, time
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from alg02 import alg02, front_end, template_tdoa, coherence_sigma, lf_frame_gain
from scipy.signal import stft
six, raw = data()
base = np.load(os.path.join(CACHE, "base.npy"))
evaluate(base, raw, tag="算法01(基线)")
t0=time.time(); o2 = alg02(six); dt=time.time()-t0
print(f"alg02 time={dt:.1f}s  RTF={dt/6.0:.3f}")
r=evaluate(o2, raw, tag="算法02(默认)")
np.save(os.path.join(CACHE,"alg02.npy"), o2)
# 诊断
o2d, dg = alg02(six, return_diag=True)
print("\npair_template(44.1k)=", np.round(dg['pair_t'],3), " cum=", np.round(dg['cum_t'],2))
print("f_unamb=", dg['f'][len(dg['f'])-1]*0+ 'inf', " 模板换算到352.8k:", np.round(dg['pair_t']*8,2))
f=dg['f']; stau=dg['stau']; mask=dg['mask']
print(f"{'f':>8}{'sigma_tau_pred':>16}{'mask均值':>10}")
for fq in [43,86,130,215,430,860,1720,3000,5000,8000,12000,18000]:
    i=int(np.argmin(np.abs(f-fq)))
    print(f"{f[i]:8.0f}{stau[i]*2:16.2f}{mask[i].mean():10.3f}")

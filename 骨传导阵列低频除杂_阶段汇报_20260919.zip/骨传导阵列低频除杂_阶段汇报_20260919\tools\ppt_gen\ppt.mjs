import pptxgen from 'pptxgenjs';

export const pptx = new pptxgen();
export const ShapeType = pptx.ShapeType;
export const ChartType = pptx.ChartType;

# -*- coding: utf-8 -*-
"""公共评测框架: 载入数据、对齐、分频带 SI-SDR / 低频残留 / 目标保真度"""
import numpy as np, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from load_data import load_all, load_ref, CACHE
from scipy.signal import butter, sosfiltfilt, fftconvolve, resample_poly

FS = 352800.0
SPACING = 0.008
C = 343.0
D_FAR = SPACING / C * FS          # 8.23 samples 远场相邻对最大TDOA
PAIR_T = np.array([15.21, 17.72, 19.47, 17.13, 14.82])   # 基线模板
# 有意义评测带(参考录音在此带内可信; >12.5kHz 为量化噪声底)
EVAL_BANDS = [(100,200),(200,400),(400,800),(800,1600),(1600,3200),(3200,6400),(6400,12500)]
LF_BANDS   = [(5,20),(20,50),(50,100)]

def data():
    six = load_all().astype(np.float64)
    raw = load_ref("raw", r"C:/Users/刘星辰/Desktop/bone/9.18/9.18/原音频.txt").astype(np.float64)
    return six, raw

def bp(x, lo, hi, order=4, fs=FS):
    sos = butter(order, np.array([lo, hi])/(fs/2), btype='band', output='sos')
    return sosfiltfilt(sos, x, axis=-1)

def bb(x, lo, hi, fs=FS):
    """砖墙分频带(FFT 域), 避免 Butterworth 过渡带把低频残留漏进相邻评测带"""
    X = np.fft.rfft(x, axis=-1); fr = np.fft.rfftfreq(x.shape[-1], 1.0/fs)
    X[(fr < lo) | (fr >= hi)] = 0
    return np.fft.irfft(X, n=x.shape[-1], axis=-1)


def hp(x, lo, order=4, fs=FS):
    sos = butter(order, lo/(fs/2), btype='high', output='sos')
    return sosfiltfilt(sos, x, axis=-1)

def best_lag(ref, sig, lo=400, hi=7000, maxlag=200000):
    """返回 lag 使 sig[n] ~ ref[n-lag] 相关最大 (正=ref提前)"""
    x = bp(ref, lo, hi) - bp(ref, lo, hi).mean()
    y = bp(sig, lo, hi) - bp(sig, lo, hi).mean()
    m = min(len(x), len(y)); x = x[:m]; y = y[:m]
    c = fftconvolve(x[::-1], y, mode='full'); L = len(c)//2
    seg = c[L-maxlag:L+maxlag]; j = int(np.argmax(seg))
    return j - maxlag

def align(ref, sig, lag=None):
    """sig(t) = ref(t - lag)  =>  返回 ref_aligned[t] = ref[t - lag], 与 sig 同轴同长"""
    if lag is None: lag = best_lag(ref, sig)
    t = np.arange(len(sig)) - int(lag)
    ok = (t >= 0) & (t < len(ref))
    out = np.zeros(len(sig))
    out[ok] = ref[t[ok]]
    return out

def si_sdr(est, clean):
    m = min(len(est), len(clean)); e = est[:m]-est[:m].mean(); c = clean[:m]-clean[:m].mean()
    s_t = (np.dot(e, c)/np.dot(c, c)+1e-30)*c
    return 10*np.log10(np.dot(s_t, s_t)/(np.dot(e-s_t, e-s_t)+1e-30)+1e-30)

def evaluate(sig, ref, six=None, tag="", verbose=True, bands=EVAL_BANDS+LF_BANDS):
    lag = best_lag(ref, sig)
    a = align(ref, sig, lag)
    n = min(len(sig), len(a)); sig = sig[:n]; a = a[:n]
    r = {"tag": tag, "lag": int(lag), "si_sdr_full": si_sdr(sig, a), "rms": float(np.sqrt((sig**2).mean()))}
    per = {}
    for lo, hi in bands:
        per[(lo, hi)] = si_sdr(bb(sig, lo, hi), bb(a, lo, hi))
    r["bands"] = per
    # 加权整体 SI-SDR (按参考在该带的能量占比)
    w = np.array([np.sum(bb(a, lo, hi)**2) for lo, hi in EVAL_BANDS])
    v = np.array([per[b] for b in EVAL_BANDS])
    r["si_sdr_wavg"] = float(np.sum(w*v)/np.sum(w))
    r["si_sdr_lo3"] = float(np.mean(np.sort(v)[:3]))
    r["si_sdr_obj"] = float(np.mean(v))
    # 低频残留指数: 输出 5-100Hz 能量 / 输出 100-12500Hz 能量 (dB), 越小越好
    lf = np.sum(bb(sig, 5, 100)**2); mb = np.sum(bb(sig, 100, 12500)**2)
    r["LF_residue_dB"] = float(10*np.log10(lf/(mb+1e-40)))
    lfc = np.sum(bb(a, 5, 100)**2); mbc = np.sum(bb(a, 100, 12500)**2)
    r["LF_ref_dB"] = float(10*np.log10(lfc/(mbc+1e-40)))
    if verbose:
        print(f"[{tag}] lag={lag:+d} SI-SDR(全带)={r['si_sdr_full']:+6.2f}  "
              f"加权={r['si_sdr_wavg']:+6.2f}  最差3带均值={r['si_sdr_lo3']:+6.2f}  "
              f"LF残留={r['LF_residue_dB']:+6.1f}dB (参考={r['LF_ref_dB']:+.1f})  rms={r['rms']:.2e}")
        print("        分频带SI-SDR: " + "  ".join(f"{lo/1000:g}-{hi/1000:g}k={per[(lo,hi)]:+.2f}" if lo>=1000
              else f"{lo}-{hi}={per[(lo,hi)]:+.2f}" for lo, hi in bands))
    return r


def frac_delay(x, d, fs=FS):
    """分数样本延时 (FFT 相位斜坡), d>0 => 输出 = x(t - d)"""
    X = np.fft.rfft(x); fr = np.fft.rfftfreq(len(x), 1.0/fs)
    return np.fft.irfft(X*np.exp(-1j*2*np.pi*fr*d/fs*fs/fs*1.0)*np.exp(-1j*2*np.pi*fr*(d/fs)*fs/fs), n=len(x))

def align_opt(ref, sig, coarse=None, span=40, step=0.25, fs=FS, band=(100, 12500)):
    """分数延迟搜索使分频带加权的 SI-SDR 最大, 消除整数对齐抖动 (~5样本 => ~1.5dB 假差异)"""
    if coarse is None: coarse = best_lag(ref, sig)
    r0 = sig*0
    best = (-1e9, coarse)
    for d in np.arange(coarse-span, coarse+span+1e-9, step):
        a = _shift(ref, d, len(sig), fs)
        v = si_sdr(sig*0+bb(sig, *band), bb(a, *band))
        if v > best[0]: best = (v, d)
    return _shift(ref, best[1], len(sig), fs), best[1], best[0]

def _shift(x, d, n, fs=FS):
    X = np.fft.rfft(x); fr = np.fft.rfftfreq(len(x), 1.0/fs)
    y = np.fft.irfft(X*np.exp(-1j*2*np.pi*fr*d/fs), n=len(x))
    out = np.zeros(n); m = min(n, len(y)); out[:m] = y[:m]
    return out

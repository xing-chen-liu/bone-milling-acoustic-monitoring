// 设计令牌 —— 正式工作汇报风格: 严谨、克制、工程化
export const C = {
  bg:       'FFFFFF',
  surface:  'F4F6F9',   // 浅面板
  surface2: 'EAF0F6',   // 稍深面板/表头
  ink:      '1B2430',   // 主文字(近黑墨蓝)
  ink2:     '3E4C5E',   // 次文字
  muted:    '6E7C8D',   // 注释/来源
  accent:   '1F5C99',   // 主强调(蓝)
  accent2:  '2E7FC4',   // 亮蓝
  amber:    'B07A1C',   // 次强调(琥珀)
  positive: '2E7D46',   // 达标
  caution:  'B97A12',   // 接近/风险中
  risk:     'C13B2E',   // 未达/差距
  hairline: 'D8DEE6',
  hairline2:'C2CAD4',
  white:    'FFFFFF',
  dsGray:   '8A94A0',
  jointAm:  'C98A2B',
};

export const F = {
  cn: 'Microsoft YaHei',   // 中文主字体(Windows 通用)
  num: 'Arial',            // 数字/英文
};

// 16:9 画布与节奏
export const PAGE = { w: 13.333, h: 7.5, mx: 0.62 };
export const RHY = {
  labelY: 0.33, titleY: 0.57, ruleY: 1.12, contentY: 1.34,
  footerY: 7.08,
};

export const T = {
  sectionLabel: { fontFace: F.cn, fontSize: 10.5, bold: true, color: C.accent, charSpacing: 2 },
  claim:        { fontFace: F.cn, fontSize: 22, bold: true, color: C.ink },
  body:         { fontFace: F.cn, fontSize: 12, color: C.ink2 },
  bodyStrong:   { fontFace: F.cn, fontSize: 12, bold: true, color: C.ink },
  annotation:   { fontFace: F.cn, fontSize: 10, color: C.muted },
  source:       { fontFace: F.cn, fontSize: 8.5, color: C.muted },
  folio:        { fontFace: F.num, fontSize: 8.5, color: C.muted },
};

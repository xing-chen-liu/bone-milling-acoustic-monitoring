# -*- coding: utf-8 -*-
import numpy as np, pandas as pd, os, sys, time

ROOT = r"C:/Users/刘星辰/Desktop/bone"
CACHE = os.path.join(ROOT, "analysis", "cache")
os.makedirs(CACHE, exist_ok=True)
FILES = [os.path.join(ROOT, "data", "六通道音频录音", f"{i}.txt") for i in (1, 2, 3)] + \
        [os.path.join(ROOT, "data", "六通道音频录音2", f"{i}.txt") for i in (4, 5, 6)]

def load_col(path, name):
    t0 = time.time()
    a = pd.read_csv(path, header=None, dtype=np.float32).to_numpy().ravel()
    np.save(os.path.join(CACHE, name + ".npy"), a)
    print(f"{name}: n={a.size}  {time.time()-t0:.1f}s", flush=True)
    return a

def load_all():
    p = os.path.join(CACHE, "six.npy")
    if os.path.exists(p):
        return np.load(p)
    ch = [load_col(f, f"ch{i+1}") for i, f in enumerate(FILES)]
    n = min(c.size for c in ch)
    six = np.stack([c[:n] for c in ch]).astype(np.float32)
    np.save(p, six)
    return six

def load_ref(name, path):
    p = os.path.join(CACHE, name + ".npy")
    if os.path.exists(p):
        return np.load(p)
    a = pd.read_csv(path, header=None, dtype=np.float32).to_numpy().ravel()
    np.save(p, a)
    return a

if __name__ == "__main__":
    six = load_all()
    print("six", six.shape, "rms per ch", np.sqrt((six.astype(np.float64)**2).mean(1)))
    raw = load_ref("raw", os.path.join(ROOT, "9.18", "9.18", "原音频.txt"))
    out = load_ref("out01", os.path.join(ROOT, "9.18", "9.18", "01 去噪结果.txt"))
    print("raw", raw.shape, "rms", float(np.sqrt((raw.astype(np.float64)**2).mean())))
    print("out", out.shape, "rms", float(np.sqrt((out.astype(np.float64)**2).mean())))

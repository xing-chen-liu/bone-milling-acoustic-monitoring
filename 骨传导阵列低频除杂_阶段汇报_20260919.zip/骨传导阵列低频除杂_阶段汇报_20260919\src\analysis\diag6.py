# -*- coding: utf-8 -*-
"""验证 原音频.txt 是否为可信 clean reference; 刻画目标/干扰的幅度(ILD)与相位(ITD)线索"""
import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from common import *
from scipy.signal import welch
six, raw = data(); n = six.shape[1]
old = load_ref("out01", r"C:/Users/刘星辰/Desktop/bone/9.18/9.18/01 去噪结果.txt").astype(np.float64)
base = np.load(os.path.join(CACHE, "base.npy"))
print("corr(base, old) =", np.corrcoef(base, old[:len(base)])[0,1])

lag = best_lag(raw, six[0]); print("best lag raw->ch1:", lag)
a = align(raw, six[0], lag); n2 = min(len(a), n); a = a[:n2]
print("\n=== 参考 vs 各通道 (对齐后) 分频带 SI-SDR / 相关 / 增益 ===")
for lo, hi in [(20,50),(50,100),(100,200),(200,400),(400,800),(800,1600),(1600,3200),(3200,6400),(6400,12500),(12500,19000)]:
    r = bp(a, lo, hi)
    row = f"  {lo:>5.0f}-{hi:<6.0f}"
    for i in range(6):
        c = bp(six[i][:n2], lo, hi)
        cc = np.corrcoef(r, c)[0,1]
        row += f" {cc:+.2f}/{np.sqrt((c**2).mean())/np.sqrt((r**2).mean()):.2f}"
    print(row + "   (corr/rms比, ch1..ch6)")
print("\n=== 目标在各通道的相对增益 (由 400-6400Hz 反演) ===")
g = []
for i in range(6):
    r = bp(a, 400, 6400); c = bp(six[i][:n2], 400, 6400)
    g.append(np.dot(r, c)/np.dot(r, r))
g = np.array(g); print("  h_i =", np.round(g, 3), " (20log10 dB)", np.round(20*np.log10(np.abs(g)+1e-9), 2))
print("  => 目标端射近场幅度衰减: ch1->ch6 =", f"{20*np.log10(abs(g[0]/g[5])):.2f} dB")
print("\n=== 低频干涉在各通道的相对增益 (20-100Hz, 与参考不相关 => 纯干扰) ===")
gl = []
for i in range(6):
    r = bp(a, 20, 100); c = bp(six[i][:n2], 20, 100)
    gl.append(np.dot(r, c)/np.dot(r, r))
print("  h_i(LF) =", np.round(np.array(gl), 3))
for i in range(6):
    c = bp(six[i][:n2], 20, 100); print(f"    ch{i+1} LF rms={np.sqrt((c**2).mean()):.3e}")
print("\n=== 谱峰归属: 音调成分在参考里是否也存在 ===")
fq, P = welch(a, fs=FS, nperseg=65536, noverlap=32768)
_, P0 = welch(six[0], fs=FS, nperseg=65536, noverlap=32768)
_, Pb = welch(base, fs=FS, nperseg=65536, noverlap=32768)
for f0 in [699.8, 1092.8, 1378.1, 1636.5, 1846.5, 2169.5, 2847.8, 3073.9]:
    m = (fq > f0-25) & (fq < f0+25); w = (fq > f0-400) & (fq < f0+400) & ~m
    print(f"  {f0:7.1f}Hz  ch1峰-底={10*np.log10(P0[m].max()/(np.median(P0[w])+1e-40)):5.1f}dB   "
          f"ref峰-底={10*np.log10(P[m].max()/(np.median(P[w])+1e-40)):5.1f}dB   "
          f"base峰-底={10*np.log10(Pb[m].max()/(np.median(Pb[w])+1e-40)):5.1f}dB")
print("\n=== 基线客观指标 ===")
r_ref = evaluate(a := align(raw, base), raw, tag="ref->base轴(自检)")
evaluate(base, align(raw, base, best_lag(raw, base)), tag="baseline(算法01)")
evaluate(six[0], raw, tag="单通道ch1")
evaluate(six.mean(0), raw, tag=" naive mean6")
